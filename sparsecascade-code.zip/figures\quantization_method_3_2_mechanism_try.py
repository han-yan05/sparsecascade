from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

np.random.seed(21)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(9.5, 5.5), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.5, weight="normal", color="#334155", ha="center", va="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va=va, zorder=50,
    )


def chip(x, y, w, h, text, facecolor, edgecolor, fontsize=8.1, color="#1f2937"):
    canvas.add_patch(
        FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.003,rounding_size=0.01",
            transform=canvas.transAxes,
            facecolor=facecolor, edgecolor=edgecolor,
            linewidth=0.9, zorder=35,
        )
    )
    label(x + w / 2, y + h / 2, text, size=fontsize, weight="bold", color=color)


def arrow(x1, y1, x2, y2, color="#64748b", lw=1.8, scale=14, style="-|>"):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle=style,
            mutation_scale=scale, linewidth=lw, color=color,
            transform=canvas.transAxes, zorder=30,
        )
    )


rows, cols = 12, 12
weight = np.abs(np.random.randn(rows, cols))
weight = (weight - weight.min()) / (weight.max() - weight.min() + 1e-9)
importance = np.array([0.92, 0.83, 0.26, 0.77, 0.41, 0.72, 0.31, 0.88, 0.24, 0.67, 0.18, 0.79])
keep_rows = importance >= 0.40
pruned_rows = ~keep_rows

rng_act = np.random.default_rng(21)
n_dims = 20
act_vals = rng_act.exponential(scale=0.18, size=n_dims)
outlier_first = rng_act.choice(n_dims // 2, size=2, replace=False)
outlier_second = rng_act.choice(n_dims // 2, size=1, replace=False)[0] + n_dims // 2
outlier_indices = np.concatenate([outlier_first, [outlier_second]])
act_vals[outlier_indices] += rng_act.uniform(0.40, 0.60, size=len(outlier_indices))
threshold = np.quantile(act_vals, 0.85)
outlier_mask = act_vals >= threshold


def style_ax(ax):
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def draw_mask_signal(ax):
    style_ax(ax)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, rows)
    for idx in range(rows):
        y = rows - 1 - idx + 0.08
        if keep_rows[idx]:
            fill = "#60a5fa"
            edge = "#2563eb"
        else:
            fill = "#fecaca"
            edge = "#f87171"
        ax.add_patch(Rectangle((0.18, y), 0.64, 0.76,
                               facecolor=fill, edgecolor=edge, linewidth=0.7))
        ax.text(0.50, y + 0.38, f"L{idx+1}", ha="center", va="center",
                fontsize=6.0, color="white" if keep_rows[idx] else "#991b1b", fontweight="bold")
    ax.text(0.50, rows + 0.30, "Pruning Mask Anchor", ha="center", va="bottom",
            fontsize=9.0, fontweight="bold", color="#1d4ed8")
    ax.text(0.50, -0.55, "Blue=Kept  Red=Pruned", ha="center", va="top",
            fontsize=7.0, fontweight="bold", color="#475569")


def draw_sensitivity_signal(ax):
    style_ax(ax)
    idx = np.arange(len(act_vals))
    colors = np.where(outlier_mask, "#f59e0b", "#93c5fd")
    ax.bar(idx, act_vals, color=colors, width=0.72, edgecolor="white", linewidth=0.3)
    ax.axhline(threshold, color="#f59e0b", linestyle="--", linewidth=1.0)
    ax.set_xlim(-0.6, len(act_vals) - 0.4)
    ax.set_ylim(0, max(act_vals) * 1.15)
    ax.set_title("Activation Sensitivity", fontsize=9.0, pad=3, fontweight="bold")
    ax.text(0.50, -0.12, "Outlier dims → High-precision protection", ha="center", va="top",
            fontsize=7.0, fontweight="bold", color="#475569", transform=ax.transAxes)


def draw_dense_calibration(ax):
    style_ax(ax)
    ax.imshow(weight, cmap="viridis", aspect="equal", interpolation="nearest", vmin=0, vmax=1)
    for row in np.where(pruned_rows)[0]:
        ax.add_patch(Rectangle((-0.5, row - 0.5), cols, 1.0,
                               facecolor=(1.0, 0.93, 0.93, 0.78),
                               edgecolor="#dc2626", linewidth=1.0, linestyle="--"))
    for row in np.where(keep_rows)[0]:
        ax.add_patch(Rectangle((-0.5, row - 0.5), cols, 1.0,
                               facecolor="none", edgecolor="#2563eb",
                               linewidth=0.5, linestyle=":"))
    ax.set_title("Dense Statistical Window", fontsize=9.0, pad=3, fontweight="bold", color="#dc2626")
    ax.text(0.50, -0.10, "Boundary spans invalid rows", ha="center", va="top",
            fontsize=7.0, color="#dc2626", fontweight="bold", transform=ax.transAxes)


def draw_valid_calibration(ax):
    style_ax(ax)
    rgb = np.ones((rows, cols, 3))
    cmap = plt.get_cmap("GnBu")
    for r in range(rows):
        if keep_rows[r]:
            row_colors = cmap(0.25 + 0.70 * weight[r])[:, :3]
            rgb[r, :, :] = row_colors
        else:
            rgb[r, :, :] = np.array([0.97, 0.98, 0.99])
    ax.imshow(rgb, aspect="equal", interpolation="nearest")
    for row in np.where(pruned_rows)[0]:
        ax.add_patch(Rectangle((-0.5, row - 0.5), cols, 1.0,
                               facecolor="none", edgecolor="#cbd5e1", linewidth=0.6))
    ax.set_title(r"Valid Subset Calibration $W_l^{valid}$", fontsize=9.0, pad=3, fontweight="bold", color="#2563eb")
    ax.text(0.50, -0.10, "Calibrate only valid dims", ha="center", va="top",
            fontsize=7.0, color="#2563eb", fontweight="bold", transform=ax.transAxes)


def draw_uniform_quant(ax):
    style_ax(ax)
    x = np.arange(len(act_vals))
    colors = np.where(outlier_mask, "#fca5a5", "#cbd5e1")
    ax.bar(x, np.full_like(act_vals, 0.72), color=colors, width=0.72, edgecolor="white", linewidth=0.3)
    for i, is_out in enumerate(outlier_mask):
        if is_out:
            ax.add_patch(Rectangle((i - 0.36, 0), 0.72, 0.72,
                                   facecolor="none", edgecolor="#dc2626",
                                   linewidth=1.0, linestyle="--", zorder=5))
    ax.set_xlim(-0.6, len(act_vals) - 0.4)
    ax.set_ylim(0, 0.95)
    ax.set_title("Uniform 4-bit", fontsize=9.0, pad=3, fontweight="bold", color="#dc2626")
    ax.text(0.50, 0.85, "Outlier dims unprotected!", ha="center", va="center",
            fontsize=7.0, fontweight="bold", color="#dc2626", transform=ax.transAxes)


def draw_mixed_quant(ax):
    style_ax(ax)
    x = np.arange(len(act_vals))
    bit_heights = np.where(outlier_mask, 0.90, 0.68)
    colors = np.where(outlier_mask, "#f59e0b", "#93c5fd")
    ax.bar(x, bit_heights, color=colors, width=0.72, edgecolor="white", linewidth=0.3)
    for i, is_out in enumerate(outlier_mask):
        if is_out:
            ax.text(i, 0.93, "FP16", ha="center", va="bottom",
                    fontsize=5.5, fontweight="bold", color="#92400e")
    ax.set_xlim(-0.6, len(act_vals) - 0.4)
    ax.set_ylim(0, 1.05)
    ax.set_title("Mixed-Precision Protection", fontsize=9.0, pad=3, fontweight="bold", color="#16a34a")
    ax.text(0.50, -0.10, "1%FP16 + 99%4-bit", ha="center", va="top",
            fontsize=7.0, color="#16a34a", fontweight="bold", transform=ax.transAxes)


canvas.add_patch(
    FancyBboxPatch(
        (0.03, 0.04), 0.94, 0.84,
        boxstyle="round,pad=0.005,rounding_size=0.018",
        linewidth=1.0, edgecolor="#e2e8f0", facecolor="white",
        transform=canvas.transAxes,
    )
)

canvas.add_patch(
    FancyBboxPatch(
        (0.22, 0.88), 0.56, 0.05,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#0f172a", facecolor="#f8fafc",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.905, "Dynamic Mask-Guided Mixed-Precision Quantization Mechanism", size=10.0, weight="bold", color="#0f172a")

canvas.add_patch(
    FancyBboxPatch(
        (0.03, 0.88), 0.17, 0.05,
        boxstyle="round,pad=0.003,rounding_size=0.008",
        linewidth=0.8, edgecolor="#93c5fd", facecolor="#dbeafe",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.115, 0.905, "Signal Source", size=8.5, weight="bold", color="#1d4ed8")

canvas.add_patch(
    FancyBboxPatch(
        (0.35, 0.52), 0.62, 0.32,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#fecaca", facecolor="#fff5f5",
        transform=canvas.transAxes, zorder=3,
    )
)
label(0.66, 0.855, "Conventional: Dense Calibration + Uniform Low-Bit", size=8.5, weight="bold", color="#dc2626")

canvas.add_patch(
    FancyBboxPatch(
        (0.35, 0.12), 0.62, 0.36,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#bfdbfe", facecolor="#f0f7ff",
        transform=canvas.transAxes, zorder=3,
    )
)
label(0.66, 0.495, "Ours: Valid Subset Calibration + Mixed-Precision Protection", size=8.5, weight="bold", color="#2563eb")

ax_mask = fig.add_axes([0.06, 0.55, 0.12, 0.28])
draw_mask_signal(ax_mask)
ax_signal = fig.add_axes([0.06, 0.16, 0.22, 0.30])
draw_sensitivity_signal(ax_signal)

ax_dense = fig.add_axes([0.40, 0.57, 0.20, 0.22])
draw_dense_calibration(ax_dense)
ax_uniform = fig.add_axes([0.70, 0.57, 0.20, 0.22])
draw_uniform_quant(ax_uniform)

ax_valid = fig.add_axes([0.40, 0.17, 0.20, 0.22])
draw_valid_calibration(ax_valid)
ax_mixed = fig.add_axes([0.70, 0.17, 0.20, 0.22])
draw_mixed_quant(ax_mixed)

arrow(0.20, 0.70, 0.37, 0.70, color="#2563eb", lw=2.0, scale=14)
label(0.28, 0.74, "Mask", size=7.0, weight="bold", color="#2563eb")

arrow(0.20, 0.32, 0.37, 0.32, color="#2563eb", lw=2.0, scale=14)
label(0.32, 0.36, "Sensitivity", size=7.0, weight="bold", color="#2563eb")

arrow(0.20, 0.65, 0.37, 0.35, color="#94a3b8", lw=1.5, scale=12)
arrow(0.20, 0.38, 0.37, 0.62, color="#94a3b8", lw=1.5, scale=12)

arrow(0.62, 0.68, 0.68, 0.68, color="#dc2626", lw=1.8, scale=13)
arrow(0.62, 0.26, 0.68, 0.26, color="#16a34a", lw=1.8, scale=13)

chip(0.40, 0.82, 0.18, 0.035, "Stats span invalid rows", "#fee2e2", "#fca5a5", fontsize=7.2, color="#991b1b")
chip(0.72, 0.82, 0.14, 0.035, "Outliers unprotected", "#fee2e2", "#fca5a5", fontsize=7.2, color="#991b1b")
chip(0.40, 0.44, 0.18, 0.035, r"Calibrate $W_l^{valid}$ only", "#dbeafe", "#93c5fd", fontsize=7.2, color="#1d4ed8")
chip(0.72, 0.44, 0.18, 0.035, "Sensitive dims FP16", "#fef3c7", "#f59e0b", fontsize=7.2, color="#92400e")

label(0.50, 0.07, "Mask-guided calibration + Mixed-precision protection → Precise quantization, zero loss on critical dims",
      size=8.0, color="#1e40af", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_2_mechanism_try.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_2_mechanism_try.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_2_mechanism_try.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
