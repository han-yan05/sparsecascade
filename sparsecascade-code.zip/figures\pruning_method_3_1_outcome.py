from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
from matplotlib.colors import LinearSegmentedColormap

np.random.seed(11)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(9.0, 4.2), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.2, weight="normal", color="#334155", ha="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va="center", zorder=31,
    )


def arrow(x1, y1, x2, y2, lw=1.8, color="#475569", scale=15):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>",
            mutation_scale=scale, linewidth=lw, color=color,
            transform=canvas.transAxes, zorder=30,
        )
    )


def chip(x, y, w, h, text, facecolor, edgecolor, fontsize=8.1):
    canvas.add_patch(
        FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.003,rounding_size=0.01",
            transform=canvas.transAxes,
            facecolor=facecolor, edgecolor=edgecolor,
            linewidth=0.9, zorder=30,
        )
    )
    canvas.text(
        x + w / 2, y + h / 2, text,
        transform=canvas.transAxes,
        ha="center", va="center",
        fontsize=fontsize, fontweight="bold", color="#1f2937", zorder=31,
    )


def clean_ax(ax):
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def importance_color(val):
    if val >= 0.80:
        return "#dc2626"
    elif val >= 0.60:
        return "#f97316"
    elif val >= 0.45:
        return "#eab308"
    else:
        return "#94a3b8"


def build_importance_map(lengths, n_cols=12):
    rng = np.random.default_rng(11)
    base = rng.uniform(0.10, 0.22, size=(len(lengths), n_cols))
    for i, keep in enumerate(lengths):
        keep_count = max(2, int(np.round(n_cols * keep)))
        hotspot = np.sort(rng.choice(n_cols, size=keep_count, replace=False))
        base[i, hotspot] += rng.uniform(0.42, 0.68, size=len(hotspot))
        for idx in hotspot:
            if idx - 1 >= 0:
                base[i, idx - 1] += 0.10
            if idx + 1 < n_cols:
                base[i, idx + 1] += 0.10
        base[i] += keep * 0.20
    base = (base - base.min()) / (base.max() - base.min() + 1e-9)
    return base


def draw_importance_heatmap(ax, importance_map, title):
    clean_ax(ax)
    cmap = LinearSegmentedColormap.from_list(
        "importance_map",
        ["#f7fbff", "#d6e9c6", "#7fcdbb", "#41b6c4", "#225ea8", "#0b2c6b"],
    )
    ax.imshow(importance_map, aspect="equal", cmap=cmap, interpolation="nearest", vmin=0, vmax=1)
    ax.set_title(title, fontsize=9.5, pad=5, fontweight="bold")
    ax.set_yticks(np.arange(importance_map.shape[0]))
    ax.set_yticklabels([f"L{i}" for i in range(1, importance_map.shape[0] + 1)], fontsize=6.8, color="#64748b")
    ax.set_xticks([])
    for y in np.arange(-0.5, importance_map.shape[0], 1):
        ax.axhline(y, color="white", linewidth=0.7, alpha=0.90)
    for x in np.arange(-0.5, importance_map.shape[1], 1):
        ax.axvline(x, color="white", linewidth=0.7, alpha=0.90)
    ax.add_patch(Rectangle(
        (-0.5, -0.5), importance_map.shape[1], importance_map.shape[0],
        fill=False, edgecolor="#cbd5e1", linewidth=0.8, zorder=4,
    ))

    from matplotlib.colorbar import ColorbarBase
    from matplotlib.colors import Normalize
    cbar_ax = ax.inset_axes([0.0, -0.18, 1.0, 0.05])
    cb = ColorbarBase(cbar_ax, cmap=cmap, norm=Normalize(0, 1), orientation="horizontal")
    cb.set_ticks([0, 0.5, 1])
    cb.set_ticklabels(["Low", "", "High"])
    cb.ax.tick_params(labelsize=6.0, length=2, pad=1, colors="#64748b")
    cb.outline.set_edgecolor("#94a3b8")
    cb.outline.set_linewidth(0.5)
    cbar_ax.set_title("Importance", fontsize=6.0, color="#64748b", fontweight="bold", pad=2)


def draw_colored_topology(ax, lengths, importance_values, title, show_annotations=True):
    ax.set_xlim(-0.15, 1.25)
    ax.set_ylim(-0.1, len(lengths) + 0.3)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    for idx, (length, imp) in enumerate(zip(lengths[::-1], importance_values[::-1])):
        layer_id = len(lengths) - idx
        y = idx + 0.18
        row_color = importance_color(imp)
        ax.text(-0.10, y + 0.22, f"L{layer_id}", fontsize=6.5, color="#64748b", va="center")
        ax.add_patch(Rectangle((0.10, y), 0.80, 0.44,
                               facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=0.7))
        fill_w = 0.80 * length
        n_cells = max(4, int(24 * length))
        cell_w = fill_w / n_cells
        for j in range(n_cells):
            ax.add_patch(Rectangle(
                (0.10 + j * cell_w, y), cell_w - 0.002, 0.44,
                facecolor=row_color, edgecolor=row_color, linewidth=0.25, alpha=0.85,
            ))
        ax.plot([0.10 + fill_w, 0.90], [y + 0.22, y + 0.22],
                color="#cbd5e1", linewidth=1.0, linestyle="--")
        if show_annotations:
            pct = int(length * 100)
            ax.text(0.93, y + 0.22, f"{pct}%", va="center", fontsize=6.5,
                    color=row_color, fontweight="bold")
            if imp >= 0.80 and length >= 0.85:
                ax.text(1.08, y + 0.22, "Protected", va="center", fontsize=5.5,
                        color="#16a34a", fontweight="bold")
            elif imp < 0.45 and length <= 0.60:
                ax.text(1.08, y + 0.22, "Pruned", va="center", fontsize=5.5,
                        color="#6b7280", fontweight="bold")
    ax.set_title(title, fontsize=9.5, pad=5, fontweight="bold")


def draw_uniform_topology(ax, lengths, importance_values, title):
    ax.set_xlim(-0.15, 1.05)
    ax.set_ylim(-0.1, len(lengths) + 0.3)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    for idx, (length, imp) in enumerate(zip(lengths[::-1], importance_values[::-1])):
        layer_id = len(lengths) - idx
        y = idx + 0.18
        row_color = importance_color(imp)
        ax.text(-0.10, y + 0.22, f"L{layer_id}", fontsize=6.5, color="#64748b", va="center")
        ax.add_patch(Rectangle((0.10, y), 0.80, 0.44,
                               facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=0.7))
        fill_w = 0.80 * length
        n_cells = max(4, int(24 * length))
        cell_w = fill_w / n_cells
        for j in range(n_cells):
            ax.add_patch(Rectangle(
                (0.10 + j * cell_w, y), cell_w - 0.002, 0.44,
                facecolor="#cbd5e1", edgecolor="#cbd5e1", linewidth=0.25, alpha=0.85,
            ))
        ax.plot([0.10 + fill_w, 0.90], [y + 0.22, y + 0.22],
                color="#cbd5e1", linewidth=1.0, linestyle="--")
        if imp >= 0.80:
            ax.add_patch(Rectangle((0.10, y), 0.80, 0.44,
                                   facecolor="none", edgecolor="#dc2626",
                                   linewidth=1.0, linestyle="--"))
            ax.text(0.93, y + 0.22, "!", va="center", fontsize=8.0,
                    color="#dc2626", fontweight="bold")
    ax.set_title(title, fontsize=9.5, pad=5, fontweight="bold")


layer_importance = np.array([0.92, 0.61, 0.84, 0.38, 0.88, 0.47, 0.73, 0.29])
layer_keep = np.array([0.95, 0.72, 0.84, 0.58, 0.90, 0.67, 0.80, 0.52])
uniform_keep = np.full(8, 0.70)
importance_map = build_importance_map(layer_keep, n_cols=12)

canvas.add_patch(
    FancyBboxPatch(
        (0.03, 0.06), 0.94, 0.78,
        boxstyle="round,pad=0.004,rounding_size=0.018",
        linewidth=1.0, edgecolor="#bfdbfe", facecolor="#f8fbff",
        transform=canvas.transAxes,
    )
)

canvas.add_patch(
    FancyBboxPatch(
        (0.25, 0.84), 0.50, 0.05,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#2563eb", facecolor="#eff6ff",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.865, "Outcome: Adaptive Retention Ratio Allocation", size=9.5, weight="bold", color="#2563eb")

chip(0.30, 0.79, 0.40, 0.04, r"$s_l[i]=\|W_l[i,:]\|_2 \cdot \|Act_l[:,i]\|_2$", "#e0f2fe", "#38bdf8", fontsize=8.2)

ax_import = fig.add_axes([0.06, 0.16, 0.18, 0.50])
draw_importance_heatmap(ax_import, importance_map, "Layer-Dim Importance")

ax_uniform = fig.add_axes([0.32, 0.16, 0.24, 0.50])
draw_uniform_topology(ax_uniform, uniform_keep, layer_importance, "Uniform 30% Pruning")

ax_adapt = fig.add_axes([0.65, 0.16, 0.24, 0.50])
draw_colored_topology(ax_adapt, layer_keep, layer_importance, "Adaptive 30% Pruning")

arrow(0.26, 0.42, 0.30, 0.42, lw=2.0, scale=14, color="#475569")
label(0.28, 0.50, "Uniform\nRetention", size=6.0, weight="bold", color="#64748b")

canvas.add_patch(FancyArrowPatch(
    (0.57, 0.42), (0.63, 0.42),
    arrowstyle="-|>",
    mutation_scale=16, linewidth=2.5, color="#16a34a",
    transform=canvas.transAxes, zorder=30,
))

canvas.add_patch(
    FancyBboxPatch(
        (0.58, 0.52), 0.05, 0.04,
        boxstyle="round,pad=0.002,rounding_size=0.008",
        linewidth=0.6, edgecolor="#86efac", facecolor="#f0fdf4",
        transform=canvas.transAxes, zorder=12,
    )
)
canvas.text(0.605, 0.54, "Better", transform=canvas.transAxes,
            ha="center", va="center", fontsize=6.5, fontweight="bold", color="#16a34a", zorder=13)
label(0.605, 0.60, "Joint Score\nDriven Alloc.", size=6.5, weight="bold", color="#2563eb")

label(0.50, 0.08, "Adaptive pruning: high-imp. layers protected, low-imp. layers pruned → Non-uniform sparse structure",
      size=8.0, color="#1e40af", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_1_outcome.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_outcome.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_outcome.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
