from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

np.random.seed(11)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(8.5, 5.0), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.5, weight="normal", color="#334155", ha="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va="center", zorder=30,
    )


def arrow(x1, y1, x2, y2, lw=1.8, color="#475569", scale=14):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>",
            mutation_scale=scale, linewidth=lw, color=color,
            transform=canvas.transAxes, zorder=30,
        )
    )


def importance_color(val):
    if val >= 0.80:
        return "#dc2626"
    elif val >= 0.60:
        return "#f97316"
    elif val >= 0.45:
        return "#eab308"
    else:
        return "#94a3b8"


def draw_importance_bars(ax, values):
    ax.barh(
        np.arange(len(values)), values,
        color=[importance_color(v) for v in values],
        height=0.78, edgecolor="white", linewidth=0.5,
    )
    ax.invert_yaxis()
    ax.set_xlim(0, 1.05)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    for i, v in enumerate(values):
        ax.text(v + 0.02, i, f"{v:.2f}", va="center", fontsize=7.0,
                color=importance_color(v), fontweight="bold")
    ax.set_title("Layer Importance Distribution", fontsize=9.5, pad=5, fontweight="bold")
    ax.axvline(values.mean(), color="#7f1d1d", linewidth=1.5, linestyle="--", alpha=0.7)
    ax.text(values.mean() + 0.02, len(values) - 0.3, f"Mean={values.mean():.2f}",
            fontsize=6.5, color="#7f1d1d", fontweight="bold")


def draw_mismatch_topology(ax, lengths, importance_values):
    ax.set_xlim(-0.15, 1.15)
    ax.set_ylim(-0.1, len(lengths) + 0.3)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    for idx, (length, imp) in enumerate(zip(lengths[::-1], importance_values[::-1])):
        layer_id = len(lengths) - idx
        y = idx + 0.18
        row_color = importance_color(imp)
        ax.text(-0.10, y + 0.22, f"L{layer_id}", fontsize=6.5, color="#64748b", va="center")
        ax.add_patch(Rectangle((0.10, y), 0.80, 0.44,
                               facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=0.7))
        fill_w = 0.80 * length
        n_cells = max(4, int(24 * length))
        cell_w = fill_w / n_cells
        for j in range(n_cells):
            ax.add_patch(Rectangle(
                (0.10 + j * cell_w, y), cell_w - 0.002, 0.44,
                facecolor=row_color, edgecolor=row_color, linewidth=0.25, alpha=0.85,
            ))
        ax.plot([0.10 + fill_w, 0.90], [y + 0.22, y + 0.22],
                color="#cbd5e1", linewidth=1.0, linestyle="--")
        if imp >= 0.80 and length < 0.85:
            ax.text(0.95, y + 0.22, "Over-pruned!", va="center", fontsize=6.0,
                    color="#dc2626", fontweight="bold")
            ax.add_patch(Rectangle((0.10, y), 0.80, 0.44,
                                   facecolor="none", edgecolor="#dc2626",
                                   linewidth=1.2, linestyle="--"))
        elif imp < 0.45 and length > 0.60:
            ax.text(0.95, y + 0.22, "Redundant", va="center", fontsize=6.0,
                    color="#94a3b8", fontweight="bold")
    ax.set_title("Uniform 30% Pruning (Retain=70%)", fontsize=9.5, pad=5, fontweight="bold")


layer_importance = np.array([0.92, 0.61, 0.84, 0.38, 0.88, 0.47, 0.73, 0.29])
uniform_keep = np.full(8, 0.70)

canvas.add_patch(
    FancyBboxPatch(
        (0.04, 0.12), 0.92, 0.72,
        boxstyle="round,pad=0.004,rounding_size=0.018",
        linewidth=1.0, edgecolor="#fecaca", facecolor="#fffafa",
        transform=canvas.transAxes,
    )
)

canvas.add_patch(
    FancyBboxPatch(
        (0.2, 0.82), 0.6, 0.045,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#dc2626", facecolor="#fef2f2",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.843, "Problem: Uniform Retention Ignores Inter-Layer Heterogeneity", size=9.0, weight="bold", color="#dc2626")

ax_import = fig.add_axes([0.10, 0.22, 0.28, 0.52])
draw_importance_bars(ax_import, layer_importance)

ax_uniform = fig.add_axes([0.56, 0.22, 0.34, 0.52])
draw_mismatch_topology(ax_uniform, uniform_keep, layer_importance)

arrow(0.42, 0.48, 0.53, 0.48, lw=2.2, scale=16, color="#dc2626")

canvas.add_patch(
    FancyBboxPatch(
        (0.10, 0.90), 0.12, 0.04,
        boxstyle="round,pad=0.003,rounding_size=0.008",
        linewidth=0.6, edgecolor="#e5e7eb", facecolor="white",
        transform=canvas.transAxes, zorder=5,
    )
)
items = [
    ("High Imp.", "#dc2626", 0.13),
    ("Mid Imp.", "#f97316", 0.27),
    ("Low Imp.", "#94a3b8", 0.41),
]
for text, color, x_pos in items:
    canvas.add_patch(Rectangle(
        (x_pos, 0.905), 0.015, 0.025,
        facecolor=color, edgecolor="none",
        transform=canvas.transAxes, zorder=6,
    ))
    canvas.text(
        x_pos + 0.02, 0.918, text,
        transform=canvas.transAxes,
        fontsize=7.0, color="#475569", ha="left", va="center", zorder=6,
    )

label(0.50, 0.15, "High-imp. layers over-pruned, low-imp. layers redundant → Non-uniform sparsity is better",
      size=8.0, color="#7f1d1d", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_1_problem.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_problem.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_problem.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
