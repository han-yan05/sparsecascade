import torch
import os
import sys

# REMOVED: Import from Step 1 code. 
# We MUST use standard transformers Llama to ensure physical pruning works correctly on standard nn.Linear layers.
# The custom Step 1 model might have wrappers or different structures that block our pruning logic.

from transformers import (
    AutoTokenizer,
    AutoConfig,
    AutoModelForCausalLM,
    LlamaForCausalLM # Explicitly import standard class
)
import argparse
import torch.nn as nn

from datasets import load_dataset
import functools
from tqdm import tqdm
from datautils import get_loaders

# Import Pruning Utils
from utils import load_prune_info, physical_prune_attn, physical_prune_mlp

# import pdb



def get_act_scales(model, dataloader, num_samples=128):
    model.eval()
    device = next(model.parameters()).device
    act_scales = {}

    def stat_tensor(name, tensor): #tensor 1*2048*4096
        hidden_dim = tensor.shape[-1] 
        tensor = tensor.view(-1, hidden_dim).abs().detach() #2048*4096
        comming_max = torch.max(tensor, dim=0)[0].float().cpu() #4096
        if name in act_scales:
            act_scales[name] = torch.max(act_scales[name], comming_max)
        else:
            act_scales[name] = comming_max

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            if "down_proj" in name or "gate_proj" in name:
                print(f"HOOK REGISTERED: {name} | in: {m.in_features} | out: {m.out_features}")
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name)))

    for i in tqdm(range(num_samples)):
        model(dataloader[i][0].to(device))

    for h in hooks:
        h.remove()

    return act_scales 

def get_act_shifts(model, dataloader, num_samples=128):
    model.eval()
    device = next(model.parameters()).device
    act_shifts = {}

    def stat_tensor(name, tensor):
        hidden_dim = tensor.shape[-1]
        tensor = tensor.view(-1, hidden_dim).detach()
        comming_max = torch.max(tensor, dim=0)[0].float().cpu()
        comming_min = torch.min(tensor, dim=0)[0].float().cpu()
        if name in act_shifts:
            act_shifts[name] = 0.99*act_shifts[name] + 0.01 *((comming_max+comming_min)/2)
        else:
            act_shifts[name] = (comming_max+comming_min)/2

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name))
            )

    for i in tqdm(range(num_samples)):
        model(dataloader[i][0].to(device))


    for h in hooks:
        h.remove()

    return act_shifts




def build_model_and_tokenizer(model_name, prune_info_path=None):
    kwargs = {"torch_dtype": torch.float16, "device_map": "auto"}
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=False)
    
    if prune_info_path:
        print(f"Loading with Prune Info from {prune_info_path}...")
        config = AutoConfig.from_pretrained(model_name, trust_remote_code=True)
        
        # Override config to use eager attention
        if hasattr(config, "attn_implementation"):
            print(f"Forcing attn_implementation='eager' (was {config.attn_implementation}) for ragged model compatibility.")
            config.attn_implementation = "eager"
        elif hasattr(config, "_attn_implementation"):
             config._attn_implementation = "eager"
             
        # 1. Initialize Dense Model (CPU) - FORCE Standard HF Llama
        from transformers import LlamaForCausalLM as HFLlamaForCausalLM
        try:
            print("Initializing custom LlamaForCausalLM (without weights)...")
            model = HFLlamaForCausalLM(config)
        except Exception as e:
            print(f"Failed to init LlamaForCausalLM: {e}. Fallback to AutoModel.")
            model = AutoModelForCausalLM.from_config(config)
            
        model.to(dtype=torch.float16)
        
        # 2. Apply Physical Pruning
        prune_info = load_prune_info(prune_info_path)
        physical_prune_mlp(model, prune_info, "cpu")
        physical_prune_attn(model, prune_info, "cpu")
        
        # 3. Load Weights
        print(f"Loading weights from {model_name}...")
        # Try finding the weight file
        weight_path = os.path.join(model_name, "pytorch_model.bin")
        if not os.path.exists(weight_path):
             import glob
             bins = list(glob.glob(os.path.join(model_name, "*.bin")))
             if bins:
                 weight_path = bins[0] # Take the first bin
        
        if os.path.exists(weight_path):
            state_dict = torch.load(weight_path, map_location="cpu")
            # Strict=True ensures our pruning matched the saved weights
            try:
                model.load_state_dict(state_dict, strict=True)
                print("Weights loaded successfully with Strict=True!")
            except Exception as e:
                print(f"CRITICAL ERROR: Strict loading failed: {e}")
                print("Fallback: Checkpoint might be Dense. Trying to load into Dense model then Prune...")
                
                try:
                    # 1. Re-init Dense
                    # Ensure Eager Attention Config is passed correctly
                    if hasattr(config, "attn_implementation"): config.attn_implementation = "eager"
                    if hasattr(config, "_attn_implementation"): config._attn_implementation = "eager"
                    
                    model = HFLlamaForCausalLM(config)
                    model.to(dtype=torch.float16)
                    
                    # Verify Attention Class Type
                    if hasattr(model.model.layers[0], "self_attn"):
                         attn_type = type(model.model.layers[0].self_attn)
                         print(f"DEBUG: Attention Class Type: {attn_type}")
                         
                    # 2. Load Dense Weights
                    model.load_state_dict(state_dict, strict=False)
                    print("Dense weights loaded. Now applying physical pruning...")
                    # 3. Prune
                    physical_prune_mlp(model, prune_info, "cpu")
                    physical_prune_attn(model, prune_info, "cpu")
                    print("Pruning applied successfully.")
                    
                    if hasattr(model.config, "attn_implementation"):
                         print(f"Final Attention Implementation: {model.config.attn_implementation}")

                except Exception as e2:
                    print(f"Fallback failed: {e2}")
                    raise e
        else:
            print(f"Warning: Weight file {weight_path} not found. Model initialized randomly (Garbage Scales!)")
            
        # 4. Move to GPU
        print("Moving model to GPU...")
        model.cuda()
        
    else:
        # Standard loading
        print("Loading standard model (no prune_info)...")
        try:
            model = LlamaForCausalLM.from_pretrained(model_name, **kwargs)
        except Exception as e:
            print(f"Error loading with custom LlamaForCausalLM: {e}")
            print("Falling back to AutoModelForCausalLM (may fail if model is pruned)")
            model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)
        
    return model, tokenizer

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str,help='model name')
    parser.add_argument('--scales-output-path', type=str, default='./act_scales/',
                        help='where to save the act scales')
    parser.add_argument('--shifts-output-path', type=str, default='./act_shifts/',
                        help='where to save the act shifts')
    parser.add_argument("--calib_dataset",type=str,default="wikitext2",
        choices=["wikitext2", "ptb", "c4", "mix","pile"],
        help="Where to extract calibration data from.",)
    parser.add_argument('--num-samples', type=int, default=128)
    parser.add_argument('--seq-len', type=int, default=2048)
    parser.add_argument("--seed", type=int, default=2, help="Seed for sampling the calibration data.")
    parser.add_argument("--prune_info_path", type=str, default=None, help="Path to prune_info.pt for loading ragged models")
    args = parser.parse_args()
    return args


@torch.no_grad()
def main():
    args = parse_args()
    model, tokenizer = build_model_and_tokenizer(args.model, args.prune_info_path)
    dataloader, _ = get_loaders(
    args.calib_dataset,
    nsamples=args.num_samples,
    seed=args.seed,
    model=args.model,
    seqlen=args.seq_len,
    )
    
    # Robustly get model basename
    args.net = os.path.basename(args.model.rstrip('/'))
    if not args.net: # handle root path edge case
        args.net = "model"
        
    print(f"Generating act stats for {args.net}...")
    
    act_scales = get_act_scales(model, dataloader,args.num_samples)
    save_path = os.path.join(args.scales_output_path,f'{args.net}.pt')
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    torch.save(act_scales, save_path)
    print(f"Saved act_scales to {save_path}")

    act_shifts = get_act_shifts(model, dataloader,args.num_samples)
    save_path = os.path.join(args.shifts_output_path,f'{args.net}.pt')
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    torch.save(act_shifts, save_path)
    print(f"Saved act_shifts to {save_path}")


if __name__ == '__main__':
    main()
