import torch
# from torch._six import inf
from math import inf
import logging
from termcolor import colored
import sys
import os
import time
import re
import torch.nn as nn

def ampscaler_get_grad_norm(parameters, norm_type: float = 2.0) -> torch.Tensor:
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = [p for p in parameters if p.grad is not None]
    norm_type = float(norm_type)
    if len(parameters) == 0:
        return torch.tensor(0.)
    device = parameters[0].grad.device
    if norm_type == inf:
        total_norm = max(p.grad.detach().abs().max().to(device) for p in parameters)
    else:
        total_norm = torch.norm(torch.stack([torch.norm(p.grad.detach(),
                                                        norm_type).to(device) for p in parameters]), norm_type)
    return total_norm

class NativeScalerWithGradNormCount:
    state_dict_key = "amp_scaler"

    def __init__(self):
        self._scaler = torch.cuda.amp.GradScaler()

    def __call__(self, loss, optimizer, clip_grad=None, parameters=None, create_graph=False, update_grad=True,retain_graph=False):
        self._scaler.scale(loss).backward(create_graph=create_graph, retain_graph=retain_graph)
        if update_grad:
            if clip_grad is not None:
                assert parameters is not None
                self._scaler.unscale_(optimizer)  # unscale the gradients of optimizer's assigned params in-place
                norm = torch.nn.utils.clip_grad_norm_(parameters, clip_grad)
            else:
                self._scaler.unscale_(optimizer)
                norm = ampscaler_get_grad_norm(parameters)
            self._scaler.step(optimizer)
            self._scaler.update()
        else:
            norm = None
        return norm

    def state_dict(self):
        return self._scaler.state_dict()

    def load_state_dict(self, state_dict):
        self._scaler.load_state_dict(state_dict)


def create_logger(output_dir, dist_rank=0, name=''):
    # create logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    # create formatter
    fmt = '[%(asctime)s %(name)s] (%(filename)s %(lineno)d): %(levelname)s %(message)s'
    color_fmt = colored('[%(asctime)s %(name)s]', 'green') + \
                colored('(%(filename)s %(lineno)d)', 'yellow') + ': %(levelname)s %(message)s'

    # create console handlers for master process
    if dist_rank == 0:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(
            logging.Formatter(fmt=color_fmt, datefmt='%Y-%m-%d %H:%M:%S'))
        logger.addHandler(console_handler)

    # create file handlers
    file_handler = logging.FileHandler(os.path.join(output_dir, f'log_rank{dist_rank}_{int(time.time())}.txt'), mode='a')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(fmt=fmt, datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(file_handler)

    return logger

# ==========================================
# Pruning Utilities (Ported from recycle.py)
# ==========================================

def load_prune_info(prune_info_path):
    print(f"Loading prune info from {prune_info_path}...")
    try:
        # Load directly to CPU to avoid GPU OOM or device mismatch
        info = torch.load(prune_info_path, map_location="cpu")
        
        # Basic validation
        if not isinstance(info, dict):
            raise ValueError(f"prune_info must be a dict, got {type(info)}")
        
        # Check if empty
        if len(info) == 0:
            print("Loaded prune_info is empty!")
        else:
            # Debug: print first 5 keys to help diagnosis
            keys = list(info.keys())[:5]
            print(f"Prune info loaded. Sample keys: {keys}")
            
        return info
    except Exception as e:
        print(f"Failed to load prune_info: {e}")
        return {}

def get_mask_for_layer(prune_info, layer_idx, layer_name, param_name, shape, device):
    mask = None
    
    # Strategy 1: Nested dict lookup (e.g. prune_info["layer_0"]["self_attn.q_proj"])
    layer_key = f"layer_{layer_idx}"
    if layer_key in prune_info:
        layer_dict = prune_info[layer_key]
        
        if "mlp" in layer_name and "hard_mlp_mask" in layer_dict:
             mask = layer_dict["hard_mlp_mask"]
        elif "self_attn" in layer_name and "hard_attn_mask" in layer_dict:
             mask = layer_dict["hard_attn_mask"]
        else:
            candidates_inner = [
                f"{layer_name}.{param_name}",
                f"{param_name}" 
            ]
            
            for key in candidates_inner:
                if key in layer_dict:
                    mask = layer_dict[key]
                    break
                    
            if mask is None:
                 for k, v in layer_dict.items():
                     if layer_name == k or layer_name.endswith(k) or k.endswith(layer_name):
                         mask = v
                         break
                         
    # Strategy 2: Flat dict lookup
    if mask is None:
        candidates = [
            f"model.layers.{layer_idx}.{layer_name}.{param_name}",
            f"layers.{layer_idx}.{layer_name}.{param_name}",
            f"{layer_name}.{param_name}",
            f"model.layers.{layer_idx}.{layer_name}.{param_name}_mask",
            f"layers.{layer_idx}.{layer_name}.{param_name}_mask",
            f"layer_{layer_idx}", 
            f"layer_{layer_idx}.{param_name}", 
            f"layer_{layer_idx}.{layer_name}.{param_name}"
        ]
        
        for key in candidates:
            if key in prune_info:
                mask = prune_info[key]
                break
    
    # Strategy 3: Regex
    if mask is None:
        pattern = re.compile(f".*layers\\.{layer_idx}\\..*{re.escape(layer_name)}.*{re.escape(param_name)}.*")
        for k, v in prune_info.items():
            if isinstance(v, dict): continue 
            if pattern.match(k):
                mask = v
                break
                
    if mask is None:
        return None

    if isinstance(mask, dict):
        if "mlp" in layer_name and "hard_mlp_mask" in mask:
             mask = mask["hard_mlp_mask"]
        elif "self_attn" in layer_name and "hard_attn_mask" in mask:
             mask = mask["hard_attn_mask"]
        else:
             return None

    if mask.dim() == 1:
        if mask.shape[0] == 32 and (shape[0] == 4096 or shape[1] == 4096):
             mask = mask.repeat_interleave(128, dim=0) 
        elif mask.shape[0] == 32 and (shape[0] == 11008 or shape[1] == 11008):
             repeat_times = 11008 // 32
             mask = mask.repeat_interleave(repeat_times, dim=0) 
             
    if mask.dim() < len(shape):
        if mask.dim() == 1:
             if mask.shape[0] == shape[0]:
                 mask = mask.unsqueeze(1).expand(shape)
             elif mask.shape[0] == shape[1]:
                 mask = mask.unsqueeze(0).expand(shape)
             else:
                 return None
            
    if mask.shape != shape:
        return None
        
    return mask.to(device)

def print_stat(tensor, name):
    max_val = tensor.max().item()
    min_val = tensor.min().item()
    mean_val = tensor.mean().item()
    std_val = tensor.std().item()
    print(f"{name} | Mean: {mean_val:.4f} | Std: {std_val:.4f} | Max: {max_val:.4f} | Min: {min_val:.4f}")
    
    if torch.isnan(tensor).any() or torch.isinf(tensor).any():
        print(f"!!! CRITICAL: {name} contains NaN or Inf !!!")
    elif abs(max_val) > 100: # Threshold for suspicion
        print(f"!!! WARNING: {name} has large values > 100 !!!")

def get_layers(model):
    if hasattr(model, "model"):
        if hasattr(model.model, "layers"):
            return model.model.layers
    
    if hasattr(model, "layers"):
        return model.layers
        
    if hasattr(model, "transformer"):
        if hasattr(model.transformer, "h"):
            return model.transformer.h
        if hasattr(model.transformer, "layers"):
            return model.transformer.layers
            
    for m in model.modules():
        if isinstance(m, nn.ModuleList) and len(m) > 1:
            if hasattr(m[0], "self_attn") or hasattr(m[0], "mlp") or hasattr(m[0], "attn"):
                return m
                
    raise ValueError("Could not find transformer layers in model structure.")

def physical_prune_attn(model, prune_info, device):
    print("Checking for physical pruning opportunities in Attention layers...")
    layers = get_layers(model)
    pruned_count = 0

    total_reduction = 0
    
    for i, layer in enumerate(layers):
        if not hasattr(layer, "self_attn"):
            continue
            
        attn = layer.self_attn
        if not hasattr(attn, "q_proj"): continue
        
        q = attn.q_proj
        k = attn.k_proj
        v = attn.v_proj
        o = attn.o_proj
        
        mask_q = get_mask_for_layer(prune_info, i, "self_attn.q_proj", "weight", q.weight.shape, device)
        
        if mask_q is None:
            continue
            
        row_alive = mask_q.sum(dim=1) > 0
        alive_indices = row_alive.nonzero().squeeze()
        
        if alive_indices.numel() == 0:
            print(f"Layer {i} Attn: All heads pruned? Skipping to avoid collapse.")
            continue
            
        original_dim = q.weight.shape[0]
        new_dim = alive_indices.numel()
        
        if new_dim < original_dim:
            print(f"Layer {i} Attn: Pruning head dimension {original_dim} -> {new_dim}")
            
            # CHECK MASK STRUCTURE
            head_dim = 128
            if new_dim % head_dim != 0:
                print(f"!!! CRITICAL WARNING: Pruned dim {new_dim} is not multiple of {head_dim}!")
            
            # Check if indices are contiguous blocks of 128
            # alive_indices should be like [0,1,..,127, 256,257,..,383]
            # Reshape to [num_heads, head_dim] and check if rows are all-0 or all-1
            mask_reshaped = row_alive.float().view(-1, head_dim)
            head_sums = mask_reshaped.sum(dim=1)
            is_structured = torch.all((head_sums == 0) | (head_sums == head_dim))
            if not is_structured:
                print(f"!!! CRITICAL ERROR: Mask is NOT structured by head! RoPE will fail!")
                print(f"Head sums: {head_sums}")
                # Fallback to Soft Pruning if mask is broken
                print("Falling back to Soft Pruning for this layer to avoid NaN.")
                mask_q_float = row_alive.to(dtype=q.weight.dtype, device=device).unsqueeze(1)
                q.weight.data *= mask_q_float
                if q.bias is not None: q.bias.data *= row_alive.to(dtype=q.bias.dtype, device=device)
                k.weight.data *= mask_q_float
                if k.bias is not None: k.bias.data *= row_alive.to(dtype=k.bias.dtype, device=device)
                v.weight.data *= mask_q_float
                if v.bias is not None: v.bias.data *= row_alive.to(dtype=v.bias.dtype, device=device)
                mask_o_float = row_alive.to(dtype=o.weight.dtype, device=device).unsqueeze(0)
                o.weight.data *= mask_o_float
                continue

            new_q = nn.Linear(q.in_features, new_dim, bias=q.bias is not None, device=device, dtype=q.weight.dtype)
            new_q.weight.data = q.weight.data[alive_indices, :]
            if q.bias is not None: new_q.bias.data = q.bias.data[alive_indices]
            attn.q_proj = new_q
            
            new_k = nn.Linear(k.in_features, new_dim, bias=k.bias is not None, device=device, dtype=k.weight.dtype)
            new_k.weight.data = k.weight.data[alive_indices, :]
            if k.bias is not None: new_k.bias.data = k.bias.data[alive_indices]
            attn.k_proj = new_k
            
            new_v = nn.Linear(v.in_features, new_dim, bias=v.bias is not None, device=device, dtype=v.weight.dtype)
            new_v.weight.data = v.weight.data[alive_indices, :]
            if v.bias is not None: new_v.bias.data = v.bias.data[alive_indices]
            attn.v_proj = new_v
            
            new_o = nn.Linear(new_dim, o.out_features, bias=o.bias is not None, device=device, dtype=o.weight.dtype)
            new_o.weight.data = o.weight.data[:, alive_indices]
            if o.bias is not None: new_o.bias.data = o.bias.data
            attn.o_proj = new_o
            
            if hasattr(attn, "head_dim"): head_dim = attn.head_dim
            elif hasattr(model.config, "head_dim"): head_dim = model.config.head_dim
            
            if new_dim % head_dim == 0:
                new_num_heads = new_dim // head_dim
                print(f"  -> Updating num_heads: {attn.num_heads} -> {new_num_heads} (head_dim={head_dim})")
                attn.num_heads = new_num_heads
                attn.hidden_size = new_dim
                if hasattr(attn, "num_key_value_heads"):
                    print(f"  -> Updating num_key_value_heads: {attn.num_key_value_heads} -> {new_num_heads}")
                    attn.num_key_value_heads = new_num_heads
            else:
                print(f"  -> WARNING: New dim {new_dim} not divisible by head_dim {head_dim}!")
            
            pruned_count += 1
            total_reduction += (original_dim - new_dim) * 3 + (original_dim - new_dim) 
            
    print(f"Physically pruned {pruned_count} Attention layers. Total param reduction: {total_reduction}")

def physical_prune_mlp(model, prune_info, device):
    print("Checking for physical pruning opportunities in MLPs...")
    
    layers = get_layers(model)
        
    pruned_count = 0
    total_reduction = 0
    
    for i, layer in enumerate(layers):
        if not hasattr(layer, "mlp"):
            continue
            
        mlp = layer.mlp
        if not hasattr(mlp, "gate_proj"): 
            continue
            
        gate = mlp.gate_proj
        up = mlp.up_proj
        down = mlp.down_proj
        
        mask_gate = get_mask_for_layer(prune_info, i, "mlp.gate_proj", "weight", gate.weight.shape, device)
        mask_up = get_mask_for_layer(prune_info, i, "mlp.up_proj", "weight", up.weight.shape, device)
        mask_down = get_mask_for_layer(prune_info, i, "mlp.down_proj", "weight", down.weight.shape, device)
        
        if mask_gate is None or mask_up is None or mask_down is None:
            continue
            
        gate_alive = mask_gate.sum(dim=1) > 0
        up_alive = mask_up.sum(dim=1) > 0
        down_alive = mask_down.sum(dim=0) > 0
        
        alive_indices = (gate_alive & up_alive & down_alive).nonzero().squeeze()
        
        original_inter_dim = gate.weight.shape[0]
        new_inter_dim = alive_indices.numel()
        
        if new_inter_dim < original_inter_dim:
            print(f"Layer {i} MLP: Pruning intermediate {original_inter_dim} -> {new_inter_dim}")
            
            new_gate = nn.Linear(gate.in_features, new_inter_dim, bias=gate.bias is not None, device=device, dtype=gate.weight.dtype)
            new_gate.weight.data = gate.weight.data[alive_indices, :]
            if gate.bias is not None: new_gate.bias.data = gate.bias.data[alive_indices]
            
            new_up = nn.Linear(up.in_features, new_inter_dim, bias=up.bias is not None, device=device, dtype=up.weight.dtype)
            new_up.weight.data = up.weight.data[alive_indices, :]
            if up.bias is not None: new_up.bias.data = up.bias.data[alive_indices]
            
            new_down = nn.Linear(new_inter_dim, down.out_features, bias=down.bias is not None, device=device, dtype=down.weight.dtype)
            new_down.weight.data = down.weight.data[:, alive_indices]
            if down.bias is not None: new_down.bias.data = down.bias.data
            
            mlp.gate_proj = new_gate
            mlp.up_proj = new_up
            mlp.down_proj = new_down
            
            # Explicitly set modules to ensure named_modules() picks them up
            if hasattr(mlp, "_modules"):
                mlp._modules["gate_proj"] = new_gate
                mlp._modules["up_proj"] = new_up
                mlp._modules["down_proj"] = new_down
            
            pruned_count += 1
            total_reduction += (original_inter_dim - new_inter_dim)
            
    print(f"Physically pruned {pruned_count} MLP layers. Total neuron reduction: {total_reduction}")
