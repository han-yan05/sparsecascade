
import datasets
try:
    print("Attempting to load regisss/piqa...")
    ds = datasets.load_dataset("regisss/piqa", trust_remote_code=False)
    print("Successfully loaded regisss/piqa")
    print(ds)
except Exception as e:
    print(f"Failed to load regisss/piqa: {e}")
