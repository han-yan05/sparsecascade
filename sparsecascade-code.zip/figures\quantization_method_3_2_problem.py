from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle, Circle

np.random.seed(17)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(8.5, 5.0), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.5, weight="normal", color="#334155", ha="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va="center", zorder=40,
    )


def arrow(x1, y1, x2, y2, lw=1.8, color="#475569", scale=14):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>",
            mutation_scale=scale, linewidth=lw, color=color,
            transform=canvas.transAxes, zorder=32,
        )
    )


rows, cols = 16, 14
matrix = np.abs(np.random.randn(rows, cols))
rng_act = np.random.default_rng(17)
n_dims = 24
act_vals = rng_act.exponential(scale=0.20, size=n_dims)
outlier_indices = rng_act.choice(n_dims, size=max(1, int(n_dims * 0.10)), replace=False)
act_vals[outlier_indices] += rng_act.uniform(0.45, 0.65, size=len(outlier_indices))
threshold = np.quantile(act_vals, 0.90)
outlier_mask = act_vals >= threshold
sparse_lengths = np.array([0.86, 0.78, 0.61, 0.74, 0.69, 0.56, 0.72, 0.63])


def build_sparse_pixel_mask(shape, lengths):
    mask = np.ones(shape, dtype=bool)
    groups = np.array_split(np.arange(shape[0]), len(lengths))
    rng = np.random.default_rng(23)
    for group, keep_ratio in zip(groups, lengths):
        prune_ratio = np.clip(1.0 - keep_ratio, 0.08, 0.45)
        n_mask = max(1, int(len(group) * shape[1] * prune_ratio))
        flat_idx = rng.choice(len(group) * shape[1], n_mask, replace=False)
        local_mask = np.ones((len(group), shape[1]), dtype=bool)
        local_mask.reshape(-1)[flat_idx] = False
        mask[group[:, None], np.arange(shape[1])] = local_mask
    return mask


sparse_pixel_mask = build_sparse_pixel_mask(matrix.shape, sparse_lengths)


NL = [6, 5, 5, 4]
keep_sets_q = []
rng_q = np.random.default_rng(42)
for n, ratio in zip(NL, sparse_lengths[:4]):
    nk = max(1, int(round(n * ratio)))
    keep_sets_q.append(set(rng_q.choice(n, nk, replace=False).tolist()))


def draw_problem_matrix(ax):
    ax.set_xlim(-0.05, 1.05)
    ax.set_ylim(-0.20, 1.10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

    n_layers = len(NL)
    x_positions = [0.10 + i * 0.80 / max(n_layers - 1, 1) for i in range(n_layers)]
    r = 0.032
    prev_kept = None
    for li, n in enumerate(NL):
        cx = x_positions[li]
        sp = 0.80 / max(n - 1, 1)
        off = 0.50 - (n - 1) * sp / 2
        kept_pts = []
        for ni in range(n):
            cy = off + ni * sp
            is_kept = ni in keep_sets_q[li]
            fc = "#4299e1" if is_kept else "#e2e8f0"
            ec = "#2b6cb0" if is_kept else "#cbd5e0"
            lw = 0.6 if is_kept else 0.3
            ax.add_patch(Circle((cx, cy), r, facecolor=fc, edgecolor=ec,
                                linewidth=lw, zorder=5, alpha=1.0 if is_kept else 0.5))
            if is_kept:
                kept_pts.append((cx, cy))
            else:
                ax.plot([cx - 0.015, cx + 0.015], [cy - 0.015, cy + 0.015],
                        color="#dc2626", lw=0.6, zorder=6, alpha=0.7)
                ax.plot([cx - 0.015, cx + 0.015], [cy + 0.015, cy - 0.015],
                        color="#dc2626", lw=0.6, zorder=6, alpha=0.7)
        if prev_kept and kept_pts:
            for px, py in prev_kept:
                for nx_, ny_ in kept_pts:
                    ax.plot([px + r, nx_ - r], [py, ny_],
                            color="#7ba7cc", lw=0.8, alpha=0.6, zorder=0)
        prev_kept = kept_pts

    for li in range(n_layers):
        cx = x_positions[li]
        n = NL[li]
        sp = 0.80 / max(n - 1, 1)
        off = 0.50 - (n - 1) * sp / 2
        top_y = off + (n - 1) * sp + 0.05
        bot_y = off - 0.05
        ax.add_patch(Rectangle((cx - 0.06, bot_y), 0.12, top_y - bot_y,
                               facecolor="none", edgecolor="#dc2626",
                               linewidth=1.2, linestyle="--", zorder=7, alpha=0.8))
        ax.text(cx, top_y + 0.03, "Dense\nStats", ha="center", va="bottom",
                fontsize=5.0, color="#dc2626", fontweight="bold", zorder=7, linespacing=0.8)

    ax.text(0.50, -0.10, "Pruned dims still included in quant. stats", ha="center", va="center",
            fontsize=7.5, color="#dc2626", fontweight="bold",
            transform=ax.transAxes, zorder=10)
    ax.set_title("Sparse Topology + Dense Statistical Boundary", fontsize=9.5, pad=5, fontweight="bold")


def draw_outlier_bars(ax):
    idx = np.arange(len(act_vals))
    colors = np.where(outlier_mask, "#dc2626", "#93c5fd")
    bars = ax.bar(idx, act_vals, color=colors, width=0.78, edgecolor="white", linewidth=0.5)
    threshold = np.quantile(act_vals, 0.90)
    ax.axhline(threshold, color="#dc2626", linestyle="--", linewidth=1.2)
    for i, (v, is_out) in enumerate(zip(act_vals, outlier_mask)):
        if is_out:
            ax.text(i, v + 0.02, f"{v:.2f}", ha="center", va="bottom",
                    fontsize=7.0, color="#dc2626", fontweight="bold")
            ax.add_patch(Rectangle(
                (i - 0.39, 0), 0.78, v,
                facecolor="none", edgecolor="#dc2626",
                linewidth=1.2, linestyle="--", zorder=5,
            ))
    ax.set_title("Uniform 4-bit Damages Outlier Dims", fontsize=9.5, pad=5, fontweight="bold")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.text(0.50, -0.08, "Outlier dims suffer extreme quant. error", ha="center", va="center",
            fontsize=7.5, color="#dc2626", fontweight="bold",
            transform=ax.transAxes, zorder=10)


canvas.add_patch(
    FancyBboxPatch(
        (0.04, 0.10), 0.92, 0.76,
        boxstyle="round,pad=0.005,rounding_size=0.018",
        linewidth=1.0, edgecolor="#fecaca", facecolor="#fffafa",
        transform=canvas.transAxes,
    )
)

canvas.add_patch(
    FancyBboxPatch(
        (0.22, 0.85), 0.56, 0.05,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#dc2626", facecolor="#fef2f2",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.875, "Problem: Dense Stats Misalignment + Uniform Low-Bit Insufficiency", size=8.5, weight="bold", color="#dc2626")

ax_problem_mat = fig.add_axes([0.08, 0.22, 0.34, 0.52])
draw_problem_matrix(ax_problem_mat)

ax_problem_bar = fig.add_axes([0.56, 0.22, 0.34, 0.52])
draw_outlier_bars(ax_problem_bar)

arrow(0.44, 0.48, 0.54, 0.48, color="#dc2626", lw=2.2, scale=16)

label(0.49, 0.55, "Causes", size=8.5, weight="bold", color="#dc2626")

label(0.30, 0.14, "Dense stats span pruned dimensions", size=8.0, weight="bold", color="#b91c1c")
label(0.72, 0.14, "Uniform 4-bit fails to protect outliers", size=8.0, weight="bold", color="#b91c1c")

label(0.50, 0.05, "Mask-guided calibration + Mixed-precision protection → Non-uniform quantization is better",
      size=8.0, color="#7f1d1d", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_2_problem.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_2_problem.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_2_problem.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
