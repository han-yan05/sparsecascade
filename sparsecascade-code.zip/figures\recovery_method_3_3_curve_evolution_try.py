from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

np.random.seed(23)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(10.8, 5.2), dpi=240, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=10, weight="normal", color="#334155", ha="center", va="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va=va, zorder=50,
    )


def flow_arrow(x1, y1, x2, y2, color="#64748b"):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>",
            mutation_scale=16, linewidth=1.8, color=color,
            transform=canvas.transAxes, zorder=30,
        )
    )


def style_ax(ax):
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def base_curve(x):
    peaks = (
        0.22 * np.exp(-((x - 0.16) / 0.10) ** 2)
        + 0.17 * np.exp(-((x - 0.39) / 0.08) ** 2)
        + 0.20 * np.exp(-((x - 0.62) / 0.09) ** 2)
        + 0.15 * np.exp(-((x - 0.84) / 0.08) ** 2)
    )
    baseline = 0.38 + 0.015 * np.sin(8 * np.pi * x)
    return np.clip(baseline + peaks, 0.10, 0.95)


DYNAMIC_SEGMENTS = [(0.02, 0.18), (0.24, 0.39), (0.47, 0.65), (0.73, 0.90)]
FIXED_SEGMENTS = [(0.03, 0.21), (0.27, 0.45), (0.51, 0.69), (0.75, 0.93)]


def draw_damaged(ax):
    style_ax(ax)
    x = np.linspace(0, 1, 600)
    y = base_curve(x)
    ax.fill_between(x, 0, y, color="#d8c8df", alpha=0.82)
    ax.plot(x, y, color="#111827", linewidth=1.45)
    for x_peak in [0.16, 0.39, 0.62, 0.84]:
        y_peak = np.interp(x_peak, x, y)
        ax.scatter([x_peak], [y_peak], s=14, color="#ef4444", zorder=5)
        ax.annotate(
            "", xy=(x_peak, y_peak - 0.01),
            xytext=(x_peak, max(0.05, y_peak - 0.13)),
            arrowprops=dict(arrowstyle="-|>", color="#ef4444", lw=0.9),
        )
    ax.text(0.50, 0.92, "Post-Compression Semantic Damage", fontsize=8.0, fontweight="bold", color="#6b21a8", ha="center")
    ax.text(0.50, 0.84, "Local high-damage peaks", fontsize=6.5, fontweight="bold", color="#b91c1c", ha="center")
    ax.text(0.50, -0.07, r"$\bar{W}_l$", fontsize=9.0, fontweight="bold", color="#1f2937", ha="center")


def draw_block(ax, x, y, w, h, face, edge, label_text=None, label_color="#1f2937"):
    ax.add_patch(
        FancyBboxPatch(
            (x + 0.012, y - 0.012), w, h,
            boxstyle="round,pad=0.002,rounding_size=0.01",
            facecolor="#0f172a", edgecolor="none", alpha=0.10,
        )
    )
    ax.add_patch(
        FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.002,rounding_size=0.01",
            facecolor=face, edgecolor=edge, linewidth=1.0,
        )
    )
    ax.add_patch(
        FancyBboxPatch(
            (x + 0.008, y + h * 0.62), w - 0.016, h * 0.22,
            boxstyle="round,pad=0.001,rounding_size=0.008",
            facecolor="white", edgecolor="none", alpha=0.18,
        )
    )
    if label_text:
        ax.text(x + w / 2, y + h / 2, label_text, ha="center", va="center", fontsize=7.2, fontweight="bold", color=label_color)


def draw_misaligned(ax):
    style_ax(ax)
    ax.add_patch(FancyBboxPatch((0.01, 0.01), 0.95, 0.75, boxstyle="round,pad=0.004,rounding_size=0.02", facecolor="#fffdfd", edgecolor="#e5e7eb", linewidth=0.8))
    ax.text(0.18, 0.83, "Fixed Template", fontsize=7.0, fontweight="bold", color="#6b7280", ha="center")
    ax.text(0.78, 0.83, "Dynamic Struct.", fontsize=7.0, fontweight="bold", color="#166534", ha="center")
    ax.text(0.48, 0.93, "Fixed Comp. Mismatch", fontsize=7.8, fontweight="bold", color="#991b1b", ha="center")
    for left, right in FIXED_SEGMENTS:
        draw_block(ax, left, 0.54, right - left, 0.18, "#e5e7eb", "#9ca3af")
    dynamic_heights = [0.16, 0.22, 0.15, 0.20]
    for (left, right), h in zip(DYNAMIC_SEGMENTS, dynamic_heights):
        draw_block(ax, left, 0.22, right - left, h, "#bbf7d0", "#4ade80")
    fixed_centers = [(l + r) / 2 for l, r in FIXED_SEGMENTS]
    dynamic_centers = [(l + r) / 2 for l, r in DYNAMIC_SEGMENTS]
    for c1, c2 in zip(fixed_centers, dynamic_centers):
        ax.annotate(
            "", xy=(c2, 0.43), xytext=(c1, 0.53),
            arrowprops=dict(arrowstyle="-|>", color="#ef4444", lw=1.2),
        )
    ax.text(0.48, 0.45, "Misal-\nigned", fontsize=7.0, fontweight="bold", color="#ef4444", ha="center")
    ax.text(0.50, 0.13, "Fixed template fails to fit dynamic segments", fontsize=6.5, fontweight="bold", color="#991b1b", ha="center")
    ax.text(0.23, 0.03, r"$\Delta W_{\mathrm{fixed}}$", fontsize=7.7, fontweight="bold", color="#1f2937")
    ax.text(0.77, 0.03, r"$d^{valid}_{in/out}$", fontsize=7.7, fontweight="bold", color="#1f2937")


def draw_aligned(ax):
    style_ax(ax)
    ax.add_patch(FancyBboxPatch((0.01, 0.01), 0.95, 0.75, boxstyle="round,pad=0.004,rounding_size=0.02", facecolor="#fbfdff", edgecolor="#dbeafe", linewidth=0.8))
    ax.text(0.22, 0.83, "Aligned Comp.", fontsize=7.0, fontweight="bold", color="#2563eb", ha="center")
    ax.text(0.78, 0.83, "Dynamic Struct.", fontsize=7.0, fontweight="bold", color="#166534", ha="center")
    ax.text(0.48, 0.93, "Dimension Alignment Lock", fontsize=7.5, fontweight="bold", color="#1d4ed8", ha="center")
    dynamic_heights = [0.16, 0.22, 0.15, 0.20]
    for (left, right), h in zip(DYNAMIC_SEGMENTS, dynamic_heights):
        draw_block(ax, left, 0.54, right - left, h, "#dbeafe", "#60a5fa")
    for (left, right), h in zip(DYNAMIC_SEGMENTS, dynamic_heights):
        draw_block(ax, left, 0.22, right - left, h, "#bbf7d0", "#4ade80")
    for left, right in DYNAMIC_SEGMENTS:
        cx = (left + right) / 2
        ax.annotate(
            "", xy=(cx, 0.43), xytext=(cx, 0.53),
            arrowprops=dict(arrowstyle="-|>", color="#2563eb", lw=1.2),
        )
    ax.text(0.44, 0.45, "Matched", fontsize=6.2, fontweight="bold", color="#2563eb", ha="center")
    ax.text(0.50, 0.13, "Comp. segments match dynamic structure", fontsize=6.5, fontweight="bold", color="#1d4ed8", ha="center")
    ax.text(0.23, 0.03, r"$\Delta W_{\mathrm{aligned}}$", fontsize=7.7, fontweight="bold", color="#1f2937")
    ax.text(0.77, 0.03, r"$d^{valid}_{in/out}$", fontsize=7.7, fontweight="bold", color="#1f2937")


def draw_recovered(ax):
    style_ax(ax)
    x = np.linspace(0, 1, 600)
    before = base_curve(x)
    after = 0.18 + 0.012 * np.sin(6 * np.pi * x + 0.5)
    ax.fill_between(x, 0, before, color="#dbeafe", alpha=0.50)
    ax.fill_between(x, 0, after, color="#bbf7d0", alpha=0.85)
    ax.plot(x, before, color="#94a3b8", linewidth=1.6, linestyle="--")
    ax.plot(x, after, color="#22c55e", linewidth=2.0)
    for x_peak in [0.18, 0.40, 0.63, 0.84]:
        y_before = np.interp(x_peak, x, before)
        y_after = np.interp(x_peak, x, after)
        ax.annotate(
            "", xy=(x_peak, y_after + 0.01),
            xytext=(x_peak, y_before - 0.01),
            arrowprops=dict(arrowstyle="-|>", color="#16a34a", lw=1.0),
        )
    ax.text(0.50, 0.92, "Recovery: Align then Expand Rank", fontsize=7.8, fontweight="bold", color="#15803d", ha="center")
    ax.text(0.50, 0.80, "Local high-error peaks absorbed", fontsize=6.5, fontweight="bold", color="#15803d", ha="center")
    ax.text(0.50, 0.10, "Overall error reduced", fontsize=6.5, fontweight="bold", color="#15803d", ha="center")
    ax.text(0.50, -0.07, r"$\bar{W}_l + \Delta W_{\mathrm{aligned}}^{r=64}$", fontsize=7.4, fontweight="bold", color="#1f2937", ha="center")


canvas.add_patch(
    FancyBboxPatch(
        (0.02, 0.82), 0.96, 0.06,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#7c3aed", facecolor="#f5f3ff",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.85, "Semantic Recovery: Locate Damage → Expose Mismatch → Dim. Alignment → Rank Expansion", size=8.5, weight="bold", color="#6b21a8")

ax1 = fig.add_axes([0.05, 0.34, 0.18, 0.42])
draw_damaged(ax1)
ax2 = fig.add_axes([0.27, 0.34, 0.18, 0.42])
draw_misaligned(ax2)
ax3 = fig.add_axes([0.49, 0.34, 0.18, 0.42])
draw_aligned(ax3)
ax4 = fig.add_axes([0.71, 0.34, 0.18, 0.42])
draw_recovered(ax4)

flow_arrow(0.23, 0.53, 0.27, 0.53, color="#7c3aed")
flow_arrow(0.45, 0.53, 0.49, 0.53, color="#7c3aed")
flow_arrow(0.67, 0.53, 0.71, 0.53, color="#7c3aed")

label(0.14, 0.26, "① Locate local high-damage", size=7.0, weight="bold", color="#475569")
label(0.36, 0.26, "② Fixed template mismatch", size=7.0, weight="bold", color="#475569")
label(0.58, 0.26, "③ Aligned comp. matched", size=7.0, weight="bold", color="#475569")
label(0.80, 0.26, "④ Rank expansion reduces peaks", size=7.0, weight="bold", color="#475569")
label(0.50, 0.22, "Dim. alignment locks comp. to valid dims → Rank expansion absorbs high-freq. semantic loss",
      size=7.5, color="#4c1d95", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_3_curve_evolution_try.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_3_curve_evolution_try.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_3_curve_evolution_try.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
