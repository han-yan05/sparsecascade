import pdb
from transformers import AutoTokenizer
from datasets import load_dataset
import numpy as np
import torch
import random


def set_seed(seed):
    np.random.seed(seed)
    torch.random.manual_seed(seed)




def get_pile(nsamples, seed, seqlen, model):
    print("get_pile")
    traindata = load_dataset("json", data_files='./prompt_quantization/val.jsonl.zst', split="train")

    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)
    trainenc = tokenizer("\n\n".join(traindata['text'][:1000]), return_tensors='pt')

    random.seed(seed)
    trainloader = []
    for _ in range(nsamples):
        i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
        j = i + seqlen
        inp = trainenc.input_ids[:, i:j]
        tar = inp.clone()
        tar[:, :-1] = -100
        trainloader.append((inp, tar))
    return trainloader, None


def get_wikitext2(nsamples, seed, seqlen, model):
    print("get_wikitext2")
    import os
    # Force HF Mirror
    os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
    
    local_wiki_paths = [
        '/root/autodl-tmp/datasets/wikitext',
        '/root/autodl-tmp/wikitext',
        '/root/autodl-tmp/datasets/wikitext/wikitext-2-raw-v1'
    ]
    local_path = None
    for p in local_wiki_paths:
        if os.path.exists(p):
            local_path = p
            break
            
    if local_path:
        print(f"Loading wikitext2 from local path: {local_path}")
        try:
            traindata = load_dataset(local_path, 'wikitext-2-raw-v1', split='train')
            testdata = load_dataset(local_path, 'wikitext-2-raw-v1', split='test')
        except Exception as e:
            print(f"Standard load failed, trying text files: {e}")
            data_files = {}
            # Try to find specific text files
            if os.path.exists(os.path.join(local_path, "train.txt")):
                 traindata = load_dataset("text", data_files={"train": os.path.join(local_path, "train.txt")}, split="train")
                 testdata = load_dataset("text", data_files={"test": os.path.join(local_path, "test.txt")}, split="test")
            elif os.path.exists(os.path.join(local_path, "wikitext-2-raw-v1", "train.txt")):
                 traindata = load_dataset("text", data_files={"train": os.path.join(local_path, "wikitext-2-raw-v1", "train.txt")}, split="train")
                 testdata = load_dataset("text", data_files={"test": os.path.join(local_path, "wikitext-2-raw-v1", "test.txt")}, split="test")
            else:
                 raise e
    else:
        print("Loading wikitext2 from Hugging Face Hub")
        traindata = load_dataset('wikitext', 'wikitext-2-raw-v1', split='train')
        testdata = load_dataset('wikitext', 'wikitext-2-raw-v1', split='test')

    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)
    trainenc = tokenizer("\n\n".join(traindata['text']), return_tensors='pt')
    testenc = tokenizer("\n\n".join(testdata['text']), return_tensors='pt')

    
    random.seed(seed)
    trainloader = []
    for _ in range(nsamples):
        i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
        j = i + seqlen
        inp = trainenc.input_ids[:, i:j]
        tar = inp.clone()
        tar[:, :-1] = -100
        trainloader.append((inp, tar))
    return trainloader, testenc

def get_ptb(nsamples, seed, seqlen, model):
    print("get_ptb")
    traindata = load_dataset('ptb_text_only', 'penn_treebank', split='train')
    valdata = load_dataset('ptb_text_only', 'penn_treebank', split='validation')

    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)

    trainenc = tokenizer("\n\n".join(traindata['sentence']), return_tensors='pt')
    testenc = tokenizer("\n\n".join(valdata['sentence']), return_tensors='pt')

    random.seed(seed)
    trainloader = []
    for _ in range(nsamples):
        i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
        j = i + seqlen
        inp = trainenc.input_ids[:, i:j]
        tar = inp.clone()
        tar[:, :-1] = -100
        trainloader.append((inp, tar))
    return trainloader, testenc

def get_c4(nsamples, seed, seqlen, model):
    print("get_c4 (Local Mode)")
    # Use local files if available
    try:
        traindata = load_dataset(
            'json', 
            data_files={'train': '/root/autodl-tmp/c4/en/c4-train.00000-of-01024.json.gz'}, 
            split='train'
        )
        valdata = load_dataset(
            'json', 
            data_files={'validation': '/root/autodl-tmp/c4/en/c4-validation.00000-of-00008.json.gz'}, 
            split='validation'
        )
    except Exception as e:
        print(f"Failed to load local C4, falling back to streaming: {e}")
        # Fallback to streaming if local load fails
        traindata = load_dataset(
            'allenai/c4', 'en', split='train', streaming=True
        )
        valdata = load_dataset(
            'allenai/c4', 'en', split='validation', streaming=True
        )

    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)

    random.seed(seed)
    trainloader = []
    
    # Iterate through the streaming dataset
    # We shuffle with a buffer to simulate random sampling
    # iterator = iter(traindata.shuffle(seed=seed, buffer_size=10000))
    # When loading from local files (non-streaming), shuffle() does not take buffer_size
    if hasattr(traindata, "shuffle"):
        try:
            # Try with buffer_size (for IterableDataset)
            iterator = iter(traindata.shuffle(seed=seed, buffer_size=10000))
        except TypeError:
            # Fallback for standard Dataset (no buffer_size arg)
            iterator = iter(traindata.shuffle(seed=seed))
    else:
        iterator = iter(traindata)
    
    count = 0
    while count < nsamples:
        try:
            sample = next(iterator)
            trainenc = tokenizer(sample['text'], return_tensors='pt')
            if trainenc.input_ids.shape[1] > seqlen:
                i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
                j = i + seqlen
                inp = trainenc.input_ids[:, i:j]
                tar = inp.clone()
                tar[:, :-1] = -100
                trainloader.append((inp, tar))
                count += 1
        except StopIteration:
            break

    # For validation, we just take the first few samples that are long enough
    valenc = []
    val_iterator = iter(valdata)
    val_count = 0
    while val_count < 256:
        try:
            sample = next(val_iterator)
            tmp = tokenizer(sample['text'], return_tensors='pt')
            if tmp.input_ids.shape[1] >= seqlen:
                i = random.randint(0, tmp.input_ids.shape[1] - seqlen - 1)
                j = i + seqlen
                valenc.append(tmp.input_ids[:, i:j])
                val_count += 1
        except StopIteration:
            break
            
    valenc = torch.hstack(valenc)

    return trainloader, valenc 

def get_ptb_new(nsamples, seed, seqlen, model):
    print("get_ptb_new")
    traindata = load_dataset('ptb_text_only', 'penn_treebank', split='train')
    testdata  = load_dataset('ptb_text_only', 'penn_treebank', split='test')


    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)

    trainenc = tokenizer(" ".join(traindata["sentence"]), return_tensors="pt")
    testenc = tokenizer(" ".join(testdata ["sentence"]), return_tensors="pt")

    random.seed(seed)
    trainloader = []
    for _ in range(nsamples):
        i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
        j = i + seqlen
        inp = trainenc.input_ids[:, i:j]
        tar = inp.clone()
        tar[:, :-1] = -100
        trainloader.append((inp, tar))
    return trainloader, testenc


def get_c4_new(nsamples, seed, seqlen, model):
    print("get_c4_new")
    #traindata = load_dataset(
    #    'allenai/c4', 'allenai--c4', data_files={'train': 'en/c4-train.00000-of-01024.json.gz'}, split='train'
    #)
    #valdata = load_dataset(
    #    'allenai/c4', 'allenai--c4',data_files={'validation': 'en/c4-validation.00000-of-00008.json.gz'}, split='validation'
    #)
    traindata = load_dataset(
        'json', data_files={'train': '/share/c4/en/c4-train.00000-of-01024.json'}, split='train'
    )
    valdata = load_dataset(
        'json', data_files={'validation': '/share/c4/en/c4-validation.00000-of-00008.json'}, split='validation'
    )

    tokenizer = AutoTokenizer.from_pretrained(model, use_fast=False)
    
    random.seed(seed)
    trainloader = []
    for _ in range(nsamples):
        while True:
            i = random.randint(0, len(traindata) - 1)
            trainenc = tokenizer(traindata[i]["text"], return_tensors="pt")
            if trainenc.input_ids.shape[1] > seqlen:
                break
        i = random.randint(0, trainenc.input_ids.shape[1] - seqlen - 1)
        j = i + seqlen
        inp = trainenc.input_ids[:, i:j]
        tar = inp.clone()
        tar[:, :-1] = -100
        trainloader.append((inp, tar))

    valenc = tokenizer(" ".join(valdata[:1100]["text"]), return_tensors="pt")
    valenc = valenc.input_ids[:, : (256 * seqlen)]
    return trainloader, valenc


def get_loaders(
    name, nsamples=128, seed=0, seqlen=2048, model='', #2048
):
    if 'wikitext2' in name:
        return get_wikitext2(nsamples, seed, seqlen, model)
    if 'pile' in name:
        return get_pile(nsamples, seed, seqlen, model)
    if 'ptb' in name:
        if 'new' in name:
            return get_ptb_new(nsamples, seed, seqlen, model)  
        return get_ptb(nsamples, seed, seqlen, model)
    if 'c4' in name:
        if 'new' in name:
            return get_c4_new(nsamples, seed, seqlen, model)  
        return get_c4(nsamples, seed, seqlen, model)
    if 'mix' in name:
        wiki_train,wiki_val=get_wikitext2(nsamples//3, seed, seqlen, model)
        ptb_train,ptb_val=get_ptb(nsamples//3, seed, seqlen, model)
        c4_train,c4_val=get_c4(nsamples//3, seed, seqlen, model)
        train=wiki_train+ptb_train+c4_train
        val=None
        return train,val
