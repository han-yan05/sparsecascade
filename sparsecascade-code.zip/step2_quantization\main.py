import os
import sys

# Add path to import LlamaForCausalLM from Step 1 code
current_dir = os.path.dirname(os.path.abspath(__file__))
pruning_code_path = os.path.join(current_dir, "../../step1_pruning/prune_channel")
if os.path.exists(pruning_code_path):
    sys.path.append(pruning_code_path)
    try:
        from models.modeling_llama import LlamaForCausalLM
        print("Successfully imported LlamaForCausalLM from Step 1 code.")
    except ImportError as e:
        print(f"Failed to import from Step 1 code: {e}")
        from transformers import LlamaForCausalLM
else:
    from transformers import LlamaForCausalLM

import random
import numpy as np
from models.LMClass import LMClass
import torch
import time
from datautils import get_loaders
from lm_eval import evaluator
from pprint import pprint
from parallel_utils import map_layers_to_multi_gpus, get_lowest_occupied_gpu
import torch.nn as nn
from quantize.blockptq import blockptqquant
from tqdm import tqdm
import utils
from pathlib import Path
from categories import subcategories, categories

from models.int_llama_layer import QuantLlamaDecoderLayer
from models.int_opt_layer import QuantOPTDecoderLayer
from quantize.int_linear import QuantLinear

import pdb
import functools

def get_act_scales(model, dataloader, device):
    model.eval()
    act_scales = {}

    def stat_tensor(name, tensor):
        hidden_dim = tensor.shape[-1]
        tensor = tensor.view(-1, hidden_dim).abs().detach()
        comming_max = torch.max(tensor, dim=0)[0].float().cpu()
        if name in act_scales:
            act_scales[name] = torch.max(act_scales[name], comming_max)
        else:
            act_scales[name] = comming_max

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name))
            )

    print("Collecting activation scales...")
    with torch.no_grad():
        for batch in tqdm(dataloader):
            if isinstance(batch, (list, tuple)):
                batch = batch[0]
            batch = batch.to(device)
            model(batch)

    for h in hooks:
        h.remove()

    return act_scales

def get_act_shifts(model, dataloader, device):
    model.eval()
    act_shifts = {}

    def stat_tensor(name, tensor):
        hidden_dim = tensor.shape[-1]
        tensor = tensor.view(-1, hidden_dim).detach()
        comming_max = torch.max(tensor, dim=0)[0].float().cpu()
        comming_min = torch.min(tensor, dim=0)[0].float().cpu()
        if name in act_shifts:
            act_shifts[name] = 0.99 * act_shifts[name] + 0.01 * ((comming_max + comming_min) / 2)
        else:
            act_shifts[name] = (comming_max + comming_min) / 2

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name))
            )

    print("Collecting activation shifts...")
    with torch.no_grad():
        for batch in tqdm(dataloader):
            if isinstance(batch, (list, tuple)):
                batch = batch[0]
            batch = batch.to(device)
            model(batch)

    for h in hooks:
        h.remove()

    return act_shifts

torch.backends.cudnn.benchmark = True

net_choices = [
    "opt-125m",
    "opt-1.3b",
    "opt-2.7b",
    "opt-6.7b",
    "opt-13b",
    "opt-30b",
    "opt-66b",
    "llama-7b",
    "llama-13b",
    "llama-30b",
    "llama-65b",
    "Llama-2-7b",
    "Llama-2-13b",
    "Llama-2-70b",
    "Llama-2-7b-chat",
    "Llama-2-13b-chat",
    "llava-llama-2-13b-chat-lightning-preview",
    "falcon-180b",
    "falcon-7b",
]


@torch.no_grad()
def evaluate(lm, args, logger):
    results = {}
    if args.multigpu:
        if "opt" in args.net.lower():
            map_layers_to_multi_gpus(lm.model.model.decoder.layers)
            input_device = lm.model.model.decoder.layers[0].device
            output_device = lm.model.model.decoder.layers[-1].device
            lm._device = input_device
            assert input_device == output_device
            lm.model.model.decoder.embed_positions.to(input_device)
            lm.model.model.decoder.embed_tokens.to(input_device)
            lm.model.model.decoder.final_layer_norm.to(output_device)
            lm.model.lm_head.to(output_device)

        elif "llama" in args.net.lower():
            map_layers_to_multi_gpus(lm.model.model.layers)
            input_device = lm.model.model.layers[0].device
            output_device = lm.model.model.layers[-1].device
            assert input_device == output_device
            lm._device = input_device
            lm.model.model.embed_tokens.to(input_device)
            lm.model.model.norm.to(output_device)
            lm.model.lm_head.to(output_device)
        elif "falcon" in args.net.lower():
            map_layers_to_multi_gpus(lm.model.transformer.h)
            input_device = lm.model.transformer.h[0].device
            output_device = lm.model.transformer.h[-1].device
            assert input_device == output_device
            lm._device = input_device
            lm.model.transformer.word_embeddings.to(input_device)
            lm.model.transformer.ln_f.to(output_device)
            lm.model.lm_head.to(output_device)
    else:
        if "opt" in args.net.lower():
            lm.model.model.decoder = lm.model.model.decoder.to(lm.device)
        elif "llama" in args.net.lower():
            lm.model = lm.model.to(lm.device)
        elif "falcon" in args.net.lower():
            lm.model.transformer = lm.model.transformer.to(lm.device)


    if args.eval_ppl:
        
        lm.model.eval()
        for dataset in ["wikitext2", "c4"]:
            cache_testloader = f'{args.cache_dir}/testloader_{args.model_family}_{dataset}_all.cache'
            if os.path.exists(cache_testloader):
                # PyTorch 2.6+ defaults weights_only=True, which blocks transformers BatchEncoding.
                # We trust our own cache files, so we set weights_only=False.
                testloader = torch.load(cache_testloader, weights_only=False)
                logger.info(f"load calibration from {cache_testloader}")
            else:
                dataloader, testloader = get_loaders(
                    dataset,
                    seed=args.seed,
                    model=args.model,
                    seqlen=lm.seqlen,
                )
                torch.save(testloader, cache_testloader)
            if "c4" in dataset:
                testenc = testloader
            else:
                testenc = testloader.input_ids

            nsamples = testenc.numel() // lm.seqlen
            use_cache = lm.model.config.use_cache
            lm.model.config.use_cache = False
            lm.model.eval()
            nlls = []
            for i in tqdm(range(nsamples)):
                batch = testenc[:, (i * lm.seqlen) : ((i + 1) * lm.seqlen)].to(lm.device)
                if "opt" in args.net.lower():
                    outputs = lm.model.model.decoder(batch)
                elif "llama" in args.net.lower():
                    outputs = lm.model.model(batch)
                elif "falcon" in args.model:
                    outputs = lm.model.transformer(batch)
                hidden_states = outputs[0]
                logits = lm.model.lm_head(hidden_states)
                shift_logits = logits[:, :-1, :]
                shift_labels = testenc[:, (i * lm.seqlen) : ((i + 1) * lm.seqlen)][
                    :, 1:
                ].to(lm.model.lm_head.weight.device)
                loss_fct = nn.CrossEntropyLoss()
                loss = loss_fct(
                    shift_logits.view(-1, shift_logits.size(-1)),
                    shift_labels.view(-1),
                )
                neg_log_likelihood = loss.float() * lm.seqlen
                nlls.append(neg_log_likelihood)
                if i == args.limit:
                    break

            ppl = torch.exp(torch.stack(nlls).sum() / (nsamples * lm.seqlen))
            logger.info(f'{dataset} : {ppl.item()}')
            lm.model.config.use_cache = use_cache
            results[dataset] = ppl.item()
    if args.tasks != "":
        t_results = evaluator.simple_evaluate(
            lm,
            tasks=args.tasks,
            num_fewshot=args.num_fewshot,
            limit=None if args.limit == -1 else args.limit,
        )
        results.update(t_results)
        logger.info(results)
        pprint(results)
        # for test of MMLU
        if 'hendrycksTest' in args.tasks:
            all_cors = []
            all_cors_norm = []
            subcat_cors = {subcat: [] for subcat_lists in subcategories.values() for subcat in subcat_lists}
            cat_cors = {cat: [] for cat in categories}
            cat_cors_norm = {cat: [] for cat in categories}
            for key in t_results['results'].keys():
                if not 'hendrycksTest' in key:
                    continue
                subject = key.split('-')[-1]
                cors = t_results['results'][key]['acc']
                cors_norm = t_results['results'][key]['acc_norm']
                subcats = subcategories[subject]
                for subcat in subcats:
                    subcat_cors[subcat].append(cors)
                    for key in categories.keys():
                        if subcat in categories[key]:
                            cat_cors[key].append(cors)
                            cat_cors_norm[key].append(cors_norm)
                    all_cors.append(cors)
                    all_cors_norm.append(cors_norm)
                    
            for cat in cat_cors:
                cat_acc = np.mean(cat_cors[cat])
                logger.info("Average accuracy {:.4f} - {}".format(cat_acc, cat))
            weighted_acc = np.mean(all_cors)
            logger.info("Average accuracy: {:.4f}".format(weighted_acc))               
    return results


def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, help="model name of model path")
    parser.add_argument("--cache_dir", default="./cache", type=str, help="cache dir of dataset, leading to faster debug")
    parser.add_argument("--output_dir", default="../log/", type=str, help="direction of logging file")
    parser.add_argument("--save_dir", default=None, type=str, help="direction for saving fake quantization model")
    parser.add_argument("--resume", type=str, default=None)
    parser.add_argument("--real_quant", default=False, action="store_true",)
    parser.add_argument("--calib_dataset",type=str,default="wikitext2",
        choices=["wikitext2", "ptb", "c4"], #, "mix","pile"
        help="Where to extract calibration data from.",
    )
    parser.add_argument("--nsamples", type=int, default=128, help="Number of calibration data samples.")
    parser.add_argument("--batch_size", type=int, default=1, help="batch size.")
    parser.add_argument("--seed", type=int, default=2, help="Seed for sampling the calibration data.")
    parser.add_argument("--tasks", default="")
    parser.add_argument("--eval_ppl", action="store_true")
    parser.add_argument("--num_fewshot", type=int, default=0)
    parser.add_argument("--wbits", type=int, default=4)
    parser.add_argument("--abits", type=int, default=4)
    parser.add_argument("--group_size", type=int, default=None)
    parser.add_argument("--alpha", type=float, default=0.5)
    parser.add_argument("--let_lr", type=float, default=5e-3)
    parser.add_argument("--lwc_lr", type=float, default=1e-2)
    parser.add_argument("--wd", type=float, default=0)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--let",default=False, action="store_true",help="activate learnable equivalent transformation")
    parser.add_argument("--lwc",default=False, action="store_true",help="activate learnable weight clipping")
    parser.add_argument("--aug_loss", default=False, action="store_true", help="calculate additional loss with same input")
    parser.add_argument("--symmetric",default=False, action="store_true", help="symmetric quantization")
    parser.add_argument("--a_dynamic_method", type=str, default="per_token", choices=["per_token"])
    parser.add_argument("--w_dynamic_method", type=str, default="per_channel", choices=["per_channel"])
    parser.add_argument("--limit", type=int, default=-1)
    parser.add_argument("--multigpu", action="store_true", help="at eval, map model to multiple gpus")
    parser.add_argument("--deactive_amp", action="store_true", help="deactivate AMP when 8<=bits<16")
    parser.add_argument("--net", type=str, default=None, choices=net_choices)
    parser.add_argument("--act-scales", type=str, default=None)
    parser.add_argument("--act-shifts", type=str, default=None)
    parser.add_argument("--quant_type", type=str, default="low")
    parser.add_argument("--prune_info_path", type=str, default=None, help="Path to prune_info.pt for loading ragged models")
    parser.add_argument("--lora_r", type=int, default=0, help="LoRA rank for evaluation")
    parser.add_argument("--lora_alpha", type=int, default=16, help="LoRA alpha for evaluation")
    parser.add_argument("--lora_path", type=str, default="lora_final.pth", help="Path to LoRA weights (relative to output_dir)")

    args = parser.parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    # check
    if args.epochs > 0:
        assert args.lwc or args.let
        
    if (args.wbits<16 and args.wbits>=8) or (args.abits<16 and args.abits>=8):
        args.deactive_amp = True

    # init logger
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    if args.cache_dir:
        Path(args.cache_dir).mkdir(parents=True, exist_ok=True)
    if args.save_dir:
        Path(args.save_dir).mkdir(parents=True, exist_ok=True)
    output_dir = Path(args.output_dir)
    logger = utils.create_logger(output_dir)
    logger.info(args)
    
    # load model
    if args.net is None:
        args.net = args.model.split('/')[-1]
    
    # Force Llama if not detected but we know it's Llama
    # Check for 'llm_weight' or 'step2_recycled' or just assume it if not recognized
    if "llama" not in args.net.lower():
        if "llm_weight" in args.net or "step2_recycled" in args.net:
            print(f"Warning: args.net '{args.net}' does not look like Llama, but we assume it is Llama-2-7b.")
            args.net = "Llama-2-7b"
        else:
             # Last resort fallback for custom paths
             print(f"Warning: args.net '{args.net}' unrecognized. Forcing Llama-2-7b.")
             args.net = "Llama-2-7b"

    # assert args.net in net_choices
    args.model_family = args.net.split('-')[0]
    lm = LMClass(args)
    lm.seqlen = 2048 #2048
    lm.model.eval()
    for param in lm.model.parameters():
        param.requires_grad = False

    # --- Manually replace layers with QuantLlamaDecoderLayer if we are in Mix mode ---
    # This is necessary because loading state_dict doesn't change architecture
    if args.quant_type == "mix" or args.wbits < 16:
        print("Replacing layers with QuantLlamaDecoderLayer for evaluation...")
        
        # Prepare quant params (must be done before initialization)
        args.weight_quant_params = {
            "n_bits": args.wbits,
            "per_channel_axes": [0],
            "symmetric": args.symmetric,
            "metric": "minmax",
            "dynamic_method": args.w_dynamic_method,
            "group_size": args.group_size,
            "lwc":args.lwc
        }
        args.act_quant_params = {
            "n_bits":  args.abits,
            "per_channel_axes": [],
            "symmetric": False,
            "metric": "minmax",
            "dynamic_method": args.a_dynamic_method,
        }
        args.q_quant_params = {
            "n_bits": args.abits,
            "per_channel_axes": [],
            "symmetric": False,
            "metric": "minmax",
            "dynamic_method": args.a_dynamic_method,
        }
        args.k_quant_params = {
            "n_bits": args.abits,
            "per_channel_axes": [],
            "symmetric": False,
            "metric": "minmax",
            "dynamic_method": args.a_dynamic_method,
        }
        args.v_quant_params = {
            "n_bits": args.abits,
            "per_channel_axes": [],
            "symmetric": False,
            "metric": "minmax",
            "dynamic_method": args.a_dynamic_method,
        }
        args.p_quant_params = {
            "n_bits": args.abits, # Fix: Use abits instead of hardcoded 16
            "per_channel_axes": [], # Added missing param
            "symmetric": False,     # Added missing param
            "metric": "minmax",     # Changed from fix0to1 to minmax for consistency
            "dynamic_method": args.a_dynamic_method, # Added missing param
        }
        
        layers = lm.model.model.layers
        for i in range(len(layers)):
            layers[i] = QuantLlamaDecoderLayer(lm.model.config, layers[i], args)
        print("Layer replacement done.")

    # --- ENABLE LORA IF REQUESTED (MOVED TO AFTER QUANTIZATION LOADING) ---
    # We define a function to apply LoRA, and call it later
    def apply_lora():
        if args.lora_r > 0:
            print(f"Enabling LoRA (r={args.lora_r}) for evaluation...")
            count = 0
            for name, module in lm.model.named_modules():
                if isinstance(module, QuantLinear):
                    # Target same modules as training
                    target_keywords = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']
                    if any(k in name for k in target_keywords):
                        module.enable_lora(r=args.lora_r, lora_alpha=args.lora_alpha)
                        count += 1
            print(f"Enabled LoRA for {count} layers.")
            
            # Load LoRA weights
            lora_path = os.path.join(args.output_dir, args.lora_path)
            if os.path.exists(lora_path):
                 print(f"Loading LoRA weights from {lora_path}...")
                 lm.model.load_state_dict(torch.load(lora_path), strict=False)
            else:
                 print(f"Warning: LoRA requested but {lora_path} not found!")
    # --------------------------------

    args.weight_quant_params = {
        "n_bits": args.wbits,
        "per_channel_axes": [0],
        "symmetric": args.symmetric,
        "dynamic_method": args.w_dynamic_method,
        "group_size": args.group_size,
        "lwc":args.lwc
    }
    args.act_quant_params = {
        "n_bits":  args.abits,
        "per_channel_axes": [],
        "symmetric": False,
        "dynamic_method": args.a_dynamic_method,
    }
    args.q_quant_params = {
        "n_bits": args.abits,
        "per_channel_axes": [],
        "symmetric": False,
        "dynamic_method": args.a_dynamic_method,
    }
    args.k_quant_params = {
        "n_bits": args.abits,
        "per_channel_axes": [],
        "symmetric": False,
        "dynamic_method": args.a_dynamic_method,
    }
    args.v_quant_params = {
        "n_bits": args.abits,
        "per_channel_axes": [],
        "symmetric": False,
        "dynamic_method": args.a_dynamic_method,
    }
    args.p_quant_params = {
        "n_bits": 16,
        "metric": "fix0to1",
    }

    if args.multigpu:
        gpu_id = get_lowest_occupied_gpu(wait_memory=5000)
        lm._device = f"cuda:{gpu_id}"
        logger.info(f"set quantization in gpu {gpu_id}")

    # act scales and shifts
    if args.act_scales is None:
        # Try default path based on args.net
        default_path = f'./act_scales/{args.net}.pt'
        if os.path.exists(default_path):
            args.act_scales = default_path
        else:
            # Try path based on raw model name (e.g., llm_weight)
            raw_name = args.model.split('/')[-1]
            raw_path = f'./act_scales/{raw_name}.pt'
            if os.path.exists(raw_path):
                print(f"Using act_scales from raw model name: {raw_path}")
                args.act_scales = raw_path
            else:
                # Fallback to default, let it crash if not found
                args.act_scales = default_path

    if args.act_shifts is None:
        default_path = f'./act_shifts/{args.net}.pt'
        if os.path.exists(default_path):
            args.act_shifts = default_path
        else:
            raw_name = args.model.split('/')[-1]
            raw_path = f'./act_shifts/{raw_name}.pt'
            if os.path.exists(raw_path):
                print(f"Using act_shifts from raw model name: {raw_path}")
                args.act_shifts = raw_path
            else:
                args.act_shifts = default_path

    # Check if scales/shifts exist, if not generate them
    if (not os.path.exists(args.act_scales) or not os.path.exists(args.act_shifts)) and not getattr(args, "only_evaluate", False):
        print(f"Activation scales or shifts not found at {args.act_scales} / {args.act_shifts}")
        print("Generating them now using the loaded model...")
        
        # Ensure model is on the correct device
        lm.model = lm.model.to(lm.device)
        
        # Load dataloader
        cache_dataloader = f'{args.cache_dir}/dataloader_{args.model_family}_{args.calib_dataset}_{args.nsamples}.cache'
        if os.path.exists(cache_dataloader):
             dataloader = torch.load(cache_dataloader, weights_only=False)
             logger.info(f"load calibration from {cache_dataloader}")
        else:
             dataloader, _ = get_loaders(
                 args.calib_dataset,
                 nsamples=args.nsamples,
                 seed=args.seed,
                 model=args.model,
                 seqlen=lm.seqlen,
             )
             torch.save(dataloader, cache_dataloader)
             
        if not os.path.exists(args.act_scales):
            scales = get_act_scales(lm.model, dataloader, lm.device)
            os.makedirs(os.path.dirname(args.act_scales), exist_ok=True)
            torch.save(scales, args.act_scales)
            print(f"Saved act_scales to {args.act_scales}")
            
        if not os.path.exists(args.act_shifts):
            shifts = get_act_shifts(lm.model, dataloader, lm.device)
            os.makedirs(os.path.dirname(args.act_shifts), exist_ok=True)
            torch.save(shifts, args.act_shifts)
            print(f"Saved act_shifts to {args.act_shifts}")

        # Move model back to CPU to free up memory for block quantization
        print("Moving model back to CPU to save memory for quantization...")
        lm.model = lm.model.cpu()
        torch.cuda.empty_cache()

    # Skip quantization if requested
    if getattr(args, "only_evaluate", False):
        logger.info("=== Skipping quantization (only_evaluate=True) ===")
        apply_lora() # Apply LoRA before evaluation
        evaluate(lm, args, logger)
        return

    # quantization
    if args.wbits < 16 or args.abits <16:
        # Check if already quantized (resume mechanism)
        final_ckpt_path = os.path.join(args.output_dir, f"{args.quant_type}_{args.wbits}_current.pth")
        
        logger.info(f"DEBUG: Checking for checkpoint at: {final_ckpt_path}")
        logger.info(f"DEBUG: File exists? {os.path.exists(final_ckpt_path)}")

        # If checkpoint exists, load it and SKIP the entire quantization block
        if os.path.exists(final_ckpt_path):
            logger.info(f"=== Found existing checkpoint at {final_ckpt_path}, skipping quantization ===")
            # Use strict=False to ignore missing keys (which are quantization parameters not present in original model)
            lm.model.load_state_dict(torch.load(final_ckpt_path), strict=False)
            lm.model.eval()
            apply_lora() # Apply LoRA after loading checkpoint
        else:
            # Only enter this block if NO checkpoint exists
            logger.info("=== start quantization ===")
            tick = time.time()     
            # load calibration dataset
            cache_dataloader = f'{args.cache_dir}/dataloader_{args.model_family}_{args.calib_dataset}_{args.nsamples}.cache'
            if os.path.exists(cache_dataloader):
                dataloader = torch.load(cache_dataloader, weights_only=False)
                logger.info(f"load calibration from {cache_dataloader}")
            else:
                dataloader, _ = get_loaders(
                    args.calib_dataset,
                    nsamples=args.nsamples,
                    seed=args.seed,
                    model=args.model,
                    seqlen=lm.seqlen,
                )
                torch.save(dataloader, cache_dataloader)    
            """ act_scales = None
            act_shifts = None
            if args.let: """
            act_scales = torch.load(args.act_scales)
            act_shifts = torch.load(args.act_shifts)
            
            # This function runs the 32-layer optimization
            blockptqquant(
                lm,
                args,
                dataloader,
                act_scales,
                act_shifts,
                logger,
            )
            logger.info(time.time() - tick)
            lm.model.eval()
            torch.save(lm.model.state_dict(),os.path.join(args.output_dir, f"{args.quant_type}_{args.wbits}_current.pth"))
            apply_lora() # Apply LoRA after quantization
            
    # Evaluation happens after quantization (or loading)
    evaluate(lm, args,logger)

if __name__ == "__main__":
    print(sys.argv)
    main()
