import transformers
import torch
import os
import sys

# Add path to import LlamaForCausalLM from Step 1 code
current_dir = os.path.dirname(os.path.abspath(__file__))
pruning_code_path = os.path.join(current_dir, "../../../step1_pruning/prune_channel")
if os.path.exists(pruning_code_path):
    sys.path.append(pruning_code_path)
    try:
        from models.modeling_llama import LlamaForCausalLM
        print("LMClass: Successfully imported LlamaForCausalLM from Step 1 code.")
    except ImportError as e:
        print(f"LMClass: Failed to import from Step 1 code: {e}")
        from transformers import LlamaForCausalLM
else:
    from transformers import LlamaForCausalLM

from .models_utils import BaseLM, find_layers
from transformers import AutoTokenizer, AutoConfig, AutoModelForCausalLM
import torch.nn.functional as F
from torch import nn
import torch
from tqdm import tqdm
import pdb


class LMClass(BaseLM):
    def __init__(self, args):

        super().__init__()

        self.args = args
        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model_name = args.model
        self.batch_size_per_gpu = args.batch_size

        self.model_config = args.model
        config = AutoConfig.from_pretrained(args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=False,legacy=False)
        
        # Use bfloat16 to avoid NaN issues
        target_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float32
        print(f"LMClass: Using dtype {target_dtype} for stability")

        prune_info_path = getattr(args, "prune_info_path", None)
        
        if prune_info_path:
            # New Loading Logic for Ragged Models
            from utils import load_prune_info, physical_prune_attn, physical_prune_mlp
            from transformers import LlamaForCausalLM as HFLlamaForCausalLM
            print(f"LMClass: Loading ragged model with prune info: {prune_info_path}")
            
            # FORCE Eager Attention FIRST (Before Init)
            if hasattr(config, "attn_implementation"):
                print(f"LMClass: Forcing attn_implementation='eager' for ragged model.")
                config.attn_implementation = "eager"
            elif hasattr(config, "_attn_implementation"):
                config._attn_implementation = "eager"

            # Init dense (no weights) - FORCE Standard HF Llama to avoid custom model mismatches
            try:
                self.model = HFLlamaForCausalLM(config)
            except Exception as e:
                print(f"LMClass: Fallback to AutoModel: {e}")
                self.model = AutoModelForCausalLM.from_config(config)
            
            self.model.to(dtype=target_dtype)
            
            # Prune
            prune_info = load_prune_info(prune_info_path)
            physical_prune_mlp(self.model, prune_info, "cpu")
            physical_prune_attn(self.model, prune_info, "cpu")
            
            # Load Weights
            import os
            import glob
            weight_path = os.path.join(args.model, "pytorch_model.bin")
            if not os.path.exists(weight_path):
                 bins = list(glob.glob(os.path.join(args.model, "*.bin")))
                 if bins: weight_path = bins[0]
            
            if os.path.exists(weight_path):
                print(f"LMClass: Loading weights from {weight_path}")
                state_dict = torch.load(weight_path, map_location="cpu")
                try:
                    self.model.load_state_dict(state_dict, strict=True)
                    print("LMClass: Weights loaded successfully with Strict=True!")
                except Exception as e:
                    print(f"LMClass: Strict loading failed! Checking for safe failures (e.g., rotary embeddings or layernorms)...")
                    # Analyze mismatch
                    # If mismatch is only in "rotary_emb.inv_freq" or simple size mismatches that might be expected?
                    # No, size mismatch for q_proj [2816, 4096] vs [4096, 4096] means:
                    # The CHECKPOINT has [4096, 4096] (Dense) but the MODEL is [2816, 4096] (Ragged).
                    # OR vice-versa.
                    # Error says: "copying a param with shape torch.Size([11008, 4096]) from checkpoint, the shape in current model is torch.Size([7323, 4096])."
                    # This means Checkpoint is DENSE (11008), but Model is RAGGED (7323).
                    
                    # Why is Checkpoint Dense? 
                    # Did Step 2 save the original weights instead of the pruned ones?
                    # Or did we load the WRONG checkpoint?
                    
                    print(f"DEBUG ERROR: {e}")
                    print("It seems the checkpoint file contains DENSE weights (original size), but we built a RAGGED model.")
                    print("This implies Step 2 (Recycling) did NOT save the physically pruned weights correctly, or we are pointing to the wrong file.")
                    
                    # Fallback: If checkpoint is dense, maybe we should just load it into a dense model and prune it AGAIN?
                    # But Step 2 was supposed to TRAIN the weights. If it saved dense weights, are they trained?
                    # If Step 2 logic was: Init Dense -> Mask -> Train -> Save.
                    # Then saved weights are Dense but with Zeros.
                    # If so, we should Load Dense -> Prune.
                    
                    print("Attempting Fallback Strategy: Load DENSE weights first, THEN Prune.")
                    
                    # Re-init dense model
                    try:
                        # Ensure Eager Attention Config is passed correctly
                        if hasattr(config, "attn_implementation"): 
                             config.attn_implementation = "eager"
                        if hasattr(config, "_attn_implementation"): 
                             config._attn_implementation = "eager"
                             
                        # ALSO update model_config if it's different from config
                        if hasattr(self, "model_config") and hasattr(self.model_config, "attn_implementation"):
                             self.model_config.attn_implementation = "eager"

                        # Use from_pretrained to handle sharded checkpoints correctly!
                        # Previous manual loading of single .bin file was WRONG for sharded models.
                        print(f"Loading pre-trained model from {args.model} ...")
                        self.model = HFLlamaForCausalLM.from_pretrained(
                            args.model, 
                            config=config, 
                            torch_dtype=target_dtype, 
                            device_map="cpu" # Load to CPU first to avoid OOM before pruning
                        )
                        
                        print("Loaded dense weights using from_pretrained (handles sharding). Now applying pruning...")
                        
                        physical_prune_mlp(self.model, prune_info, "cpu")
                        physical_prune_attn(self.model, prune_info, "cpu")
                        print("Pruning applied after loading. Ragged model ready.")
                        
                        # Double Check Attention Implementation
                        if hasattr(self.model.config, "attn_implementation"):
                             print(f"Final Attention Implementation: {self.model.config.attn_implementation}")
                        
                    except Exception as e2:
                        print(f"Fallback failed: {e2}")
                        raise e # Raise original error if fallback fails
            else:
                print(f"LMClass: Warning! Weight file not found at {weight_path}")
        else:
            # Try loading with custom LlamaForCausalLM first
            try:
                self.model = LlamaForCausalLM.from_pretrained(args.model, config=config, device_map='cpu', torch_dtype=target_dtype)
            except Exception as e:
                print(f"LMClass: Error loading with custom LlamaForCausalLM: {e}")
                print("LMClass: Falling back to AutoModelForCausalLM")
                self.model = AutoModelForCausalLM.from_pretrained(args.model, config=config, device_map='cpu',torch_dtype=target_dtype)
            
        self.seqlen = self.model.config.max_position_embeddings
        self.model.eval()
        self.vocab_size = self.tokenizer.vocab_size
        print("vocab size: ", self.vocab_size)

    @property
    def eot_token(self) -> str:
        return self.tokenizer.eos_token

    @property
    def eot_token_id(self):
        # we use EOT because end of *text* is more accurate for what we're doing than end of *sentence*
        return self.tokenizer.eos_token_id

    @property
    def max_length(self):
        try:
            return self.gpt2.config.n_ctx
        except AttributeError:
            # gptneoconfig doesn't have n_ctx apparently
            return self.model.config.max_position_embeddings

    @property
    def max_gen_toks(self):
        print("max_gen_toks fn")
        return 256

    @property
    def batch_size(self):
        # TODO: fix multi-gpu
        return self.batch_size_per_gpu  # * gpus

    @property
    def device(self):
        # TODO: fix multi-gpu
        return self._device

    def tok_encode(self, string: str):
        return self.tokenizer.encode(string, add_special_tokens=False)

    def tok_encode_batch(self, strings):
        return self.tokenizer(
            strings,
            padding=True,
            add_special_tokens=False,
            return_tensors="pt",
        )

    def tok_decode(self, tokens):
        return self.tokenizer.batch_decode(tokens, skip_special_tokens=True)

    def _model_call(self, inps):
        """
        inps: a torch tensor of shape [batch, sequence]
        the size of sequence may vary from call to call
        returns: a torch tensor of shape [batch, sequence, vocab] with the
        logits returned from the model
        """
        with torch.no_grad():
            if hasattr(self.model.config, "use_cache"):
                 self.model.config.use_cache = False
            return self.model(inps)["logits"]

    def model_batched_set(self, inps):
        dataset_logits = []
        for batch in inps:
            multi_logits = F.log_softmax(
                self._model_call(batch), dim=-1
            ).cpu()  # [batch, padding_length, vocab]
            dataset_logits.append(multi_logits)
        return dataset_logits

    def _model_generate(self, context, max_length, eos_token_id):
        return self.model.generate(
            context, max_length=max_length, eos_token_id=eos_token_id, do_sample=False
        )
