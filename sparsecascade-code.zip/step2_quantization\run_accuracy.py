import os
import argparse
import subprocess
import sys

# Tasks list for Zero-shot Evaluation
TASKS = "piqa,hellaswag,winogrande,arc_easy,arc_challenge"

def build_base_cmd(args):
    """Build the common command arguments."""
    cmd = [
        "python", "main.py",
        "--model", args.model_path,
        "--resume", args.checkpoint_path,
        "--wbits", str(args.wbits),
        "--abits", str(args.abits),
        "--output_dir", args.output_dir,
        "--quant_type", args.quant_type # Ensure quant_type is passed
    ]
    
    if args.let: cmd.append("--let")
    if args.lwc: cmd.append("--lwc")
    if args.aug_loss: cmd.append("--aug_loss")
    if args.symmetric: cmd.append("--symmetric")
    
    if args.prune_info_path:
        cmd.extend(["--prune_info_path", args.prune_info_path])
        
    if args.act_scales:
        cmd.extend(["--act-scales", args.act_scales])
    if args.act_shifts:
        cmd.extend(["--act-shifts", args.act_shifts])
        
    return cmd

def run_eval(args):
    # --- Round 1: WikiText2 PPL + Zero-shot Accuracy ---
    print("\n[Round 1] Running WikiText2 PPL and Zero-shot Tasks...")
    cmd1 = build_base_cmd(args)
    cmd1.extend([
        "--eval_ppl",
        "--calib_dataset", "wikitext2",
        "--tasks", TASKS
    ])
    
    try:
        print(f"Executing: {' '.join(cmd1)}")
        subprocess.run(cmd1, check=True)
    except subprocess.CalledProcessError:
        print("[Error] Round 1 (WikiText2 + Tasks) failed!")
        return # Stop if Round 1 fails

    # --- Round 2: C4 PPL ---
    print("\n[Round 2] Running C4 PPL...")
    cmd2 = build_base_cmd(args)
    cmd2.extend([
        "--eval_ppl",
        "--calib_dataset", "c4",
        "--tasks", "" # No tasks this time, just PPL
    ])
    
    try:
        print(f"Executing: {' '.join(cmd2)}")
        subprocess.run(cmd2, check=True)
        print("\nAll Evaluations Completed Successfully!")
    except subprocess.CalledProcessError:
        print("[Error] Round 2 (C4 PPL) failed!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--wbits", type=int, default=4)
    parser.add_argument("--abits", type=int, default=16)
    parser.add_argument("--output_dir", type=str, default="./log/eval_results")
    parser.add_argument("--quant_type", type=str, default="mix", help="mix or low")
    
    # Flags
    parser.add_argument("--let", action="store_true")
    parser.add_argument("--lwc", action="store_true")
    parser.add_argument("--aug_loss", action="store_true")
    parser.add_argument("--symmetric", action="store_true")
    
    # Pruning Support
    parser.add_argument("--prune_info_path", type=str, default=None)
    parser.add_argument("--act_scales", type=str, default=None)
    parser.add_argument("--act_shifts", type=str, default=None)
    
    args = parser.parse_args()
    
    # Create output dir if not exists
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
        
    run_eval(args)
