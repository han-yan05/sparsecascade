import torch
import os
import argparse

def main(args):
    print(f"Generating Random Masks based on structure from: {args.base_prune_info}")
    
    # Load original prune info to get structure and sparsity
    base_info = torch.load(args.base_prune_info, map_location="cpu")
    new_info = {}
    
    torch.manual_seed(args.seed)
    
    for layer_key, layer_data in base_info.items():
        if not isinstance(layer_data, dict):
            print(f"Skipping non-dict key: {layer_key}, Value: {layer_data}")
            new_info[layer_key] = layer_data
            continue
            
        new_layer_data = {}
        for key, value in layer_data.items():
            if "mask" in key:
                # Value is the binary mask (1=Keep/Backbone, 0=Prune/Fat)
                # We want to generate a random mask with the SAME sparsity.
                
                # Calculate sparsity
                num_elements = value.numel()
                num_ones = value.sum().item()
                sparsity = 1.0 - (num_ones / num_elements)
                
                # Generate random tensor
                rand_tensor = torch.rand_like(value.float())
                
                # Top-k to keep (1 - sparsity)
                k = num_ones
                # If we want to keep k elements, we select top k values
                # value 1 means KEEP.
                
                # Get indices of top k
                _, indices = torch.topk(rand_tensor.view(-1), k)
                
                # Create new mask
                new_mask = torch.zeros_like(value, dtype=torch.bool)
                new_mask.view(-1)[indices] = True
                
                new_layer_data[key] = new_mask
            else:
                new_layer_data[key] = value
        new_info[layer_key] = new_layer_data
        
    os.makedirs(os.path.dirname(args.output_path), exist_ok=True)
    torch.save(new_info, args.output_path)
    print(f"Random prune info saved to: {args.output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_prune_info", type=str, required=True, help="Path to original prune_info.pt")
    parser.add_argument("--output_path", type=str, required=True, help="Path to save random_prune_info.pt")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    main(args)
