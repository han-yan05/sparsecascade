from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle, Circle

np.random.seed(29)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(9.0, 5.0), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.5, weight="normal", color="#334155", ha="center"):
    canvas.text(
        x, y, text,
        transform=canvas.transAxes,
        fontsize=size, fontweight=weight, color=color,
        ha=ha, va="center", zorder=40,
    )


def chip(x, y, w, h, text, facecolor, edgecolor, fontsize=8.3):
    canvas.add_patch(
        FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.003,rounding_size=0.01",
            transform=canvas.transAxes,
            facecolor=facecolor, edgecolor=edgecolor,
            linewidth=0.9, zorder=35,
        )
    )
    label(x + w / 2, y + h / 2, text, size=fontsize, weight="bold", color="#1f2937")


def arrow(x1, y1, x2, y2, lw=1.8, color="#475569", scale=14):
    canvas.add_patch(
        FancyArrowPatch(
            (x1, y1), (x2, y2),
            arrowstyle="-|>",
            mutation_scale=scale, linewidth=lw, color=color,
            transform=canvas.transAxes, zorder=32,
        )
    )


lengths = np.array([0.90, 0.72, 0.84, 0.58, 0.80, 0.66])


NL_r = [6, 6, 6, 6, 6, 6]
keep_sets_r = []
rng_r = np.random.default_rng(29)
for n, keep_ratio in zip(NL_r, lengths):
    nk = max(1, int(round(n * keep_ratio)))
    keep_sets_r.append(set(rng_r.choice(n, nk, replace=False).tolist()))


def draw_backbone(ax):
    ax.set_xlim(-0.05, 1.05)
    ax.set_ylim(-0.20, 1.10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

    n_layers = len(NL_r)
    x_positions = [0.10 + i * 0.80 / max(n_layers - 1, 1) for i in range(n_layers)]
    r = 0.028
    prev_kept = None
    for li, n in enumerate(NL_r):
        cx = x_positions[li]
        sp = 0.80 / max(n - 1, 1)
        off = 0.50 - (n - 1) * sp / 2
        kept_pts = []
        for ni in range(n):
            cy = off + ni * sp
            is_kept = ni in keep_sets_r[li]
            if is_kept:
                fc = "#4299e1"
                ec = "#2b6cb0"
                lw = 0.5
                ax.add_patch(Circle((cx, cy), r, facecolor=fc, edgecolor=ec,
                                    linewidth=lw, zorder=5))
                kept_pts.append((cx, cy))
            else:
                ax.add_patch(Circle((cx, cy), r, facecolor="#e2e8f0", edgecolor="#cbd5e0",
                                    linewidth=0.3, zorder=5, alpha=0.5))
                ax.plot([cx - 0.013, cx + 0.013], [cy - 0.013, cy + 0.013],
                        color="#94a3b8", lw=0.5, zorder=6, alpha=0.6)
                ax.plot([cx - 0.013, cx + 0.013], [cy + 0.013, cy - 0.013],
                        color="#94a3b8", lw=0.5, zorder=6, alpha=0.6)
        if prev_kept and kept_pts:
            for px, py in prev_kept:
                for nx_, ny_ in kept_pts:
                    ax.plot([px + r, nx_ - r], [py, ny_],
                            color="#7ba7cc", lw=0.6, alpha=0.5, zorder=0)
        prev_kept = kept_pts
        ax.text(cx, -0.08, f"L{li+1}", ha="center", va="top",
                fontsize=7.0, color="#64748b", zorder=7)
        n_valid = len(keep_sets_r[li])
        ax.text(cx, 1.02, f"d={n_valid}", ha="center", va="bottom",
                fontsize=7.0, color="#dc2626", fontweight="bold", zorder=7)

    ax.add_patch(Rectangle((0.02, -0.02), 0.96, 1.04,
                           facecolor="none", edgecolor="#2563eb", linewidth=1.2, zorder=4))
    ax.set_title("Frozen Quantized Backbone", fontsize=9.5, pad=5, fontweight="bold")
    ax.text(0.50, -0.12, "Valid dimensions vary across layers", ha="center", va="center",
            fontsize=7.5, color="#dc2626", fontweight="bold", transform=ax.transAxes)


def draw_adapter_mismatch(ax):
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title("Fixed Low-Rank Compensation", fontsize=9.5, pad=5, fontweight="bold", color="#dc2626")

    in_dim, out_dim, rank = 12, 10, 16
    valid_in, valid_out = 8, 6

    left_x = 0.06
    gap = 0.12
    left_w = 0.32
    right_w = 0.32
    left_h = 0.18 + 0.50 * min(1.0, rank / 64)
    right_h = 0.20 + 0.46 * min(1.0, out_dim / 10)
    left_y = 0.50 - left_h / 2
    right_y = 0.50 - right_h / 2

    ax.add_patch(Rectangle((left_x, left_y), left_w, left_h,
                           facecolor="#fce7f3", edgecolor="#db2777", linewidth=1.0))
    valid_w = left_w * valid_in / in_dim
    ax.add_patch(Rectangle((left_x, left_y), valid_w, left_h,
                           facecolor="#fbcfe8", edgecolor="none", zorder=1))
    ax.text(left_x + valid_w / 2, left_y + left_h / 2, r"$d_{in}^{valid}$",
            ha="center", va="center", fontsize=7.5, color="#2563eb", zorder=2)
    ax.text(left_x + left_w / 2, left_y + left_h + 0.03, r"$A_l$",
            ha="center", va="center", fontsize=11, fontweight="bold", color="#831843")
    ax.text(left_x + left_w / 2, left_y - 0.05, f"{rank} x {in_dim}",
            ha="center", va="center", fontsize=7.5, color="#64748b")

    mismatch_w = left_w * (1 - valid_in / in_dim)
    ax.add_patch(Rectangle((left_x + left_w - mismatch_w, left_y), mismatch_w, left_h,
                           facecolor="#fecaca", edgecolor="#dc2626", linewidth=1.2,
                           linestyle="--", zorder=5))
    ax.text(left_x + left_w - mismatch_w / 2, left_y + left_h / 2, "X",
            ha="center", va="center", fontsize=10, fontweight="bold", color="#dc2626", zorder=6)

    ax.add_patch(Rectangle((left_x + left_w + gap, right_y), right_w, right_h,
                           facecolor="#ede9fe", edgecolor="#7c3aed", linewidth=1.0))
    valid_h = right_h * valid_out / out_dim
    ax.add_patch(Rectangle((left_x + left_w + gap, right_y), right_w, valid_h,
                           facecolor="#ddd6fe", edgecolor="none", zorder=1))
    ax.text(left_x + left_w + gap + right_w / 2, right_y + valid_h / 2, r"$d_{out}^{valid}$",
            ha="center", va="center", fontsize=7.5, color="#2563eb", zorder=2)
    ax.text(left_x + left_w + gap + right_w / 2, right_y + right_h + 0.03, r"$B_l$",
            ha="center", va="center", fontsize=11, fontweight="bold", color="#4c1d95")
    ax.text(left_x + left_w + gap + right_w / 2, right_y - 0.05, f"{out_dim} x {rank}",
            ha="center", va="center", fontsize=7.5, color="#64748b")

    mismatch_h = right_h * (1 - valid_out / out_dim)
    ax.add_patch(Rectangle((left_x + left_w + gap, right_y + right_h - mismatch_h), right_w, mismatch_h,
                           facecolor="#fecaca", edgecolor="#dc2626", linewidth=1.2,
                           linestyle="--", zorder=5))
    ax.text(left_x + left_w + gap + right_w / 2, right_y + right_h - mismatch_h / 2, "X",
            ha="center", va="center", fontsize=10, fontweight="bold", color="#dc2626", zorder=6)

    ax.annotate("", xy=(left_x + left_w + gap - 0.01, 0.50),
                xytext=(left_x + left_w + 0.01, 0.50),
                arrowprops=dict(arrowstyle="->", color="#64748b", lw=1.5))

    ax.text(0.50, 0.95, "Red X = Invalid dims waste comp. capacity", ha="center", va="center",
            fontsize=7.0, color="#dc2626", fontweight="bold")
    ax.text(0.50, 0.03, "Capacity allocation misaligned", ha="center", va="center",
            fontsize=8.0, color="#dc2626", fontweight="bold")


canvas.add_patch(
    FancyBboxPatch(
        (0.04, 0.10), 0.92, 0.76,
        boxstyle="round,pad=0.005,rounding_size=0.018",
        linewidth=1.0, edgecolor="#fecaca", facecolor="#fffafa",
        transform=canvas.transAxes,
    )
)

canvas.add_patch(
    FancyBboxPatch(
        (0.18, 0.85), 0.64, 0.05,
        boxstyle="round,pad=0.004,rounding_size=0.012",
        linewidth=1.0, edgecolor="#dc2626", facecolor="#fef2f2",
        transform=canvas.transAxes, zorder=5,
    )
)
label(0.50, 0.875, "Problem: Fixed Compensation Fails to Adapt to Dynamic Valid Dims", size=8.5, weight="bold", color="#dc2626")

ax_base = fig.add_axes([0.06, 0.18, 0.34, 0.55])
draw_backbone(ax_base)

ax_bad = fig.add_axes([0.54, 0.18, 0.38, 0.55])
draw_adapter_mismatch(ax_bad)

arrow(0.42, 0.45, 0.52, 0.45, color="#dc2626", lw=2.2, scale=16)
label(0.47, 0.53, "Comp.\nAdapt?", size=7.0, weight="bold", color="#dc2626")

label(0.50, 0.05, "Dynamic valid dims + Fixed comp. structure → Dimension alignment + Rank expansion is better",
      size=8.0, color="#7f1d1d", weight="bold")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_3_problem.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_3_problem.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_3_problem.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
