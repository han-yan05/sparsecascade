from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib import colormaps, rcParams
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle, Polygon, Circle

np.random.seed(42)
rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
rcParams["axes.unicode_minus"] = True
rcParams["font.weight"] = "normal"
rcParams["axes.titleweight"] = "bold"

PALETTE = {
    "bg": "#ffffff",
    "s1_accent": "#2d6a4f", "s1_light": "#eef5ee", "s1_border": "#4a7c59",
    "s2_accent": "#9a6c00", "s2_light": "#fef6ee", "s2_border": "#b8860b",
    "s3_accent": "#5b4a8a", "s3_light": "#f3f0ff", "s3_border": "#6b5b95",
    "axis_color": "#334155",
    "nn_keep": "#2b6cb0", "nn_pruned": "#cbd5e0",
    "nn_fp16": "#dd6b20", "nn_4bit": "#4299e1",
    "nn_line": "#7ba7cc", "nn_line_l": "#b8d0e8", "nn_band": "#a8c8e8",
    "comp_a": "#805ad5", "comp_b": "#d53f8c",
    "text_main": "#1a1a1a", "text_sub": "#5a5a5a",
    "innov_bg": "#fff8e1", "innov_border": "#f9a825",
    "eq_bg": "#f8f9fa", "eq_border": "#adb5bd",
    "dash_color": "#94a3b8",
}

FIG_W, FIG_H = 18.0, 9.0
DPI = 220

fig = plt.figure(figsize=(FIG_W, FIG_H), dpi=DPI, facecolor=PALETTE["bg"])
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()
canvas.set_xlim(0, 1)
canvas.set_ylim(0, 1)


def label(x, y, text, size=10.3, weight="bold", color=None, ha="center", va="center"):
    canvas.text(x, y, text, transform=canvas.transData, fontsize=size,
                fontweight=weight, color=color or PALETTE["text_main"], ha=ha, va=va, zorder=25)


def arrow(x1, y1, x2, y2, lw=2.0, color=None, sc=14):
    canvas.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
        mutation_scale=sc, linewidth=lw, color=color or PALETTE["axis_color"],
        transform=canvas.transData, zorder=20))


def dashed_box(x, y, w, h, title, title_color):
    canvas.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0.005,rounding_size=0.015",
        transform=canvas.transData, facecolor="white",
        edgecolor=PALETTE["dash_color"], linewidth=1.2, linestyle=(0, (5, 3)), zorder=5))
    label(x + w / 2, y + h - 0.010, title, size=11.5, weight="bold", color=title_color)


def subax(rx, ry, rw, rh):
    return fig.add_axes([rx, ry, rw, rh])


def nn_subax(rx, ry, rw, rh):
    ax = subax(rx, ry, rw, rh)
    ax.set_xlim(0.02, 0.98); ax.set_ylim(-0.10, 1.02)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.patch.set_alpha(0.0)
    return ax


def draw_nn_col(ax, x, n, colors, r=0.032):
    sp = 0.76 / max(n - 1, 1); off = (1.0 - n * sp + sp) / 2
    out = []
    for i in range(n):
        y = off + i * sp
        ax.add_patch(plt.Circle((x, y), r, facecolor=colors[i],
                                edgecolor="white", linewidth=0.8, zorder=5))
        out.append((x, y))
    return out


def draw_connections(ax, prev, curr, color, alpha=0.5, lw=1.8):
    for px, py in prev:
        for cx, cy in curr:
            ax.plot([px + 0.032, cx - 0.032], [py, cy],
                    color=color, lw=lw, alpha=alpha, zorder=0, solid_capstyle="round")


def draw_band(ax, prev, curr, color, alpha=0.12):
    x1 = prev[0][0] + 0.032; x2 = curr[0][0] - 0.032
    yt = max(max(p[1] for p in prev), max(c[1] for c in curr)) + 0.04
    yb = min(min(p[1] for p in prev), min(c[1] for c in curr)) - 0.04
    ax.add_patch(Polygon([(x1, yb), (x2, yb), (x2, yt), (x1, yt)],
                         facecolor=color, edgecolor="none", alpha=alpha, zorder=-1))


def draw_small_nn(ax, x_off, y_off, w, h, NL, keep_sets=None, pr=None,
                  outlier_sets=None, color_map="keep", r=0.022):
    ax.set_xlim(x_off - 0.01, x_off + w + 0.01)
    ax.set_ylim(y_off - 0.01, y_off + h + 0.01)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.patch.set_alpha(0.0)

    prev_c = None
    for li, n in enumerate(NL):
        x = x_off + 0.08 + li * (w - 0.16) / max(len(NL) - 1, 1)
        sp = (h - 0.06) / max(n - 1, 1)
        off_y = y_off + h / 2 - (n - 1) * sp / 2
        cols = [PALETTE["nn_keep"]] * n
        if keep_sets and pr:
            cols = [PALETTE["nn_pruned"]] * n
            for k in keep_sets[li]: cols[k] = PALETTE["nn_keep"]
        if color_map == "quant" and keep_sets and outlier_sets:
            cols = [PALETTE["nn_pruned"]] * n
            for k in keep_sets[li]:
                cols[k] = PALETTE["nn_fp16"] if k in outlier_sets[li] else PALETTE["nn_4bit"]
        if color_map == "frozen" and keep_sets and outlier_sets:
            cols = [PALETTE["nn_pruned"]] * n
            for k in keep_sets[li]:
                base = PALETTE["nn_fp16"] if k in outlier_sets[li] else PALETTE["nn_4bit"]
                rc = mcolors.to_rgb(base)
                cols[k] = tuple(v * 0.6 + 0.4 * g for v, g in zip(rc, (0.55, 0.55, 0.55)))
        if color_map == "output" and keep_sets and outlier_sets:
            cols = [PALETTE["nn_pruned"]] * n
            for k in keep_sets[li]:
                base = PALETTE["nn_fp16"] if k in outlier_sets[li] else PALETTE["nn_4bit"]
                rc = mcolors.to_rgb(base)
                cols[k] = tuple(v * 0.65 + 0.35 * g for v, g in zip(rc, (0.18, 0.65, 0.32)))
        pts = []
        for i in range(n):
            y = off_y + i * sp
            ax.add_patch(plt.Circle((x, y), r, facecolor=cols[i],
                                    edgecolor="white", linewidth=0.5, zorder=5))
            pts.append((x, y))
        if prev_c is not None and keep_sets:
            prev_keep = keep_sets[li - 1] if li > 0 else set(range(n))
            curr_keep = keep_sets[li]
            for pi, (px, py) in enumerate(prev_c):
                if pi not in prev_keep:
                    continue
                for ci, (cx, cy) in enumerate(pts):
                    if ci not in curr_keep:
                        continue
                    ax.plot([px + r, cx - r], [py, cy], color=PALETTE["nn_line"],
                            lw=0.8, alpha=0.4, zorder=0, solid_capstyle="round")
        elif prev_c:
            for px, py in prev_c:
                for cx, cy in pts:
                    ax.plot([px + r, cx - r], [py, cy], color=PALETTE["nn_line"],
                            lw=0.8, alpha=0.4, zorder=0, solid_capstyle="round")
        prev_c = pts
    return prev_c


def draw_mask_matrix(ax, keep_sets, NL, pr):
    n_rows = sum(NL)
    n_cols = max(NL)
    mask = np.zeros((n_rows, n_cols))
    row = 0
    for li, (n, ks) in enumerate(zip(NL, keep_sets)):
        for i in range(n):
            if i in ks:
                mask[row + i, li] = 1.0
        row += n
    cm = colormaps["Blues"].copy()
    cm.set_bad("#f1f5f9")
    ax.imshow(mask, aspect="auto", cmap=cm, interpolation="nearest")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title("Pruning Mask $M_l$", fontsize=11.0, pad=3, fontweight="bold", color=PALETTE["s2_accent"])


def draw_activation_sensitivity(ax, act, outlier_idx):
    n = len(act)
    colors = ["#60a5fa"] * n
    for i in outlier_idx: colors[i] = PALETTE["nn_fp16"]
    ax.bar(range(n), act, color=colors, width=0.8)
    ax.axhline(y=np.quantile(act, 0.90), color="#ef4444", linewidth=0.8, linestyle="--", alpha=0.6)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#e2e8f0"); ax.spines["bottom"].set_color("#e2e8f0")
    ax.set_title("Activation Sensitivity", fontsize=11.0, pad=3, fontweight="bold", color=PALETTE["s2_accent"])


def draw_score_mini(ax, scores):
    ax.barh(range(len(scores)), scores, color="#67b7dc", height=0.7)
    ax.invert_yaxis(); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title("Importance Score", fontsize=8.5, pad=2, fontweight="bold", color=PALETTE["s1_accent"])


def draw_prob_mini(ax, probs):
    ax.barh(range(len(probs)), probs, color="#60a5fa", height=0.7)
    ax.invert_yaxis(); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title("Retention Prob.", fontsize=8.5, pad=2, fontweight="bold", color=PALETTE["s1_accent"])


def draw_curve_mini(ax):
    x = np.linspace(0, 1, 100)
    y1 = 0.45 + 0.22 * np.sin(2 * np.pi * x) * np.exp(-2.8 * x)
    y2 = 0.45 + 0.13 * np.sin(2 * np.pi * x + 0.08) * np.exp(-1.9 * x) + 0.04
    ax.plot(x, y1, color="#94a3b8", linewidth=1.2, linestyle="--")
    ax.plot(x, y2, color="#2d6a4f", linewidth=1.5)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title("Semantic Recovery", fontsize=8.5, pad=2, fontweight="bold", color=PALETTE["s3_accent"])


def draw_low_rank_mini(ax, B_data, A_data, delta_data):
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.patch.set_alpha(0.0)

    bx0, by0, bw, bh = 0.04, 0.10, 0.18, 0.78
    ax.imshow(B_data, aspect="auto", cmap="PuRd", extent=[bx0, bx0+bw, by0, by0+bh], interpolation="nearest", zorder=1)
    ax.add_patch(Rectangle((bx0, by0), bw, bh, fill=False, edgecolor=PALETTE["comp_b"], linewidth=1.5, zorder=2))
    ax.text(bx0+bw/2, by0-0.06, r"$B_l$", ha="center", va="center", fontsize=11.0, fontweight="bold", color=PALETTE["comp_b"])

    ax.text(0.28, 0.50, r"$\times$", ha="center", va="center", fontsize=12, fontweight="bold", color=PALETTE["text_main"])

    ax0, ay0, aw, ah = 0.34, 0.28, 0.18, 0.44
    ax.imshow(A_data, aspect="auto", cmap="PuBuGn", extent=[ax0, ax0+aw, ay0, ay0+ah], interpolation="nearest", zorder=1)
    ax.add_patch(Rectangle((ax0, ay0), aw, ah, fill=False, edgecolor=PALETTE["comp_a"], linewidth=1.5, zorder=2))
    ax.text(ax0+aw/2, ay0-0.06, r"$A_l$", ha="center", va="center", fontsize=11.0, fontweight="bold", color=PALETTE["comp_a"])

    ax.text(0.58, 0.50, r"$=$", ha="center", va="center", fontsize=12, fontweight="bold", color=PALETTE["text_main"])

    dx0, dy0, dw, dh = 0.64, 0.10, 0.30, 0.78
    ax.imshow(delta_data, aspect="auto", cmap="magma", extent=[dx0, dx0+dw, dy0, dy0+dh], interpolation="nearest", zorder=1)
    ax.add_patch(Rectangle((dx0, dy0), dw, dh, fill=False, edgecolor="#7f8c8d", linewidth=1.0, zorder=2))
    ax.text(dx0+dw/2, dy0-0.06, r"$\Delta W_l$", ha="center", va="center", fontsize=11.0, fontweight="bold", color=PALETTE["s3_accent"])

    ax.text(0.50, 0.96, "Low-Rank Decomp.", ha="center", va="center", fontsize=8.5, fontweight="bold", color=PALETTE["s3_accent"])


# ==================== Data Generation ====================

NL = [8, 7, 7, 6]
pr = [0.88, 0.62, 0.75, 0.50]
rng = np.random.default_rng(42)

keep_sets = []
for n, ratio in zip(NL, pr):
    nk = max(1, int(round(n * ratio)))
    keep_sets.append(set(rng.choice(n, nk, replace=False).tolist()))

outlier_sets = []
for n, ratio, ks in zip(NL, pr, keep_sets):
    no = max(1, int(len(ks) * 0.12))
    outlier_sets.append(set(rng.choice(list(ks), no, replace=False).tolist()))

distributed_outliers = []
for li, (n, ks) in enumerate(zip(NL, keep_sets)):
    ks_sorted = sorted(ks)
    if li == 0:
        idx = ks_sorted[len(ks_sorted) * 2 // 3]
    elif li == 1:
        idx = ks_sorted[min(len(ks_sorted) - 1, len(ks_sorted) // 3)]
    elif li == 2:
        idx = ks_sorted[-1]
    else:
        idx = ks_sorted[len(ks_sorted) // 2]
    distributed_outliers.append({idx})
outlier_sets = distributed_outliers

n_total = sum(NL)
scores = np.abs(np.random.randn(len(NL)))
scores = (scores - scores.min()) / (scores.max() - scores.min())
probs = np.clip(0.18 + 0.70 * scores, 0, 1)

n_valid = sum(len(ks) for ks in keep_sets)
act = np.random.gamma(shape=1.8, scale=1.0, size=n_valid)
topk = max(1, int(len(act) * 0.12))
outlier_idx = np.argsort(act)[-topk:]

B = np.random.randn(6, 18)
A = np.random.randn(n_valid, 6)
delta = np.random.randn(n_valid, 18)

# ==================== Layout ====================

PRUNE_BOX_X, PRUNE_BOX_Y, PRUNE_BOX_W, PRUNE_BOX_H = 0.18, 0.06, 0.30, 0.40
COMP_BOX_X, COMP_BOX_Y, COMP_BOX_W, COMP_BOX_H = 0.52, 0.06, 0.30, 0.40

PRUNE_CENTER = PRUNE_BOX_X + PRUNE_BOX_W / 2
COMP_CENTER = COMP_BOX_X + COMP_BOX_W / 2
QUANT_BOX_X = PRUNE_CENTER
QUANT_BOX_Y, QUANT_BOX_W, QUANT_BOX_H = 0.54, COMP_CENTER - PRUNE_CENTER, 0.42

AXIS_Y = 0.50
AXIS_LEFT = QUANT_BOX_X - 0.07
AXIS_RIGHT = QUANT_BOX_X + QUANT_BOX_W + 0.07



# ==================== Main Axis (U-shape: input→down→right→up→output) ====================

input_model_cx = QUANT_BOX_X - 0.07
output_model_cx = QUANT_BOX_X + QUANT_BOX_W + 0.07
model_bot_y = QUANT_BOX_Y + 0.04
axis_h_y = PRUNE_BOX_Y + PRUNE_BOX_H + 0.04

canvas.plot([input_model_cx, input_model_cx], [model_bot_y, axis_h_y],
            color=PALETTE["axis_color"], lw=2.5, transform=canvas.transData, zorder=10, solid_capstyle="round")
canvas.plot([input_model_cx, output_model_cx], [axis_h_y, axis_h_y],
            color=PALETTE["axis_color"], lw=2.5, transform=canvas.transData, zorder=10, solid_capstyle="round")
canvas.plot([output_model_cx, output_model_cx], [axis_h_y, model_bot_y],
            color=PALETTE["axis_color"], lw=2.5, transform=canvas.transData, zorder=10, solid_capstyle="round")
arrow(output_model_cx, model_bot_y - 0.01, output_model_cx, model_bot_y, lw=2.5, color=PALETTE["axis_color"], sc=18)


# ==================== Left: Original Model NN ====================

left_model_left = PRUNE_BOX_X
left_model_right = QUANT_BOX_X - 0.02
left_model_w = left_model_right - left_model_left
left_model_h = 0.34

left_box_x = left_model_left - 0.010
left_box_y = QUANT_BOX_Y + 0.04 - 0.010
left_box_w = left_model_w + 0.015
left_box_h = left_model_h + 0.050
dashed_box(left_box_x, left_box_y, left_box_w, left_box_h, "Input Model", PALETTE["nn_keep"])
label(left_box_x + left_box_w / 2, left_box_y + left_box_h - 0.028, "FP16 Full Precision", size=7.5, weight="normal", color=PALETTE["text_sub"])

a_left = nn_subax(left_model_left, QUANT_BOX_Y + 0.04, left_model_w, left_model_h)
prev_c = None
for li, n in enumerate(NL):
    x = 0.15 + li * (0.85 - 0.15) / max(len(NL) - 1, 1)
    c = draw_nn_col(a_left, x, n, [PALETTE["nn_keep"]] * n, r=0.030)
    if prev_c:
        draw_connections(a_left, prev_c, c, PALETTE["nn_line_l"], alpha=0.4, lw=1.5)
        draw_band(a_left, prev_c, c, PALETTE["nn_band"], alpha=0.10)
    prev_c = c

# ==================== Right: Compressed Model NN ====================

right_model_left = QUANT_BOX_X + QUANT_BOX_W + 0.02
right_model_right = COMP_BOX_X + COMP_BOX_W
right_model_w = right_model_right - right_model_left
right_model_h = 0.34

right_box_x = right_model_left - 0.005
right_box_y = QUANT_BOX_Y + 0.04 - 0.010
right_box_w = right_model_w + 0.020
right_box_h = right_model_h + 0.050
dashed_box(right_box_x, right_box_y, right_box_w, right_box_h, "Compressed Model", "#2e7d32")
label(right_box_x + right_box_w / 2, right_box_y + right_box_h - 0.028, "≈2.9-bit", size=7.5, weight="normal", color="#2e7d32")

a_right = nn_subax(right_model_left, QUANT_BOX_Y + 0.04, right_model_w, right_model_h)
prev_c = None
for li, (n, ratio) in enumerate(zip(NL, pr)):
    x = 0.15 + li * (0.85 - 0.15) / max(len(NL) - 1, 1)
    cols = [PALETTE["nn_pruned"]] * n
    for k in keep_sets[li]:
        base = PALETTE["nn_fp16"] if k in outlier_sets[li] else PALETTE["nn_4bit"]
        rc = mcolors.to_rgb(base)
        cols[k] = tuple(v * 0.65 + 0.35 * g for v, g in zip(rc, (0.18, 0.65, 0.32)))
    c = draw_nn_col(a_right, x, n, cols, r=0.025)
    if li > 0 and prev_c:
        kp = [(px, py) for i, (px, py) in enumerate(prev_c) if i in keep_sets[li - 1]]
        kc = [(cx, cy) for i, (cx, cy) in enumerate(c) if i in keep_sets[li]]
        draw_connections(a_right, kp, kc, "#90cdf4", alpha=0.45, lw=1.5)
    prev_c = c

for li in range(len(NL) - 1):
    x1 = 0.15 + li * (0.85 - 0.15) / max(len(NL) - 1, 1)
    x2 = 0.15 + (li + 1) * (0.85 - 0.15) / max(len(NL) - 1, 1)
    mid_x = (x1 + x2) / 2
    a_right.add_patch(Rectangle((mid_x - 0.07, -0.09), 0.06, 0.06,
        facecolor="#fce7f3", edgecolor=PALETTE["comp_a"], linewidth=0.8, zorder=7))
    a_right.text(mid_x - 0.04, -0.06, r"$A$", fontsize=7.0, ha="center", va="center",
        color=PALETTE["comp_a"], fontweight="bold", zorder=8)
    a_right.add_patch(Rectangle((mid_x + 0.01, -0.09), 0.06, 0.06,
        facecolor="#f3e8ff", edgecolor=PALETTE["comp_b"], linewidth=0.8, zorder=7))
    a_right.text(mid_x + 0.04, -0.06, r"$B$", fontsize=7.0, ha="center", va="center",
        color=PALETTE["comp_b"], fontweight="bold", zorder=8)
    a_right.annotate("", xy=(mid_x, 0.0), xytext=(mid_x, -0.09),
        arrowprops=dict(arrowstyle="-|>", color=PALETTE["s3_accent"], lw=1.5))

# ==================== Pruning Section (below axis, 上三下二 layout) ====================

dashed_box(PRUNE_BOX_X, PRUNE_BOX_Y, PRUNE_BOX_W, PRUNE_BOX_H,
           "Stage 1: Globally Adaptive Iterative Pruning", PALETTE["s1_accent"])

PB = (PRUNE_BOX_X, PRUNE_BOX_Y, PRUNE_BOX_W, PRUNE_BOX_H)
pb_pad = 0.015
pb_title_h = 0.028
pb_row_gap = 0.014
pb_col_gap = 0.010
pb_inner_w = PB[2] - 2 * pb_pad
pb_avail_h = PB[3] - pb_title_h - pb_row_gap - 0.030
pb_top_h = pb_avail_h * 0.50
pb_bot_h = pb_avail_h * 0.50

pb_top_bw = (pb_inner_w - 2 * pb_col_gap) / 3
pb_bot_bw = (pb_inner_w - 1 * pb_col_gap) / 2

top_y = PB[1] + PB[3] - pb_title_h - pb_top_h
bot_y = top_y - pb_row_gap - pb_bot_h

bx1 = PB[0] + pb_pad
bx2 = PB[0] + pb_pad + pb_top_bw + pb_col_gap
bx3 = PB[0] + pb_pad + 2 * (pb_top_bw + pb_col_gap)
bbx1 = PB[0] + pb_pad
bbx2 = PB[0] + pb_pad + pb_bot_bw + pb_col_gap

def small_dash(x, y, w, h, title, tc):
    canvas.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0.002,rounding_size=0.005",
        transform=canvas.transData, facecolor="#fafafa",
        edgecolor=tc, linewidth=0.6, linestyle=(0, (4, 2)), zorder=6))
    canvas.text(x + w / 2, y + h - 0.006, title, transform=canvas.transData,
                fontsize=7.2, fontweight="bold", color=tc, ha="center", va="center", zorder=7)

arr_c = PALETTE["s1_accent"]
arr_lw = 1.5
arr_sc = 10

# ① Importance Score - heatmap style
small_dash(bx1, top_y, pb_top_bw, pb_top_h, "① Importance Score", arr_c)
ax_s1 = subax(bx1 + 0.005, top_y + 0.006, pb_top_bw - 0.010, pb_top_h - 0.022)
n_layers = 4
n_dims = 6
s_matrix = np.array([
    [0.92, 0.45, 0.78, 0.31, 0.65, 0.18],
    [0.85, 0.52, 0.38, 0.71, 0.29, 0.60],
    [0.48, 0.90, 0.33, 0.67, 0.55, 0.82],
    [0.73, 0.40, 0.88, 0.22, 0.76, 0.47],
])
cm_s = colormaps["YlGnBu"]
ax_s1.imshow(s_matrix, aspect="auto", cmap=cm_s, interpolation="nearest", vmin=0, vmax=1)
for i in range(n_layers):
    for j in range(n_dims):
        ax_s1.text(j, i, f"{s_matrix[i,j]:.1f}", ha="center", va="center",
                   fontsize=7.6, color="white" if s_matrix[i,j] > 0.6 else "#1e3a5f", fontweight="bold")
ax_s1.set_xticks(range(n_dims))
ax_s1.set_xticklabels([f"d{j}" for j in range(n_dims)], fontsize=6.2, color=PALETTE["text_sub"])
ax_s1.set_yticks(range(n_layers))
ax_s1.set_yticklabels([f"L{j}" for j in range(n_layers)], fontsize=6.2, color=PALETTE["text_sub"])
ax_s1.tick_params(length=1, pad=0.5)
for s in ax_s1.spines.values(): s.set_visible(False)

# ② Retain Probability → Bernoulli Sampling (per-neuron)
small_dash(bx2, top_y, pb_top_bw, pb_top_h, "② Retention Prob.→Bernoulli", arr_c)
ax_s2 = subax(bx2 + 0.005, top_y + 0.006, pb_top_bw - 0.010, pb_top_h - 0.022)
ax_s2.set_xlim(0, 6); ax_s2.set_ylim(-1.5, 4.0)
ax_s2.set_xticks([]); ax_s2.set_yticks([])
for s in ax_s2.spines.values(): s.set_visible(False)
ax_s2.patch.set_alpha(0.0)

p_per_neuron = [
    [0.88, 0.45, 0.72, 0.30, 0.65, 0.20],
    [0.55, 0.82, 0.38, 0.70, 0.25, 0.60],
]
m_per_neuron = [
    [1, 0, 1, 0, 1, 0],
    [1, 1, 0, 1, 0, 1],
]
layer_labels = ["L1", "L2"]

for li in range(2):
    y_base = 2.5 - li * 2.5
    ax_s2.text(-0.3, y_base + 0.3, layer_labels[li], fontsize=9.7, ha="right", va="center",
        color=PALETTE["text_sub"], fontweight="bold")
    for ni in range(6):
        x_pos = 0.5 + ni * 0.9
        p_val = p_per_neuron[li][ni]
        m_val = m_per_neuron[li][ni]
        bar_h = p_val * 0.7
        ax_s2.add_patch(Rectangle((x_pos - 0.25, y_base - 0.1), 0.5, bar_h,
            facecolor="#60a5fa", edgecolor="white", linewidth=0.3, zorder=5))
        ax_s2.text(x_pos, y_base - 0.25, f"{p_val:.1f}", fontsize=7.6, ha="center", va="top",
            color="#3b82f6", zorder=6)
        m_color = "#2d6a4f" if m_val == 1 else "#ef4444"
        bg_color = "#d1fae5" if m_val == 1 else "#fee2e2"
        ax_s2.add_patch(Rectangle((x_pos - 0.3, y_base + 0.80), 0.65, 0.40,
            facecolor=bg_color, edgecolor=m_color, linewidth=0.5, zorder=5))
        ax_s2.text(x_pos + 0.02, y_base + 1.00, f"m={m_val}", fontsize=4, ha="center", va="center",
            color=m_color, fontweight="bold", zorder=6)
    ax_s2.annotate("Sample", xy=(5.8, y_base + 0.35), fontsize=5, ha="left", va="center",
        color=PALETTE["s1_accent"], fontweight="bold")

ax_s2.text(3.0, -1.0, r"$p_l[i]\!=\!\sigma(\theta_l),\; m_l[i]\!\sim\!B(p_l[i])$",
    fontsize=8.3, ha="center", va="center", color=PALETTE["s1_accent"])

# ③ Gated Forward + NLL Loss - with axis labels
small_dash(bx3, top_y, pb_top_bw, pb_top_h, "③ Gated Fwd. + NLL Loss", arr_c)
ax_s3 = subax(bx3 + 0.010, top_y + 0.030, pb_top_bw - 0.020, pb_top_h - 0.060)
x_ep = np.linspace(0, 1, 50)
y_loss = 2.5 * np.exp(-1.5 * x_ep) + 0.8 + 0.08 * np.random.randn(50) * np.exp(-x_ep)
y_ema = np.zeros_like(y_loss)
y_ema[0] = y_loss[0]
for t in range(1, len(y_ema)):
    y_ema[t] = 0.9 * y_ema[t-1] + 0.1 * y_loss[t]
ax_s3.plot(x_ep, y_loss, color="#94a3b8", linewidth=0.8, alpha=0.5, label="Raw")
ax_s3.plot(x_ep, y_ema, color=PALETTE["s1_accent"], linewidth=1.5, label="EMA Smoothed")
ax_s3.set_xlim(0, 1)
ax_s3.set_ylim(0.5, 3.5)
ax_s3.set_xlabel("Iteration Step", fontsize=9.5, color=PALETTE["text_sub"], labelpad=2)
ax_s3.set_ylabel("NLL Loss", fontsize=9.5, color=PALETTE["text_sub"], labelpad=2)
ax_s3.spines["top"].set_visible(False); ax_s3.spines["right"].set_visible(False)
ax_s3.spines["left"].set_color("#c0c0c0"); ax_s3.spines["bottom"].set_color("#c0c0c0")
ax_s3.set_xticks([0, 0.5, 1.0])
ax_s3.set_xticklabels(["0", "T/2", "T"], fontsize=6.9)
ax_s3.set_yticks([])
ax_s3.tick_params(axis="x", length=2, pad=2, colors=PALETTE["text_sub"])
ax_s3.patch.set_alpha(0.0)
ax_s3.legend(fontsize=5.8, loc="upper right", framealpha=0.5, bbox_to_anchor=(1.20, 1.05))

# ④ Pruned Model (bottom right)
small_dash(bbx2, bot_y, pb_bot_bw, pb_bot_h, "④ Pruned Model (Non-uniform Sparse)", arr_c)
a1 = nn_subax(bbx2 + 0.008, bot_y + 0.008, pb_bot_bw - 0.016, pb_bot_h - 0.024)
draw_small_nn(a1, 0.05, 0.05, 0.90, 0.90, NL, keep_sets, pr, color_map="keep", r=0.016)
for li, ratio in enumerate(pr):
    a1.text(0.08 + li * 0.28, -0.03, f"L{li+1}:{int(ratio*100)}%",
        ha="center", va="center", fontsize=6.9, color=PALETTE["s1_accent"], fontweight="bold",
        transform=a1.transAxes)

# ⑤ REINFORCE Update (bottom left) - θ and p comparison
small_dash(bbx1, bot_y, pb_bot_bw, pb_bot_h, "⑤ REINFORCE Gradient Update θ", arr_c)
ax_s5 = subax(bbx1 + 0.005, bot_y + 0.006, pb_bot_bw - 0.010, pb_bot_h - 0.022)
ax_s5.set_xlim(0, 10); ax_s5.set_ylim(0, 10)
ax_s5.set_xticks([]); ax_s5.set_yticks([])
for s in ax_s5.spines.values(): s.set_visible(False)
ax_s5.patch.set_alpha(0.0)

flow_c = PALETTE["s1_accent"]

# Left: θ before/after comparison
theta_before = [0.30, 0.50, 0.70, 0.40]
theta_after = [0.20, 0.62, 0.80, 0.32]
n_bars = len(theta_before)
bar_h = 0.6
x_left = 0.3
bar_max_w = 2.5

ax_s5.text(1.5, 9.2, "Policy θ", fontsize=7.5, ha="center", va="center",
    color=flow_c, fontweight="bold")
for i in range(n_bars):
    y_pos = 7.5 - i * 1.6
    ax_s5.add_patch(Rectangle((x_left, y_pos + 0.35), theta_before[i] * bar_max_w, bar_h,
        facecolor="#cbd5e0", edgecolor="white", linewidth=0.3, zorder=5))
    ax_s5.add_patch(Rectangle((x_left, y_pos - 0.35), theta_after[i] * bar_max_w, bar_h,
        facecolor=flow_c, edgecolor="white", linewidth=0.3, zorder=5))
    ax_s5.text(x_left - 0.1, y_pos, f"L{i+1}", fontsize=7.6, ha="right", va="center",
        color=PALETTE["text_sub"])

ax_s5.text(3.2, 8.8, "Before", fontsize=6.9, color="#94a3b8", ha="left")
ax_s5.text(3.2, 8.1, "After", fontsize=6.9, color=flow_c, ha="left")

# Center: REINFORCE formula
ax_s5.text(3.8, 5.5, "Policy\nGradient", fontsize=5, ha="center", va="center",
    color=flow_c, fontweight="bold")
ax_s5.text(3.8, 4.5, r"$\nabla_\theta E[L]$", fontsize=8.5, ha="center", va="center",
    color=flow_c, fontweight="bold")
ax_s5.text(3.8, 3.5, r"$= E[L \cdot \nabla_\theta \log p_\theta(m)]$",
    fontsize=5.0, ha="center", va="center", color=PALETTE["text_sub"])
ax_s5.text(3.8, 2.5, r"$\theta \leftarrow \theta - \eta \nabla_\theta E[L]$",
    fontsize=5.5, ha="center", va="center", color="#2563eb", fontweight="bold")

# Right: retain probability before/after
p_before = [0.57, 0.62, 0.67, 0.60]
p_after = [0.45, 0.65, 0.69, 0.54]
x_right = 5.5

ax_s5.text(6.5, 9.2, "Ret. Prob. p", fontsize=7, ha="center", va="center",
    color="#3b82f6", fontweight="bold")
for i in range(n_bars):
    y_pos = 7.5 - i * 1.6
    ax_s5.add_patch(Rectangle((x_right, y_pos + 0.35), p_before[i] * bar_max_w, bar_h,
        facecolor="#cbd5e0", edgecolor="white", linewidth=0.3, zorder=5))
    ax_s5.add_patch(Rectangle((x_right, y_pos - 0.35), p_after[i] * bar_max_w, bar_h,
        facecolor="#3b82f6", edgecolor="white", linewidth=0.3, zorder=5))
    ax_s5.text(x_right + bar_max_w + 0.1, y_pos + 0.15, f"{p_before[i]:.2f}→{p_after[i]:.2f}",
        fontsize=6.2, ha="left", va="center", color=PALETTE["text_sub"])

ax_s5.text(8.2, 8.8, "Before", fontsize=6.9, color="#94a3b8", ha="left")
ax_s5.text(8.2, 8.1, "After", fontsize=6.9, color="#3b82f6", ha="left")

# Arrows: θ → formula → p
ax_s5.annotate("", xy=(3.3, 5.8), xytext=(3.0, 7.0),
    arrowprops=dict(arrowstyle="-|>", color=flow_c, lw=1.0))
ax_s5.annotate("", xy=(5.5, 7.0), xytext=(4.3, 5.8),
    arrowprops=dict(arrowstyle="-|>", color="#3b82f6", lw=1.0))

# Arrows between boxes
top_mid_y = top_y + pb_top_h / 2
bot_mid_y = bot_y + pb_bot_h / 2

arrow(bx1 + pb_top_bw, top_mid_y + 0.006, bx2, top_mid_y + 0.006, lw=arr_lw, color=arr_c, sc=arr_sc)
label((bx1 + pb_top_bw + bx2) / 2, top_mid_y + 0.018, "Sigmoid", size=5.5, weight="bold", color=arr_c)

arrow(bx2 + pb_top_bw, top_mid_y + 0.006, bx3, top_mid_y + 0.006, lw=arr_lw, color=arr_c, sc=arr_sc)
label((bx2 + pb_top_bw + bx3) / 2 - 0.003, top_mid_y + 0.02, "Sample+\nGate", size=5.5, weight="bold", color=arr_c)

corner_y = (top_y + bot_y + pb_bot_h) / 2
canvas.plot([bx3 + pb_top_bw * 0.5, bx3 + pb_top_bw * 0.5, bbx2 + pb_bot_bw * 0.5],
    [top_y, corner_y, corner_y],
    color=arr_c, linewidth=arr_lw, transform=canvas.transData, zorder=10,
    solid_capstyle="round", solid_joinstyle="round")
arrow(bx3 + pb_top_bw * 0.5, corner_y, bbx2 + pb_bot_bw * 0.5, corner_y,
    lw=arr_lw, color=arr_c, sc=arr_sc)
arrow(bx3 + pb_top_bw * 0.5, top_y, bx3 + pb_top_bw * 0.5, corner_y,
    lw=arr_lw, color=arr_c, sc=arr_sc)
label(bx3 + pb_top_bw * 0.5 + 0.010, (top_y + corner_y) / 2 - 0.003, "Mask Apply", size=6.3, weight="bold", color=arr_c, ha="left")

arrow(bbx2 + 0.005, bot_mid_y, bbx1 + pb_bot_bw - 0.005, bot_mid_y, lw=arr_lw, color=arr_c, sc=arr_sc)
label((bbx2 + bbx1 + pb_bot_bw) / 2 + 0.005, bot_mid_y + 0.02, "NLL Feedback", size=5.5, weight="bold", color=arr_c)

loop_left_x = PB[0] - 0.020
loop_pts_x = [bbx1, loop_left_x, loop_left_x, bx2]
loop_pts_y = [bot_mid_y, bot_mid_y, top_mid_y, top_mid_y]
canvas.plot(loop_pts_x, loop_pts_y, color="#ef4444", linewidth=2.0, zorder=20,
    transform=canvas.transData, solid_capstyle="round", solid_joinstyle="round")
arrow(loop_pts_x[-2], loop_pts_y[-2], loop_pts_x[-1], loop_pts_y[-1], lw=2.0, color="#ef4444", sc=12)

loop_label_x = loop_left_x - 0.006
loop_label_y = (top_mid_y + bot_mid_y) / 2
canvas.text(loop_label_x + 0.005, loop_label_y, "Iterate", transform=canvas.transData,
    fontsize=12, fontweight="bold", color="#ef4444", ha="center", va="center", zorder=21)

canvas.add_patch(FancyBboxPatch((loop_left_x - 0.025, loop_label_y - 0.018), 0.050, 0.036,
    boxstyle="round,pad=0.003,rounding_size=0.006", transform=canvas.transData,
    facecolor="#fef2f2", edgecolor="#ef4444", linewidth=1.0, zorder=19))

eq_w = PB[2] * 0.95
canvas.add_patch(FancyBboxPatch((PB[0] + (PB[2] - eq_w)/2, PB[1] + 0.004), eq_w, 0.022,
    boxstyle="round,pad=0.002,rounding_size=0.006", transform=canvas.transData,
    facecolor=PALETTE["eq_bg"], edgecolor=PALETTE["eq_border"], linewidth=0.5, zorder=25))
canvas.text(PB[0] + PB[2]/2, PB[1] + 0.015,
            r"$\widetilde{W}_l = \mathrm{diag}(m_l) \cdot W_l$  (1) | Global 30% Pruning  (2)",
            transform=canvas.transData, fontsize=8.3, color=PALETTE["text_main"],
            ha="center", va="center", zorder=26)

# ==================== Quantization Section (above axis, 上二下二 layout) ====================

dashed_box(QUANT_BOX_X, QUANT_BOX_Y, QUANT_BOX_W, QUANT_BOX_H,
           "Stage 2: Dynamic Mask-Guided Mixed Quant.", PALETTE["s2_accent"])

QB = (QUANT_BOX_X, QUANT_BOX_Y, QUANT_BOX_W, QUANT_BOX_H)
qc = PALETTE["s2_accent"]
qb_pad = 0.010
qb_title_h = 0.028
qb_row_gap = 0.010
qb_col_gap = 0.008
qb_inner_w = QB[2] - 2 * qb_pad
qb_avail_h = QB[3] - qb_title_h - qb_row_gap - 0.028
qb_top_h = qb_avail_h * 0.50
qb_bot_h = qb_avail_h * 0.50
qb_top_bw = (qb_inner_w - qb_col_gap) / 2
qb_bot_bw = (qb_inner_w - qb_col_gap) / 2

qb_top_y = QB[1] + QB[3] - qb_title_h - qb_top_h
qb_bot_y = qb_top_y - qb_row_gap - qb_bot_h

qbx1 = QB[0] + qb_pad
qbx2 = QB[0] + qb_pad + qb_top_bw + qb_col_gap
qbx3 = QB[0] + qb_pad
qbx4 = QB[0] + qb_pad + qb_bot_bw + qb_col_gap

def qstep(x, y, w, h, title, tc):
    canvas.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0.002,rounding_size=0.005",
        transform=canvas.transData, facecolor="#fafafa",
        edgecolor=tc, linewidth=0.6, linestyle=(0, (4, 2)), zorder=6))
    canvas.text(x + w / 2, y + h - 0.006, title, transform=canvas.transData,
                fontsize=9.0, fontweight="bold", color=tc, ha="center", va="center", zorder=7)

qstep(qbx1, qb_top_y, qb_top_bw, qb_top_h, "① Mask Anchor Extract Valid Wt.", qc)
ax_q1 = subax(qbx1 + 0.004, qb_top_y + 0.004, qb_top_bw - 0.008, qb_top_h - 0.016)
ax_q1.set_xlim(0, 10); ax_q1.set_ylim(0, 7)
ax_q1.set_xticks([]); ax_q1.set_yticks([])
for s in ax_q1.spines.values(): s.set_visible(False)
ax_q1.patch.set_alpha(0.0)

layer_masks = [
    [1, 1, 1, 1, 0],
    [1, 0, 1, 0, 1],
    [1, 1, 0, 1, 1],
    [0, 1, 0, 1, 0],
]
layer_names = ["L1", "L2", "L3", "L4"]
n_neurons = 5
n_layers = 4

col_w = 1.0
col_gap = 0.1
col_start = 0.4
row_sp = 0.70
y_start = 4.6
cell_h = 0.48

for ni in range(n_neurons):
    y_row = y_start - ni * row_sp
    ax_q1.text(col_start - 0.08, y_row, f"n{ni}", fontsize=6.2, ha="right", va="center",
        color=PALETTE["text_sub"], fontweight="bold", zorder=6)

for li in range(n_layers):
    cx = col_start + li * (col_w + col_gap)
    ax_q1.text(cx + col_w / 2, y_start + 0.4, layer_names[li], fontsize=7.6,
        ha="center", va="center", color=qc, fontweight="bold")
    for ni in range(n_neurons):
        y_row = y_start - ni * row_sp
        is_kept = layer_masks[li][ni] == 1
        m_color = "#2d6a4f" if is_kept else "#ef4444"
        w_color = "#93c5fd" if is_kept else "#e2e8f0"
        row_bg = "#e8f5e9" if is_kept else "#fef2f2"

        ax_q1.add_patch(Rectangle((cx, y_row - cell_h / 2), col_w, cell_h,
            facecolor=row_bg, edgecolor=m_color, linewidth=0.4, zorder=2))
        ax_q1.text(cx + 0.15, y_row, f"{layer_masks[li][ni]}", fontsize=6.9,
            ha="center", va="center", color=m_color, fontweight="bold", zorder=6)
        ax_q1.add_patch(Rectangle((cx + 0.35, y_row - 0.16), col_w - 0.45, 0.32,
            facecolor=w_color, edgecolor="white", linewidth=0.2, zorder=5))

ax_q1.text(col_start + n_layers * (col_w + col_gap) / 2 - col_gap / 2 + 0.15, y_start + 0.9,
    r"$W_l$ (Multi-layer Wt.+Mask)", fontsize=7.6, ha="center", va="center",
    color=qc, fontweight="bold")

arr_x = col_start + n_layers * (col_w + col_gap) - col_gap + 0.15
ax_q1.annotate("", xy=(arr_x + 0.6, 3.0), xytext=(arr_x, 3.0),
    arrowprops=dict(arrowstyle="-|>", color=qc, lw=1.0))

valid_x = arr_x + 0.6
v_col_w = 1.0
v_col_gap = 0.1
for li in range(n_layers):
    cx = valid_x + li * (v_col_w + v_col_gap)
    kept = [ni for ni in range(n_neurons) if layer_masks[li][ni] == 1]
    ax_q1.text(cx + v_col_w / 2, y_start + 0.4, layer_names[li], fontsize=6.9,
        ha="center", va="center", color=qc, fontweight="bold")
    for ki, ni in enumerate(kept):
        y_row = y_start - ki * row_sp
        ax_q1.add_patch(Rectangle((cx, y_row - cell_h / 2), v_col_w, cell_h,
            facecolor="#e8f5e9", edgecolor="#2d6a4f", linewidth=0.4, zorder=2))
        ax_q1.text(cx + 0.12, y_row, f"n{ni}", fontsize=5.5, ha="center", va="center",
            color="#2d6a4f", fontweight="bold", zorder=6)
        ax_q1.add_patch(Rectangle((cx + 0.30, y_row - 0.16), v_col_w - 0.40, 0.32,
            facecolor="#60a5fa", edgecolor="white", linewidth=0.2, zorder=5))

ax_q1.text(valid_x + n_layers * (v_col_w + v_col_gap) / 2 - v_col_gap / 2, y_start + 0.9,
    r"$W_l^{valid}$", fontsize=7.6,
    ha="center", va="center", color=qc, fontweight="bold")

ax_q1.text(5.0, 0.5, r"$I_l\!=\!\{i|m_l[i]\!=\!1\}$", fontsize=7.6, ha="center", va="center",
    color=qc, fontweight="bold")
ax_q1.text(5.0, 0.0, r"$W_l^{valid}\!=\!W_l[I_l,:]$  Per-neuron Extract", fontsize=6.9,
    ha="center", va="center", color=PALETTE["text_sub"])

qstep(qbx2, qb_top_y, qb_top_bw, qb_top_h, "② Per-Layer Quant. Calib. (Valid Only)", qc)
ax_q2 = subax(qbx2 + 0.004, qb_top_y + 0.004, qb_top_bw - 0.008, qb_top_h - 0.016)
ax_q2.set_xlim(0, 10); ax_q2.set_ylim(0, 4)
ax_q2.set_xticks([]); ax_q2.set_yticks([])
for s in ax_q2.spines.values(): s.set_visible(False)
ax_q2.patch.set_alpha(0.0)

rng_q2 = np.random.default_rng(7)
w_valid = rng_q2.normal(0.0, 0.8, 40)
bins = np.linspace(-2.5, 2.5, 17)
counts, edges = np.histogram(w_valid, bins=bins)
max_c = max(counts) if max(counts) > 0 else 1
bar_w = (edges[1] - edges[0]) * 1.6
for k in range(len(counts)):
    bx = 0.5 + k * bar_w
    bh = counts[k] / max_c * 1.6
    ax_q2.add_patch(Rectangle((bx, 0.5), bar_w * 0.85, bh,
        facecolor="#bfdbfe", edgecolor="white", linewidth=0.2, zorder=5))

q_min_val, q_max_val = w_valid.min(), w_valid.max()
n_levels = 8
for k in range(n_levels):
    qval = q_min_val + (q_max_val - q_min_val) * k / (n_levels - 1)
    x_pos = 0.5 + (qval - bins[0]) / (bins[-1] - bins[0]) * (len(counts) * bar_w)
    ax_q2.plot([x_pos, x_pos], [2.5, 3.0], color="#ef4444", linewidth=0.8, zorder=7)
    if k % 2 == 0:
        ax_q2.text(x_pos, 3.05, f"{qval:.1f}", fontsize=5.5, ha="center", va="bottom",
            color="#ef4444", zorder=7)

ax_q2.plot([0.3, 9.0], [2.5, 2.5], color="#94a3b8", linewidth=0.5, zorder=6)
ax_q2.text(4.5, 3.5, "4-bit Quant. Discrete (Valid Wt. Only)", fontsize=7.6, ha="center", va="center",
    color="#ef4444", fontweight="bold")
ax_q2.text(4.5, 0.2, "Valid Weight Dist.", fontsize=8.3, ha="center", va="center",
    color=qc, fontweight="bold")
ax_q2.text(1.0, -0.1, f"min={q_min_val:.1f}", fontsize=6.9, ha="left", va="center", color="#ef4444")
ax_q2.text(8.5, -0.1, f"max={q_max_val:.1f}", fontsize=6.9, ha="right", va="center", color="#3b82f6")
ax_q2.text(7.5, 2.0, r"$\Delta_l\!=\!\frac{W_{max}^{valid}-W_{min}^{valid}}{2^b-1}$",
    fontsize=7.6, ha="center", va="center", color=qc)
ax_q2.text(7.5, 1.3, r"$z_l\!=\!-round(\frac{W_{min}^{valid}}{\Delta_l})$",
    fontsize=6.9, ha="center", va="center", color=PALETTE["text_sub"])

q_top_mid_y = qb_top_y + qb_top_h / 2
arrow(qbx1 + qb_top_bw, q_top_mid_y + 0.006, qbx2, q_top_mid_y + 0.006, lw=1.0, color=qc, sc=8)

qstep(qbx3, qb_bot_y, qb_bot_bw, qb_bot_h, "③ Activation Sensitivity → Outlier Dims", qc)
ax_q3 = subax(qbx3 + 0.004, qb_bot_y + 0.004, qb_bot_bw - 0.008, qb_bot_h - 0.016)
ax_q3.set_xlim(0, 10); ax_q3.set_ylim(0, 4)
ax_q3.set_xticks([]); ax_q3.set_yticks([])
for s in ax_q3.spines.values(): s.set_visible(False)
ax_q3.patch.set_alpha(0.0)

act_vals = [0.3, 0.9, 0.5, 1.2, 0.4, 0.7]
is_outlier = [False, True, False, True, False, False]
for i in range(6):
    bar_h = act_vals[i] * 2.5
    c = "#ef4444" if is_outlier[i] else "#60a5fa"
    ax_q3.add_patch(Rectangle((0.5 + i * 1.2, 0.3), 0.8, bar_h,
        facecolor=c, edgecolor="white", linewidth=0.3, zorder=5))
    ax_q3.text(0.9 + i * 1.2, 0.15, f"d{i}", fontsize=6.9, ha="center", va="center",
        color=PALETTE["text_sub"])

thresh_y = 0.3 + 0.8 * 2.5
ax_q3.plot([0.3, 7.8], [thresh_y, thresh_y], color="#f97316", linewidth=1.0, linestyle="--", zorder=7)
ax_q3.text(8.0, thresh_y, "Thresh.", fontsize=8.3, ha="left", va="center", color="#f97316", fontweight="bold")
ax_q3.text(9.0, 2.0, r"$a_l[i]\!=\!\|Act_l[:,i]\|_2$",
    fontsize=6.0, ha="center", va="center", color=qc)
ax_q3.text(9.0, 1.0, r"$thresh\!=\!Quantile_{1-p}$",
    fontsize=5.5, ha="center", va="center", color=PALETTE["text_sub"])

qstep(qbx4, qb_bot_y, qb_bot_bw, qb_bot_h, "④ Mixed-Precision Quant. Model", qc)
a2 = nn_subax(qbx4 + 0.004, qb_bot_y + 0.004, qb_bot_bw - 0.008, qb_bot_h - 0.016)
draw_small_nn(a2, 0.05, 0.05, 0.90, 0.90, NL, keep_sets, pr, outlier_sets, color_map="quant", r=0.020)
a2.text(1.02, 0.95, "FP16", ha="right", va="top", fontsize=6,
        fontweight="bold", color=PALETTE["nn_fp16"], transform=a2.transAxes)
a2.text(1.02, 0.85, "4-bit", ha="right", va="top", fontsize=6,    
        fontweight="bold", color=PALETTE["nn_4bit"], transform=a2.transAxes)

q_bot_mid_y = qb_bot_y + qb_bot_h / 2
arrow(qbx3 + qb_bot_bw, q_bot_mid_y + 0.006, qbx4, q_bot_mid_y + 0.006, lw=1.0, color=qc, sc=8)

# Bottom formula
eq_w2 = QB[2] * 0.95
canvas.add_patch(FancyBboxPatch((QB[0] + (QB[2] - eq_w2)/2, QB[1] + 0.004), eq_w2, 0.022,
    boxstyle="round,pad=0.002,rounding_size=0.006", transform=canvas.transData,
    facecolor=PALETTE["eq_bg"], edgecolor=PALETTE["eq_border"], linewidth=0.5, zorder=25))
canvas.text(QB[0] + QB[2]/2, QB[1] + 0.015,
            r"$\hat{W}^{valid}\!=\!M^{out}\!\odot\!W_{clip}\!+\!(1\!-\!M^{out})\!\odot\!Q_{4bit}$  (11)",
            transform=canvas.transData, fontsize=9.0, color=PALETTE["text_main"],
            ha="center", va="center", zorder=26)

# ==================== Compensation Section (below-right) ====================

dashed_box(COMP_BOX_X, COMP_BOX_Y, COMP_BOX_W, COMP_BOX_H,
           "Stage 3: Dim.-Aligned Semantic Recovery", PALETTE["s3_accent"])

CB = (COMP_BOX_X, COMP_BOX_Y, COMP_BOX_W, COMP_BOX_H)
cc = PALETTE["s3_accent"]
cb_pad = 0.010
cb_title_h = 0.028
cb_row_gap = 0.010
cb_col_gap = 0.008
cb_inner_w = CB[2] - 2 * cb_pad
cb_avail_h = CB[3] - cb_title_h - cb_row_gap - 0.028
cb_top_h = cb_avail_h * 0.50
cb_bot_h = cb_avail_h * 0.50
cb_top_bw = (cb_inner_w - cb_col_gap) / 2
cb_bot_bw = (cb_inner_w - cb_col_gap) / 2

cb_top_y = CB[1] + CB[3] - cb_title_h - cb_top_h
cb_bot_y = cb_top_y - cb_row_gap - cb_bot_h

cbx1 = CB[0] + cb_pad
cbx2 = CB[0] + cb_pad + cb_top_bw + cb_col_gap
cbx3 = CB[0] + cb_pad
cbx4 = CB[0] + cb_pad + cb_bot_bw + cb_col_gap

def cstep(x, y, w, h, title, tc):
    canvas.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0.002,rounding_size=0.005",
        transform=canvas.transData, facecolor="#fafafa",
        edgecolor=tc, linewidth=0.6, linestyle=(0, (4, 2)), zorder=6))
    canvas.text(x + w / 2, y + h - 0.006, title, transform=canvas.transData,
                fontsize=7.7, fontweight="bold", color=tc, ha="center", va="center", zorder=7)

cstep(cbx1, cb_top_y, cb_top_bw, cb_top_h, "① Dim.-Aligned Low-Rank Matrices", cc)
ax_c1 = subax(cbx1 + 0.004, cb_top_y + 0.004, cb_top_bw - 0.008, cb_top_h - 0.016)
ax_c1.set_xlim(0, 10); ax_c1.set_ylim(0, 6)
ax_c1.set_xticks([]); ax_c1.set_yticks([])
for s in ax_c1.spines.values(): s.set_visible(False)
ax_c1.patch.set_alpha(0.0)

ax_c1.text(2.5, 5.5, "Conventional (Dim. Mismatch)", fontsize=7.6, ha="center", va="center",
    color="#ef4444", fontweight="bold")
ax_c1.add_patch(Rectangle((0.3, 3.5), 1.8, 1.5,
    facecolor="#fee2e2", edgecolor="#ef4444", linewidth=0.6, zorder=5))
ax_c1.text(1.2, 4.6, r"$B_l'$", fontsize=9.7, ha="center", va="center",
    color="#ef4444", fontweight="bold", zorder=6)
ax_c1.text(1.2, 3.9, r"$d_{out}$×r", fontsize=6.2, ha="center", va="center", color="#ef4444")
ax_c1.text(2.5, 4.25, "×", fontsize=8, ha="center", va="center",
    color=PALETTE["text_main"], fontweight="bold")
ax_c1.add_patch(Rectangle((3.0, 3.8), 1.8, 0.9,
    facecolor="#fee2e2", edgecolor="#ef4444", linewidth=0.6, zorder=5))
ax_c1.text(3.9, 4.25, r"$A_l'$", fontsize=9.7, ha="center", va="center",
    color="#ef4444", fontweight="bold", zorder=6)
ax_c1.text(3.9, 3.5, r"r×$d_{in}$", fontsize=6.2, ha="center", va="center", color="#ef4444")
ax_c1.text(2.5, 3.0, "Contains pruned dims→Redundant", fontsize=6.9, ha="center", va="center",
    color="#ef4444")

ax_c1.plot([0.2, 4.9], [2.6, 2.6], color="#94a3b8", linewidth=0.4, linestyle="--")

ax_c1.text(2.5, 0, "Ours (Dim. Aligned)", fontsize=7.6, ha="center", va="center",
    color="#2d6a4f", fontweight="bold")
ax_c1.add_patch(Rectangle((0.3, 0.5), 1.8, 1.3,
    facecolor="#f3e8ff", edgecolor=PALETTE["comp_b"], linewidth=0.8, zorder=5))
ax_c1.text(1.2, 1.4, r"$B_l$", fontsize=9.7, ha="center", va="center",
    color=PALETTE["comp_b"], fontweight="bold", zorder=6)
ax_c1.text(1.2, 0.8, r"$d_{out}^{valid}$×r", fontsize=6.2, ha="center", va="center",
    color=PALETTE["comp_b"])
ax_c1.text(2.5, 1.15, "×", fontsize=8, ha="center", va="center",
    color=PALETTE["text_main"], fontweight="bold")
ax_c1.add_patch(Rectangle((3.0, 0.7), 1.8, 0.9,
    facecolor="#fce7f3", edgecolor=PALETTE["comp_a"], linewidth=0.8, zorder=5))
ax_c1.text(3.9, 1.15, r"$A_l$", fontsize=9.7, ha="center", va="center",
    color=PALETTE["comp_a"], fontweight="bold", zorder=6)
ax_c1.text(3.9, 0.4, r"r×$d_{in}^{valid}$", fontsize=6.2, ha="center", va="center",
    color=PALETTE["comp_a"])

ax_c1.annotate("", xy=(6.5, 1.15), xytext=(5.2, 1.15),
    arrowprops=dict(arrowstyle="-|>", color=cc, lw=1.0))
ax_c1.add_patch(Rectangle((6.5, 0.5), 3.2, 1.3,
    facecolor="#e8f5e9", edgecolor="#2d6a4f", linewidth=0.6, zorder=5))
ax_c1.text(8.1, 1.3, r"$B_l A_l$", fontsize=9.7, ha="center", va="center",
    color="#2d6a4f", fontweight="bold", zorder=6)
ax_c1.text(8.1, 0.7, r"$d_{out}^{valid}$×$d_{in}^{valid}$", fontsize=6.2,
    ha="center", va="center", color="#2d6a4f")

ax_c1.text(8.1, 2.2, "Strictly aligned to valid struct.", fontsize=7.6, ha="center", va="center",
    color="#2d6a4f", fontweight="bold")

cstep(cbx2, cb_top_y, cb_top_bw, cb_top_h, "② Rank Expansion Enhances Capacity", cc)
ax_c2 = subax(cbx2 + 0.004, cb_top_y + 0.004, cb_top_bw - 0.008, cb_top_h - 0.016)
ax_c2.set_xlim(0, 10); ax_c2.set_ylim(0, 4)
ax_c2.set_xticks([]); ax_c2.set_yticks([])
for s in ax_c2.spines.values(): s.set_visible(False)
ax_c2.patch.set_alpha(0.0)

r_vals = [4, 8, 16, 32, 64]
capacity = [0.12, 0.22, 0.38, 0.62, 1.0]
for i, (rv, cv) in enumerate(zip(r_vals, capacity)):
    x_pos = 0.8 + i * 1.7
    bar_h = cv * 2.5
    c = "#c4b5fd" if rv < 64 else PALETTE["s3_accent"]
    ax_c2.add_patch(Rectangle((x_pos, 0.5), 1.2, bar_h,
        facecolor=c, edgecolor="white", linewidth=0.3, zorder=5))
    ax_c2.text(x_pos + 0.6, 0.3, f"r={rv}", fontsize=6.2, ha="center", va="center",
        color=PALETTE["text_sub"])

ax_c2.text(5.0, 3.5, "Comp. Capacity vs Rank r", fontsize=8.3, ha="center", va="center",
    color=cc, fontweight="bold")
ax_c2.text(5.0, 0.0, "r=64, α=128 → Sufficient fittable subspace", fontsize=6.9, ha="center", va="center",
    color=PALETTE["s3_accent"], fontweight="bold")

c_top_mid_y = cb_top_y + cb_top_h / 2
arrow(cbx1 + cb_top_bw, c_top_mid_y + 0.006, cbx2, c_top_mid_y + 0.006, lw=1.0, color=cc, sc=8)

cstep(cbx3, cb_bot_y, cb_bot_bw, cb_bot_h, "③ Residual Forward Reconstruction", cc)
ax_c3 = subax(cbx3 + 0.004, cb_bot_y + 0.004, cb_bot_bw - 0.008, cb_bot_h - 0.016)
ax_c3.set_xlim(0, 10); ax_c3.set_ylim(0, 5)
ax_c3.set_xticks([]); ax_c3.set_yticks([])
for s in ax_c3.spines.values(): s.set_visible(False)
ax_c3.patch.set_alpha(0.0)

ax_c3.text(0.6, 2.5, "x", fontsize=9.7, ha="center", va="center",
    color=PALETTE["text_main"], fontweight="bold")
ax_c3.text(0.6, 1.8, "(Valid Input)", fontsize=6.2, ha="center", va="center",
    color=PALETTE["text_sub"])

ax_c3.annotate("", xy=(1.8, 3.5), xytext=(1.0, 2.7),
    arrowprops=dict(arrowstyle="-|>", color="#94a3b8", lw=0.8))
ax_c3.annotate("", xy=(1.8, 1.5), xytext=(1.0, 2.3),
    arrowprops=dict(arrowstyle="-|>", color=PALETTE["s3_accent"], lw=0.8))

ax_c3.add_patch(Rectangle((1.8, 3.2), 3.0, 0.8,
    facecolor="#e2e8f0", edgecolor="#94a3b8", linewidth=0.6, zorder=5))
ax_c3.text(3.3, 3.6, r"$x \cdot \bar{W}_l^T$", fontsize=7.6, ha="center", va="center",
    color="#64748b", fontweight="bold", zorder=6)
ax_c3.text(3.3, 4.2, "Frozen Backbone", fontsize=6.9, ha="center", va="center",
    color="#94a3b8")

ax_c3.add_patch(Rectangle((1.8, 1.2), 1.3, 0.7,
    facecolor="#fce7f3", edgecolor=PALETTE["comp_a"], linewidth=0.6, zorder=5))
ax_c3.text(2.45, 1.55, r"$A_l$", fontsize=8.3, ha="center", va="center",
    color=PALETTE["comp_a"], fontweight="bold", zorder=6)
ax_c3.annotate("", xy=(3.8, 1.55), xytext=(3.1, 1.55),
    arrowprops=dict(arrowstyle="-|>", color=PALETTE["s3_accent"], lw=0.8))
ax_c3.add_patch(Rectangle((3.8, 1.2), 1.3, 0.7,
    facecolor="#f3e8ff", edgecolor=PALETTE["comp_b"], linewidth=0.6, zorder=5))
ax_c3.text(4.45, 1.55, r"$B_l$", fontsize=8.3, ha="center", va="center",
    color=PALETTE["comp_b"], fontweight="bold", zorder=6)
ax_c3.text(3.2, 0.7, r"$\frac{\alpha}{r}x(B_lA_l)^T$", fontsize=6.9, ha="center", va="center",
    color=PALETTE["s3_accent"])

ax_c3.annotate("", xy=(6.5, 2.5), xytext=(4.8, 3.6),
    arrowprops=dict(arrowstyle="-|>", color="#94a3b8", lw=0.8))
ax_c3.annotate("", xy=(6.5, 2.5), xytext=(5.1, 1.55),
    arrowprops=dict(arrowstyle="-|>", color=PALETTE["s3_accent"], lw=0.8))

ax_c3.text(6.5, 2.5, "+", fontsize=9, ha="center", va="center",
    color=PALETTE["text_main"], fontweight="bold",
    bbox={"boxstyle": "round,pad=0.05", "facecolor": "white", "edgecolor": "#ccc", "linewidth": 0.3})

ax_c3.annotate("", xy=(8.0, 2.5), xytext=(7.0, 2.5),
    arrowprops=dict(arrowstyle="-|>", color=cc, lw=1.0))

ax_c3.add_patch(Rectangle((8.0, 2.0), 1.8, 1.0,
    facecolor="#e8f5e9", edgecolor=cc, linewidth=0.6, zorder=5))
ax_c3.text(8.9, 2.5, "h", fontsize=9.7, ha="center", va="center",
    color=cc, fontweight="bold", zorder=6)

ax_c3.text(5.0, 0.2, r"$h = x\bar{W}_l^T + \frac{\alpha}{r}x(B_lA_l)^T$",
    fontsize=6.9, ha="center", va="center", color=cc, fontweight="bold")

cstep(cbx4, cb_bot_y, cb_bot_bw, cb_bot_h, "④ Frozen Backbone + Fine-tune Comp.", cc)
ax_c4 = subax(cbx4 + 0.004, cb_bot_y + 0.004, cb_bot_bw - 0.008, cb_bot_h - 0.016)
ax_c4.set_xlim(0, 10); ax_c4.set_ylim(0, 6)
ax_c4.set_xticks([]); ax_c4.set_yticks([])
for s in ax_c4.spines.values(): s.set_visible(False)
ax_c4.patch.set_alpha(0.0)

nn_x_positions = [1.5, 3.5, 5.5, 7.5]
nn_y_spacing = 0.45
nn_r = 0.15
nn_y_base = 4.5

for li in range(len(NL)):
    n = NL[li]
    cx = nn_x_positions[li]
    kept = keep_sets[li]
    sp = (3.5 - 0.5) / max(n - 1, 1)
    base_y = 0.5
    for ni in range(n):
        cy = base_y + ni * sp
        is_kept = ni in kept
        c = "#e2e8f0" if is_kept else "#f8fafc"
        ec = "#94a3b8" if is_kept else "#e2e8f0"
        ax_c4.add_patch(Circle((cx, cy), nn_r, facecolor=c, edgecolor=ec,
            linewidth=0.4, zorder=5))

    if li > 0:
        prev_kept = keep_sets[li - 1]
        prev_n = NL[li - 1]
        prev_sp = (3.5 - 0.5) / max(prev_n - 1, 1)
        for pi in prev_kept:
            py = 0.5 + pi * prev_sp
            for ci in kept:
                cy = 0.5 + ci * sp
                ax_c4.plot([nn_x_positions[li-1] + nn_r, cx - nn_r], [py, cy],
                    color="#94a3b8", lw=0.3, alpha=0.3, zorder=0)

for li in range(len(NL) - 1):
    cx = (nn_x_positions[li] + nn_x_positions[li + 1]) / 2
    comp_y = 4.5

    ax_c4.add_patch(Rectangle((cx - 0.55, comp_y - 0.22), 0.50, 0.44,
        facecolor="#fce7f3", edgecolor=PALETTE["comp_a"], linewidth=0.5, zorder=7))
    ax_c4.text(cx - 0.30, comp_y, r"$A_l$", fontsize=6.2, ha="center", va="center",
        color=PALETTE["comp_a"], fontweight="bold", zorder=8)
    ax_c4.add_patch(Rectangle((cx + 0.05, comp_y - 0.22), 0.50, 0.44,
        facecolor="#f3e8ff", edgecolor=PALETTE["comp_b"], linewidth=0.5, zorder=7))
    ax_c4.text(cx + 0.30, comp_y, r"$B_l$", fontsize=6.2, ha="center", va="center",
        color=PALETTE["comp_b"], fontweight="bold", zorder=8)

    ax_c4.annotate("", xy=(cx, comp_y - 0.22),
        xytext=(cx, 3.5 + nn_r + 0.1),
        arrowprops=dict(arrowstyle="-|>", color=PALETTE["s3_accent"], lw=0.5))

ax_c4.text(5.0, 5.5, "Backbone Frozen (Gray) + Comp. Fine-tuned (Color)", fontsize=5.5, ha="center", va="center",
    color=cc, fontweight="bold")
ax_c4.text(5.0, 0.2, "Only update A,B params", fontsize=6.9, ha="center", va="center",
    color=PALETTE["s3_accent"], fontweight="bold")

c_bot_mid_y = cb_bot_y + cb_bot_h / 2
arrow(cbx3 + cb_bot_bw, c_bot_mid_y + 0.006, cbx4, c_bot_mid_y + 0.006, lw=1.0, color=cc, sc=8)

eq_w3 = CB[2] * 0.95
canvas.add_patch(FancyBboxPatch((CB[0] + (CB[2] - eq_w3)/2, CB[1] + 0.004), eq_w3, 0.022,
    boxstyle="round,pad=0.002,rounding_size=0.006", transform=canvas.transData,
    facecolor=PALETTE["eq_bg"], edgecolor=PALETTE["eq_border"], linewidth=0.5, zorder=25))
canvas.text(CB[0] + CB[2]/2, CB[1] + 0.015,
            r"$A_l \in \mathbb{R}^{r \times d_{in}^{valid}}, B_l \in \mathbb{R}^{d_{out}^{valid} \times r}$  (15)",
            transform=canvas.transData, fontsize=9.0, color=PALETTE["text_main"],
            ha="center", va="center", zorder=26)

# ==================== Vertical Connections (axis ↔ sections) ====================

prune_mid = PRUNE_BOX_X + PRUNE_BOX_W / 2
quant_mid = QUANT_BOX_X + QUANT_BOX_W / 2
comp_mid = COMP_BOX_X + COMP_BOX_W / 2

v_offset = 0.008

arrow(prune_mid - v_offset, axis_h_y - 0.005, prune_mid - v_offset, PRUNE_BOX_Y + PRUNE_BOX_H + 0.005,
      lw=1.2, color=PALETTE["s1_accent"], sc=8)
arrow(prune_mid + v_offset, PRUNE_BOX_Y + PRUNE_BOX_H + 0.005, prune_mid + v_offset, axis_h_y - 0.005,
      lw=1.2, color=PALETTE["s1_accent"], sc=8)

prune_vmid = (axis_h_y + PRUNE_BOX_Y + PRUNE_BOX_H) / 2
label(prune_mid - 0.01, prune_vmid + 0.005, "Full Model",
      size=7, weight="bold", color=PALETTE["s1_accent"], ha="right")
label(prune_mid + 0.01, prune_vmid - 0.005, "Pruned+Mask M",
      size=7, weight="bold", color="#2e7d32", ha="left")

arrow(quant_mid - v_offset, axis_h_y + 0.005, quant_mid - v_offset, QUANT_BOX_Y,
      lw=1.2, color=PALETTE["s2_accent"], sc=8)
arrow(quant_mid + v_offset, QUANT_BOX_Y, quant_mid + v_offset, axis_h_y + 0.005,
      lw=1.2, color=PALETTE["s2_accent"], sc=8)

quant_vmid = (axis_h_y + QUANT_BOX_Y) / 2
label(quant_mid - 0.01, quant_vmid + 0.005, "Pruned+Mask M",
      size=7, weight="bold", color=PALETTE["s2_accent"], ha="right")
label(quant_mid + 0.01, quant_vmid - 0.005, "Quantized",
      size=7, weight="bold", color=PALETTE["s2_accent"], ha="left")

arrow(comp_mid - v_offset, axis_h_y - 0.005, comp_mid - v_offset, COMP_BOX_Y + COMP_BOX_H + 0.005,
      lw=1.2, color=PALETTE["s3_accent"], sc=8)
arrow(comp_mid + v_offset, COMP_BOX_Y + COMP_BOX_H + 0.005, comp_mid + v_offset, axis_h_y - 0.005,
      lw=1.2, color=PALETTE["s3_accent"], sc=8)

comp_vmid = (axis_h_y + COMP_BOX_Y + COMP_BOX_H) / 2
label(comp_mid - 0.01, comp_vmid + 0.005, "Quantized",
      size=7, weight="bold", color=PALETTE["s3_accent"], ha="right")
label(comp_mid + 0.01, comp_vmid - 0.005, "Compressed",
      size=7, weight="bold", color=PALETTE["s3_accent"], ha="left")

# ==================== Section Flow on Axis ====================

arrow(quant_mid - QUANT_BOX_W/2 - 0.005, axis_h_y,
      prune_mid + PRUNE_BOX_W/2 + 0.005, axis_h_y,
      lw=1.5, color="#475569", sc=10)
arrow(comp_mid - COMP_BOX_W/2 - 0.005, axis_h_y,
      quant_mid + QUANT_BOX_W/2 + 0.005, axis_h_y,
      lw=1.5, color="#475569", sc=10)

label(prune_mid + 0.005, axis_h_y + 0.015, "① Pruning", size=8.0, weight="bold", color=PALETTE["s1_accent"], ha="left")
label(quant_mid + 0.005, axis_h_y - 0.015, "② Quantization", size=8.0, weight="bold", color=PALETTE["s2_accent"], ha="left")
label(comp_mid + 0.005, axis_h_y + 0.015, "③ Compensation", size=8.0, weight="bold", color=PALETTE["s3_accent"], ha="left")

# ==================== Legend ====================

legend_x, legend_y = 0.35, 0.005
legend_w, legend_h = 0.30, 0.035
canvas.add_patch(FancyBboxPatch((legend_x, legend_y), legend_w, legend_h,
    boxstyle="round,pad=0.003,rounding_size=0.008", transform=canvas.transData,
    facecolor="#fafafa", edgecolor="#e0e0e0", linewidth=0.5, zorder=30))
items = [("Kept", PALETTE["nn_keep"]), ("4-bit", PALETTE["nn_4bit"]),
         ("FP16", PALETTE["nn_fp16"]), ("Pruned", PALETTE["nn_pruned"]),
         ("Comp.", "#b8e6c8")]
xo = legend_x + 0.01
for t, c in items:
    canvas.add_patch(Rectangle((xo, legend_y + legend_h/2 - 0.004), 0.008, 0.008,
        facecolor=c, edgecolor="#9e9e9e", linewidth=0.3, transform=canvas.transData, zorder=31))
    canvas.text(xo + 0.011, legend_y + legend_h/2, t, transform=canvas.transData,
                fontsize=7.6, color=PALETTE["text_sub"], ha="left", va="center", zorder=31)
    xo += 0.058

# ==================== Save ====================

out = Path(__file__).resolve().parent
fig.savefig(out / "sparsecascade_overall_pipeline_v3.png", bbox_inches="tight", facecolor=PALETTE["bg"])
fig.savefig(out / "sparsecascade_overall_pipeline_v3.svg", bbox_inches="tight", facecolor=PALETTE["bg"])
plt.close(fig)
print("v3 done")
