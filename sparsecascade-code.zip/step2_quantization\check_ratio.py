
import torch
import os
import glob
import argparse

def check_fp16_ratio(mask_dir):
    print(f"Checking FP16 ratio in {mask_dir}...")
    
    mask_files = glob.glob(os.path.join(mask_dir, "*_mask.pth"))
    if not mask_files:
        print("No mask files found!")
        return

    total_elements = 0
    fp16_elements = 0
    
    for f in mask_files:
        mask = torch.load(f, map_location='cpu')
        total_elements += mask.numel()
        fp16_elements += mask.sum().item()
        
    ratio = fp16_elements / total_elements
    print(f"Total Elements (Channels): {total_elements}")
    print(f"FP16 Elements (Channels): {fp16_elements}")
    print(f"FP16 Ratio: {ratio:.6f} ({ratio*100:.4f}%)")
    
    return ratio

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mask_dir", type=str, required=True, help="Directory containing the mask files")
    args = parser.parse_args()
    
    check_fp16_ratio(args.mask_dir)
