from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

np.random.seed(11)

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = True

fig = plt.figure(figsize=(6.2, 3.9), dpi=220, facecolor="white")
canvas = fig.add_axes([0, 0, 1, 1])
canvas.set_axis_off()


def label(x, y, text, size=9.0, weight="normal", color="#334155", ha="center"):
    canvas.text(
        x,
        y,
        text,
        transform=canvas.transAxes,
        fontsize=size,
        fontweight=weight,
        color=color,
        ha=ha,
        va="center",
        zorder=20,
    )


panel = FancyBboxPatch(
    (0.08, 0.14),
    0.84,
    0.68,
    boxstyle="round,pad=0.004,rounding_size=0.018",
    linewidth=1.0,
    edgecolor="#dbe4ee",
    facecolor="white",
    transform=canvas.transAxes,
)
canvas.add_patch(panel)

canvas.text(
    0.50,
    0.77,
    "Prior Effect: Search Stability of Importance Prior Initialization",
    transform=canvas.transAxes,
    ha="center",
    va="center",
    fontsize=9.5,
    fontweight="bold",
    color="#2563eb",
)

canvas.add_patch(
    FancyBboxPatch(
        (0.28, 0.83),
        0.44,
        0.05,
        boxstyle="round,pad=0.003,rounding_size=0.01",
        linewidth=0.9,
        edgecolor="#38bdf8",
        facecolor="#e0f2fe",
        transform=canvas.transAxes,
        zorder=10,
    )
)
label(0.50, 0.855, "Importance Prior Init. vs Random Init.", size=8.0, weight="bold", color="#1f2937")
label(0.50, 0.71, "Prior init. reduces early search fluctuation and accelerates convergence", size=7.8, weight="bold", color="#2563eb")

ax = fig.add_axes([0.16, 0.28, 0.54, 0.38])
x = np.arange(1, 11)
with_prior = np.array([3.18, 2.72, 2.46, 2.28, 2.19, 2.15, 2.12, 2.10, 2.09, 2.08])
without_prior = np.array([3.52, 3.33, 3.05, 2.90, 2.67, 2.59, 2.50, 2.46, 2.38, 2.34])

ax.plot(x, without_prior, color="#94a3b8", linewidth=2.0, marker="o", markersize=3.3, linestyle="--", label="Random Init.")
ax.plot(x, with_prior, color="#2563eb", linewidth=2.2, marker="o", markersize=3.3, label="Importance Prior Init.")
ax.fill_between(x, with_prior, without_prior, where=without_prior >= with_prior, color="#bfdbfe", alpha=0.45)
ax.axvline(5, color="#93c5fd", linewidth=1.0, linestyle=":", alpha=0.9)
ax.text(5.15, 2.22, "Earlier stable zone", fontsize=6.5, color="#2563eb", fontweight="bold")

ax.set_xlim(1, 10)
ax.set_ylim(2.0, 3.65)
ax.set_xticks([1, 3, 5, 7, 9])
ax.set_xlabel("Iteration Step", fontsize=8.0, fontweight="bold", color="#334155", labelpad=4)
ax.set_ylabel("Calibration Loss", fontsize=8.0, fontweight="bold", color="#334155", labelpad=4)
ax.tick_params(axis="both", labelsize=7.0)
ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35)
ax.legend(frameon=False, fontsize=7.0, loc="upper right")
for spine in ax.spines.values():
    spine.set_visible(False)

hint = FancyBboxPatch(
    (0.74, 0.33),
    0.14,
    0.18,
    boxstyle="round,pad=0.004,rounding_size=0.012",
    linewidth=0.9,
    edgecolor="#bfdbfe",
    facecolor="#eff6ff",
    transform=canvas.transAxes,
    zorder=10,
)
canvas.add_patch(hint)
label(0.81, 0.47, "Key Benefit", size=8.0, weight="bold", color="#1d4ed8")
label(0.81, 0.42, "Faster Conv.", size=7.2, weight="bold", color="#334155")
label(0.81, 0.37, "Less Fluct.", size=7.2, weight="bold", color="#334155")

label(0.50, 0.17, "Importance prior provides a stable starting point, giving high-value dimensions earlier retention tendency", size=6.2, weight="bold", color="#475569")

output_dir = Path(__file__).resolve().parent
fig.savefig(output_dir / "sparsecascade_method_3_1_prior_effect.png", bbox_inches="tight", facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_prior_effect.pdf", bbox_inches="tight", pad_inches=0, facecolor="white")
fig.savefig(output_dir / "sparsecascade_method_3_1_prior_effect.svg", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("done")
