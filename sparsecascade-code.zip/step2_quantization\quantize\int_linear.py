import torch
import torch.nn as nn
import torch.nn.functional as F
from quantize.quantizer import UniformAffineQuantizer






class QuantLinear(nn.Module):
    """
    Quantized Module that can perform quantized convolution or normal convolution.
    To activate quantization, please use set_quant_state function.
    """
    def __init__(
        self,
        org_module: nn.Linear,
        weight_quant_params: dict = {},
        act_quant_params: dict = {},
        disable_input_quant=False,
    ):
        super().__init__()
        self.fwd_kwargs = dict()
        self.fwd_func = F.linear
        self.register_buffer('weight',org_module.weight)
        if org_module.bias is not None:
            self.register_buffer('bias',org_module.bias)
        else:
            self.bias = None
        self.in_features = org_module.in_features
        self.out_features = org_module.out_features
        # de-activate the quantized forward default
        self.use_weight_quant = False
        self.use_act_quant = False
        # initialize quantizer
        self.weight_quantizer = UniformAffineQuantizer(**weight_quant_params,shape=org_module.weight.shape)
        if not disable_input_quant:
            self.act_quantizer = UniformAffineQuantizer(**act_quant_params)
        else:
            self.act_quantizer = None

        self.disable_input_quant = disable_input_quant
        self.use_temporary_parameter = False
        
        # LoRA params
        self.lora_r = 0
        self.lora_A = None
        self.lora_B = None
        self.lora_scaling = 1.0

    def enable_lora(self, r=16, lora_alpha=16, dropout=0.0):
        self.lora_r = r
        if r > 0:
            import math
            self.lora_dropout = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
            # LoRA A: [r, in_features]
            self.lora_A = nn.Parameter(torch.zeros(r, self.in_features))
            # LoRA B: [out_features, r]
            self.lora_B = nn.Parameter(torch.zeros(self.out_features, r))
            self.lora_scaling = lora_alpha / r
            
            # Init
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
            nn.init.zeros_(self.lora_B)
            
            # Freeze main weights
            self.weight.requires_grad = False
            if self.bias is not None:
                self.bias.requires_grad = False
    
    
    def forward(self, input: torch.Tensor):
        if self.use_temporary_parameter:
            weight = self.temp_weight
            bias = self.temp_bias
        elif self.use_weight_quant:
            weight = self.weight_quantizer(self.weight)
            bias = self.bias
        else:
            weight = self.weight
            bias = self.bias

        if self.use_act_quant and not self.disable_input_quant:
            input = self.act_quantizer(input)
        
        # --- FIX: Ensure dtype consistency ---
        if weight.dtype != input.dtype:
            weight = weight.to(input.dtype)
        if bias is not None and bias.dtype != input.dtype:
            bias = bias.to(input.dtype)
        # -------------------------------------

        out = self.fwd_func(input, weight, bias, **self.fwd_kwargs)
        
        # LoRA bypass
        if self.lora_r > 0 and self.lora_A is not None:
            # input: [batch, seq, in]
            # lora_A: [r, in]
            # lora_B: [out, r]
            # out += (input @ A.T @ B.T) * scaling
            
            # Cast to float32 for stability during training, then cast back
            orig_dtype = input.dtype
            x = input.to(torch.float32)
            if hasattr(self, 'lora_dropout'):
                x = self.lora_dropout(x)
            lora_out = (x @ self.lora_A.t().to(torch.float32) @ self.lora_B.t().to(torch.float32)) * self.lora_scaling
            out = out + lora_out.to(orig_dtype)

        return out

    def set_quant_state(self, weight_quant: bool = False, act_quant: bool = False):
        self.use_weight_quant = weight_quant
        self.use_act_quant = act_quant
