import os
import sys
import time
import torch
import argparse
import numpy as np
from tqdm import tqdm

# Add path to import LlamaForCausalLM from Step 1 code
current_dir = os.path.dirname(os.path.abspath(__file__))
pruning_code_path = os.path.join(current_dir, "../../step1_pruning/prune_channel")
sys.path.append(pruning_code_path)

from models.LMClass import LMClass
from datautils import get_loaders

def benchmark(args):
    # 1. Load Model
    print(f"Loading model: {args.model} ...")
    lm = LMClass(args)
    lm.model.eval()
    lm.model = lm.model.to(lm.device)

    # 2. Prepare Input
    # Use a dummy input or a real sentence
    input_text = "The quick brown fox jumps over the lazy dog" * 10 # Make it long enough
    
    # We need a tokenizer. LMClass doesn't expose tokenizer directly usually, 
    # but let's try to get it from the model's config or load a default one.
    # Assuming standard Llama tokenizer
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=False, trust_remote_code=True)
    
    inputs = tokenizer(input_text, return_tensors="pt").to(lm.device)
    input_ids = inputs.input_ids

    # 3. Warmup
    print("Warming up...")
    with torch.no_grad():
        for _ in range(5):
            lm.model(input_ids)
    
    # Reset memory stats before benchmark
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    # 4. Benchmark Generation (End-to-End)
    # We will measure the time to generate N tokens
    num_tokens_to_generate = 100
    print(f"Benchmarking generation of {num_tokens_to_generate} tokens...")
    
    start_time = time.time()
    
    # Simple generation loop
    curr_input = input_ids
    with torch.no_grad():
        for _ in range(num_tokens_to_generate):
            outputs = lm.model(curr_input)
            next_token_logits = outputs.logits[:, -1, :]
            next_token = torch.argmax(next_token_logits, dim=-1).unsqueeze(0)
            curr_input = torch.cat([curr_input, next_token], dim=1)
            
    end_time = time.time()
    total_time = end_time - start_time
    speed = num_tokens_to_generate / total_time
    
    # Measure memory
    max_memory_gb = 0.0
    if torch.cuda.is_available():
        max_memory_gb = torch.cuda.max_memory_allocated() / (1024 ** 3)
    
    print(f"\n{'='*30}")
    print(f"Result for model: {args.model}")
    print(f"Quantization: {args.wbits}-bit / {args.abits}-bit")
    print(f"Total Time: {total_time:.4f} s")
    print(f"Generated Tokens: {num_tokens_to_generate}")
    print(f"Inference Speed: {speed:.2f} Tokens/s")
    print(f"Max Memory Usage: {max_memory_gb:.2f} GB")
    print(f"{'='*30}\n")
    
    return speed

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Basic args needed for LMClass
    parser.add_argument("--model", type=str, required=True, help="Path to model or huggingface name")
    parser.add_argument("--net", type=str, default=None)
    parser.add_argument("--cache_dir", default="./cache", type=str)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=2)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--multigpu", action="store_true")
    
    # Quantization args (must match what you trained)
    parser.add_argument("--wbits", type=int, default=16)
    parser.add_argument("--abits", type=int, default=16)
    parser.add_argument("--group_size", type=int, default=None)
    parser.add_argument("--symmetric", action="store_true")
    parser.add_argument("--w_dynamic_method", type=str, default="per_channel")
    parser.add_argument("--a_dynamic_method", type=str, default="per_token")
    parser.add_argument("--lwc", action="store_true")
    parser.add_argument("--let", action="store_true")
    
    # Pruning args
    parser.add_argument("--prune_info_path", type=str, default=None)
    
    args = parser.parse_args()
    
    if args.net is None:
        args.net = args.model.split('/')[-1]
        if "llama" not in args.net.lower():
            args.net = "Llama-2-7b"
            
    args.model_family = args.net.split('-')[0]
    
    benchmark(args)
