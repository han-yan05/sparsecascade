import torch
import os
import argparse
import torch.nn as nn
import functools
from tqdm import tqdm
from datautils import get_loaders
from models.LMClass import LMClass
import sys

# Ensure we can import from local utils if needed
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def get_act_scales(model, dataloader, num_samples=128):
    model.eval()
    device = next(model.parameters()).device
    act_scales = {}

    def stat_tensor(name, tensor): 
        # tensor shape might be [batch, seq, hidden_dim]
        hidden_dim = tensor.shape[-1] 
        tensor = tensor.view(-1, hidden_dim).abs().detach() 
        comming_max = torch.max(tensor, dim=0)[0].float().cpu() 
        if name in act_scales:
            act_scales[name] = torch.max(act_scales[name], comming_max)
        else:
            act_scales[name] = comming_max

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name)))

    print("Collecting activation scales...")
    with torch.no_grad():
        for i in tqdm(range(num_samples)):
            model(dataloader[i][0].to(device))

    for h in hooks:
        h.remove()

    return act_scales 

def get_act_shifts(model, dataloader, num_samples=128):
    model.eval()
    device = next(model.parameters()).device
    act_shifts = {}

    def stat_tensor(name, tensor):
        hidden_dim = tensor.shape[-1]
        tensor = tensor.view(-1, hidden_dim).detach()
        comming_max = torch.max(tensor, dim=0)[0].float().cpu()
        comming_min = torch.min(tensor, dim=0)[0].float().cpu()
        if name in act_shifts:
            act_shifts[name] = 0.99*act_shifts[name] + 0.01 *((comming_max+comming_min)/2)
        else:
            act_shifts[name] = (comming_max+comming_min)/2

    def stat_input_hook(m, x, y, name):
        if isinstance(x, tuple):
            x = x[0]
        stat_tensor(name, x)

    hooks = []
    for name, m in model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(
                m.register_forward_hook(
                    functools.partial(stat_input_hook, name=name))
            )

    print("Collecting activation shifts...")
    with torch.no_grad():
        for i in tqdm(range(num_samples)):
            model(dataloader[i][0].to(device))

    for h in hooks:
        h.remove()

    return act_shifts

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, help='model name or path', required=True)
    parser.add_argument('--prune_info_path', type=str, default=None, help='path to prune_info.pt')
    parser.add_argument('--scales-output-path', type=str, default='./act_scales/',
                        help='where to save the act scales')
    parser.add_argument('--shifts-output-path', type=str, default='./act_shifts/',
                        help='where to save the act shifts')
    parser.add_argument("--calib_dataset",type=str,default="wikitext2",
        choices=["wikitext2", "ptb", "c4", "mix","pile"],
        help="Where to extract calibration data from.",)
    parser.add_argument('--num-samples', type=int, default=128)
    parser.add_argument('--seq-len', type=int, default=2048)
    parser.add_argument("--seed", type=int, default=2, help="Seed for sampling the calibration data.")
    parser.add_argument("--batch_size", type=int, default=1, help="batch size")
    parser.add_argument("--output_dir", type=str, default=None, help="Dummy arg for compatibility")
    
    args = parser.parse_args()
    return args

@torch.no_grad()
def main():
    args = parse_args()
    
    # Initialize LMClass to handle loading and pruning
    print(f"Loading model from {args.model} with pruning info {args.prune_info_path}...")
    lm = LMClass(args)
    model = lm.model
    
    # Get dataloader
    print("Loading calibration data...")
    dataloader, _ = get_loaders(
        args.calib_dataset,
        nsamples=args.num_samples,
        seed=args.seed,
        model=args.model,
        seqlen=lm.seqlen,
    )
    
    # Determine net name for saving
    if args.model.endswith('/'):
        args.model = args.model[:-1]
    args.net = os.path.basename(args.model)
    if args.prune_info_path:
        args.net += "_pruned" # Differentiate from dense scales
    
    # Generate and save scales
    act_scales = get_act_scales(model, dataloader, args.num_samples)
    
    # Use explicit output path if provided via output_dir (custom logic)
    # But here we stick to scales-output-path
    save_path_scales = os.path.join(args.scales_output_path, f'{args.net}.pt')
    os.makedirs(os.path.dirname(save_path_scales), exist_ok=True)
    torch.save(act_scales, save_path_scales)
    print(f"Saved activation scales to {save_path_scales}")

    # Generate and save shifts
    act_shifts = get_act_shifts(model, dataloader, args.num_samples)
    save_path_shifts = os.path.join(args.shifts_output_path, f'{args.net}.pt')
    os.makedirs(os.path.dirname(save_path_shifts), exist_ok=True)
    torch.save(act_shifts, save_path_shifts)
    print(f"Saved activation shifts to {save_path_shifts}")

if __name__ == '__main__':
    main()
