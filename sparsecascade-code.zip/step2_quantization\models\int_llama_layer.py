import torch
from torch import nn
from typing import Optional, Tuple, List
from quantize.int_linear import QuantLinear
from quantize.int_matmul import QuantMatMul
import torch.nn.functional as F
from quantize.ptq_norm import PTQLlamaRMSNorm
from collections import OrderedDict
import math
from transformers.models.llama.modeling_llama import LlamaRotaryEmbedding,apply_rotary_pos_emb,LlamaRMSNorm,repeat_kv
from transformers.models.llama.configuration_llama import LlamaConfig
from transformers.activations import ACT2FN
import pdb
import copy
from models.transformation import *



def high_quant(w, wbits,dev):
    maxq = torch.tensor(2 ** wbits - 1)
    shape = w.shape
    w = w.flatten(1)
    tmp = torch.zeros(w.shape[0], device=dev)  # TODO
    wmin = torch.minimum(w.min(1)[0], tmp)
    wmax = torch.maximum(w.max(1)[0], tmp)
    tmp = (wmin == 0) & (wmax == 0)
    wmin[tmp] = -1
    wmax[tmp] = +1
    high_scale = (wmax - wmin) / maxq
    
    # Avoid division by zero
    high_scale = torch.where(high_scale == 0, torch.ones_like(high_scale), high_scale)
    
    high_zero = torch.round(-wmin / high_scale)
    shape = [-1] + [1] * (len(shape) - 1)
    high_scale = high_scale.reshape(shape)
    high_zero = high_zero.reshape(shape)
    q = torch.clamp(torch.round(w / high_scale) + high_zero, 0, maxq)

    return high_scale * (q - high_zero)

class QuantLlamaMLP(nn.Module):
    def __init__(
        self,
        org_module: nn.Module,
        hidden_size: int,
        intermediate_size: int,
        hidden_act: str,
        args=None,
    ):
        super().__init__()
        # self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        # self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)
        # self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.gate_proj = QuantLinear(org_module.gate_proj,
                                           args.weight_quant_params,
                                           args.act_quant_params)
        self.down_proj = QuantLinear(org_module.down_proj,
                                           args.weight_quant_params,
                                           args.act_quant_params)
        self.up_proj = QuantLinear(org_module.up_proj,
                                           args.weight_quant_params,
                                           args.act_quant_params)
        self.act_fn = ACT2FN[hidden_act]

    def forward(self, x):
        return self.down_proj(self.act_fn(self.gate_proj(x)) * self.up_proj(x))


class QuantLlamaAttention(nn.Module):
    """Multi-headed attention from 'Attention Is All You Need' paper"""

    def __init__(self, 
                 org_module: nn.Module,
                 config: LlamaConfig,
                 args=None):
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.hidden_size // self.num_heads
        self.num_key_value_heads = config.num_key_value_heads
        self.num_key_value_groups = self.num_heads // self.num_key_value_heads
        self.max_position_embeddings = config.max_position_embeddings

        if (self.head_dim * self.num_heads) != self.hidden_size:
            raise ValueError(
                f"hidden_size must be divisible by num_heads (got `hidden_size`: {self.hidden_size}"
                f" and `num_heads`: {self.num_heads})."
            )

        self.rotary_emb = copy.deepcopy(org_module.rotary_emb)

        self.k_proj = QuantLinear(
            org_module.k_proj,
            args.weight_quant_params,
            args.act_quant_params,
        )
        self.v_proj = QuantLinear(
            org_module.v_proj,
            args.weight_quant_params,
            args.act_quant_params,
        )
        self.q_proj = QuantLinear(
            org_module.q_proj,
            args.weight_quant_params,
            args.act_quant_params,
        )
        self.o_proj = QuantLinear(
            org_module.o_proj, args.weight_quant_params, args.act_quant_params
        )
        self.qkt_matmul = QuantMatMul(
            args.q_quant_params, args.k_quant_params, matmul_func=torch.matmul
        )
        self.pv_matmul = QuantMatMul(
            args.p_quant_params, args.v_quant_params, matmul_func=torch.matmul
        )

        self.use_weight_quant = False
        self.use_act_quant = False

    def _shape(self, tensor: torch.Tensor, seq_len: int, bsz: int):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        bsz, q_len, _ = hidden_states.size()

        # query_states = self.q_proj(hidden_states)
        # key_states = self.k_proj(hidden_states)
        # value_states = self.v_proj(hidden_states)
        
        # Adaptive reshaping for pruned models
        q_out = self.q_proj(hidden_states)
        k_out = self.k_proj(hidden_states)
        v_out = self.v_proj(hidden_states)
        
        num_heads = q_out.shape[-1] // self.head_dim
        num_key_value_heads = k_out.shape[-1] // self.head_dim
        num_key_value_groups = num_heads // num_key_value_heads
        
        query_states = q_out.view(bsz, q_len, num_heads, self.head_dim).transpose(1, 2)
        key_states = k_out.view(bsz, q_len, num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = v_out.view(bsz, q_len, num_key_value_heads, self.head_dim).transpose(1, 2)

        kv_seq_len = key_states.shape[-2]
        if past_key_value is not None:
            kv_seq_len += past_key_value[0].shape[-2]
        # Updated for transformers >= 4.38
        cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len)
        # cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)


        # [bsz, nh, t, hd]

        if past_key_value is not None:
            # reuse k, v, self_attention
            key_states = torch.cat([past_key_value[0], key_states], dim=2)
            value_states = torch.cat([past_key_value[1], value_states], dim=2)

        past_key_value = (key_states, value_states) if use_cache else None

        # repeat k/v heads if n_kv_heads < n_heads
        key_states = repeat_kv(key_states, num_key_value_groups)
        value_states = repeat_kv(value_states, num_key_value_groups)
        
        query_states = self.qkt_matmul.quant_x1(query_states)
        key_states = self.qkt_matmul.quant_x2(key_states)
        attn_weights = self.qkt_matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

        if attn_weights.size() != (bsz, num_heads, q_len, kv_seq_len):
            raise ValueError(
                f"Attention weights should be of size {(bsz, num_heads, q_len, kv_seq_len)}, but is"
                f" {attn_weights.size()}"
            )

        if attention_mask is not None:
            # Fix shape mismatch for evaluate (4096 vs 2048)
            # if attention_mask.size(-1) != attn_weights.size(-1):
            #     # Crop mask to match attn_weights
            #     diff = attention_mask.size(-1) - attn_weights.size(-1)
            #     if diff > 0:
            #         attention_mask = attention_mask[..., :attn_weights.size(-2), :attn_weights.size(-1)]
            
            if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
                raise ValueError(
                    f"Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}"
                )
            attn_weights = attn_weights + attention_mask
            attn_weights = torch.max(attn_weights, torch.tensor(torch.finfo(attn_weights.dtype).min))

        # upcast attention to fp32
        attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_weights = self.pv_matmul.quant_x1(attn_weights)
        value_states = self.pv_matmul.quant_x2(value_states)
        attn_output = self.pv_matmul(attn_weights, value_states)

        if attn_output.size() != (bsz, num_heads, q_len, self.head_dim):
            raise ValueError(
                f"`attn_output` should be of size {(bsz, num_heads, q_len, self.head_dim)}, but is"
                f" {attn_output.size()}"
            )

        attn_output = attn_output.transpose(1, 2)
        # attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)
        attn_output = attn_output.reshape(bsz, q_len, num_heads * self.head_dim)

        attn_output = self.o_proj(attn_output)

        if not output_attentions:
            attn_weights = None

        return attn_output, attn_weights, past_key_value
    
    def set_quant_state(self, weight_quant: bool = False, act_quant: bool = False):
        # setting weight quantization here does not affect actual forward pass
        self.use_weight_quant = weight_quant
        self.use_act_quant = act_quant
        for m in self.modules():
            if isinstance(m, (QuantLinear, QuantMatMul)):
                m.set_quant_state(weight_quant, act_quant)
                


class QuantLlamaDecoderLayer(nn.Module):
    def __init__(self, 
                 config: LlamaConfig,
                 ori_layer,
                 args):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.self_attn = QuantLlamaAttention(
            org_module=ori_layer.self_attn,
            config=config,
            args=args,
            )
        self.mlp = QuantLlamaMLP(
            org_module=ori_layer.mlp,
            hidden_size=self.hidden_size,
            intermediate_size=config.intermediate_size,
            hidden_act=config.hidden_act,
            args=args,
        )
        self.input_layernorm = PTQLlamaRMSNorm(ori_layer.input_layernorm,eps=ori_layer.input_layernorm.variance_epsilon)
        self.post_attention_layernorm = PTQLlamaRMSNorm(ori_layer.post_attention_layernorm,eps=ori_layer.post_attention_layernorm.variance_epsilon)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        **kwargs,
    ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        """
        Args:
            hidden_states (`torch.FloatTensor`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`torch.FloatTensor`, *optional*): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
            use_cache (`bool`, *optional*):
                If set to `True`, `past_key_values` key value states are returned and can be used to speed up decoding
                (see `past_key_values`).
            past_key_value (`Tuple(torch.FloatTensor)`, *optional*): cached past key and value projection states
        """
        residual = hidden_states

        hidden_states = self.input_layernorm(hidden_states)


        # Self Attention
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )
        hidden_states = residual + hidden_states

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        

        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (self_attn_weights,)

        if use_cache:
            outputs += (present_key_value,)

        return outputs        

    def set_quant_state(self, weight_quant: bool = False, act_quant: bool = False):
        # setting weight quantization here does not affect actual forward pass
        self.use_weight_quant = weight_quant
        self.use_act_quant = act_quant
        names = []
        for name, m in self.named_modules():
            if isinstance(m, (QuantLinear, QuantMatMul)):
                names.append(name)
                m.set_quant_state(weight_quant, act_quant)
      
    def binary_temporary(self, wbits, dev, quant_type):
        for name, module in self.named_modules():
            if isinstance(module, QuantLinear):
                module.temp_weight = module.weight
        # quant
        for name, module in self.named_modules():
            if isinstance(module, QuantLinear):
                name_tmp = name.replace(".","_")
                if hasattr(module, "temp_weight"):
                    scale = getattr(self, f"{name_tmp}_scaling_factors")
                    mean = getattr(self, f"{name_tmp}_scaling_means")
                    mask = getattr(self, f"{name_tmp}_mask")
                    r1 = getattr(self, f"{name_tmp}_scaling_rotate_1").to(dev)
                    r2 = getattr(self, f"{name_tmp}_scaling_rotate_2").to(dev)

                    if quant_type == "mix":
                        q_high = high_quant(module.temp_weight.clone(), wbits, dev)
                        q_high = q_high * mask
                        
                        # Modified for Higher Precision (Dual-Scale 4-bit)
                        # We use 4-bit quantization for Fat weights instead of 1-bit sign
                        q_low = module.temp_weight.clone()
                        q_low = q_low * ~mask # Mask FIRST to isolate Fat
                        
                        # Use high_quant (same bits as Salient) for Fat
                        # This creates a Dual-Scale 4-bit quantization
                        q_low = high_quant(q_low, wbits, dev)
                        
                        # Apply Learned Rank-1 Scaling (Retain PTQ1.61 optimization)
                        q_low = q_low * (r1@r2) 
                        
                        # Ensure masking
                        q_low = q_low * ~mask

                        module.temp_weight = q_low + q_high
                    else:
                        module.temp_weight = module.temp_weight - mean
                        module.temp_weight = module.temp_weight.sign()
                        module.temp_weight = module.temp_weight * scale
                        module.temp_weight += mean
                        module.temp_weight = r1@r2 * module.temp_weight #r1 * module.temp_weight * r2

                else:
                    scale = getattr(self, f"{name_tmp}_scaling_factors")
                    mean = getattr(self, f"{name_tmp}_scaling_means")
                    mask = getattr(self, f"{name_tmp}_mask")
                    r1 = getattr(self, f"{name_tmp}_scaling_rotate_1")
                    r2 = getattr(self, f"{name_tmp}_scaling_rotate_2")

                    if quant_type == "mix":
                        q_high = high_quant(module.weight.clone(), wbits, dev)
                        q_high = q_high * mask

                        # Modified for Higher Precision (Dual-Scale 4-bit)
                        q_low = module.weight.clone()
                        q_low = q_low * ~mask # Mask FIRST

                        q_low = high_quant(q_low, wbits, dev)
                        
                        q_low = q_low * (r1@r2)
                        q_low = q_low * ~mask

                        module.temp_weight = q_low + q_high
                    else:
                        module.temp_weight = module.weight - mean
                        module.temp_weight = module.temp_weight.sign()
                        module.temp_weight = module.temp_weight * scale
                        module.temp_weight += mean
                        module.temp_weight = r1@r2 * module.temp_weight #r1 * module.temp_weight * r2

                if not hasattr(module, "temp_bias"):
                    module.temp_bias = module.bias
                module.use_temporary_parameter=True

    @torch.no_grad()    
    def binary_inplace(self, wbits, dev, quant_type):
        for name, module in self.named_modules():
            if isinstance(module, QuantLinear):
                # module.weight = module.weight_quantizer(module.weight)
                name_tmp = name.replace(".","_")
                scale = getattr(self, f"{name_tmp}_scaling_factors")
                mean = getattr(self, f"{name_tmp}_scaling_means")
                mask = getattr(self, f"{name_tmp}_mask")
                r1 = getattr(self, f"{name_tmp}_scaling_rotate_1")
                r2 = getattr(self, f"{name_tmp}_scaling_rotate_2")

                if quant_type == "mix":
                    q_high = high_quant(module.weight.clone(), wbits, dev)
                    q_high = q_high * mask

                    # Modified for Higher Precision (Dual-Scale 4-bit)
                    q_low = module.weight.clone()
                    q_low = q_low * ~mask # Mask FIRST

                    q_low = high_quant(q_low, wbits, dev)
                    
                    q_low = q_low * (r1@r2)
                    q_low = q_low * ~mask

                    module.weight = q_low + q_high
                else:
                    module.weight = module.weight - mean
                    module.weight = module.weight.sign()
                    module.weight = module.weight * scale
                    module.weight += mean
                    module.weight = r1@r2 * module.weight #r1 * module.weight *r2

                module.use_temporary_parameter=False
    

    def clear_temp_variable(self):
       for name, module in self.named_modules():
            if isinstance(module, QuantLinear):
                del module.temp_weight
                del module.temp_bias
    

    def scaling_parameters(self):
        params = []
        template = "scaling_factors" 
        for n, m in self.named_parameters():
            if n.find(template) > -1:
                params.append(m)
        return iter(params) 
    
    def rotation_parameters(self):
        params = []
        template = "scaling_rotate" 
        for n, m in self.named_parameters():
            if n.find(template) > -1:
                params.append(m)
        return iter(params) 

    def binary_parameters(self):
        params = []
        template = "scaling"
        for n, m in self.named_parameters():
            if n.find(template) > -1:
                params.append(m)
        return iter(params)  
    
    def PTQ_state_dict(self, destination=None, prefix='', keep_vars=False):
        if destination is None:
            destination = OrderedDict()
        for name, param in self.named_parameters():
            if name.find('smooth') > -1 or name.find('bound_factor') > -1:
                destination[prefix + name] = param if keep_vars else param.detach()
        return destination
    
    def register_scales_and_zeros(self):
        for name, module in self.named_modules():
            if isinstance(module, QuantLinear):
                module.weight_quantizer.register_scales_and_zeros()