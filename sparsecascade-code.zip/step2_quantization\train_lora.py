import sys
sys.path.append(".")
import argparse
import os
import torch
import random
import numpy as np
import torch.nn as nn
from transformers import (
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    TrainingArguments,
    Trainer
)
from datautils import get_loaders
from models.LMClass import LMClass
from quantize.int_linear import QuantLinear
from models.int_llama_layer import QuantLlamaDecoderLayer

class QATDataset(torch.utils.data.Dataset):
    def __init__(self, data_list):
        self.data = data_list
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        return {"input_ids": self.data[idx][0].squeeze(0), "labels": self.data[idx][1].squeeze(0)}

def enable_lora_for_model(model, args):
    print("Enabling LoRA for QuantLinear layers...")
    count = 0
    for name, module in model.named_modules():
        if isinstance(module, QuantLinear):
            target_keywords = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']
            if any(k in name for k in target_keywords):
                module.enable_lora(r=args.lora_r, lora_alpha=args.lora_alpha, dropout=args.lora_dropout)
                count += 1
    print(f"Enabled LoRA for {count} layers.")
    
    for n, p in model.named_parameters():
        if "lora_" in n:
            p.requires_grad = True
        else:
            p.requires_grad = False
            
    return model

def print_trainable_parameters(model):
    trainable_params = 0
    all_param = 0
    for _, param in model.named_parameters():
        all_param += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()
    print(
        f"trainable params: {trainable_params} || all params: {all_param} || trainable%: {100 * trainable_params / all_param}"
    )

class LoRATrainer(Trainer):
    def save_model(self, output_dir=None, _internal_call=False):
        if output_dir is None:
            output_dir = self.args.output_dir
        os.makedirs(output_dir, exist_ok=True)
        print(f"Saving LoRA checkpoint to {output_dir}...")
        
        # Only save LoRA parameters
        model_to_save = self.model
        state_dict = model_to_save.state_dict()
        lora_state_dict = {k: v for k, v in state_dict.items() if "lora_" in k}
        
        torch.save(lora_state_dict, os.path.join(output_dir, "pytorch_model.bin"))

def main(args):
    print(f"Loading Ragged Quantized Model...")
    
    class DummyArgs:
        def __init__(self):
            self.model = args.model_id
            self.cache_dir = "./cache"
            self.use_fast_tokenizer = False
            self.trust_remote_code = False
            self.flash_attn = False
            self.net = args.model_id.split('/')[-1]
            self.prune_info_path = args.prune_info_path
            self.wbits = args.wbits
            self.abits = args.abits
            self.quant_type = args.quant_type
            self.group_size = args.group_size
            self.act_scales = args.act_scales
            self.act_shifts = args.act_shifts
            self.limit = -1
            self.multigpu = False
            self.deactive_amp = False
            self.epochs = 0
            self.let = False
            self.lwc = False
            self.aug_loss = False
            self.symmetric = False
            self.a_dynamic_method = "per_token"
            self.w_dynamic_method = "per_channel"
            self.eval_ppl = False
            self.tasks = ""
            self.output_dir = args.output_dir
            self.save_dir = None
            self.resume = None
            self.real_quant = False
            self.calib_dataset = "wikitext2"
            self.nsamples = 128
            self.batch_size = 1
            self.seed = args.seed
            self.num_fewshot = 0

    lm_args = DummyArgs()
    lm = LMClass(lm_args)
    
    # Try loading quantized checkpoint if available (e.g. mix_4_current.pth)
    ckpt_path = os.path.join(args.output_dir, f"{args.quant_type}_{args.wbits}_current.pth")
    if os.path.exists(ckpt_path):
        print(f"Loading quantized checkpoint from {ckpt_path}...")
        lm.model.load_state_dict(torch.load(ckpt_path), strict=False)
    else:
        print(f"Warning: No quantized checkpoint found at {ckpt_path}. Using initial weights.")

    model = lm.model
    tokenizer = lm.tokenizer

    # Inject Quantization Layers
    print("Replacing layers with QuantLlamaDecoderLayer...")
    args.weight_quant_params = {
        "n_bits": args.wbits,
        "per_channel_axes": [0],
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_channel",
    }
    args.act_quant_params = {
        "n_bits": args.abits,
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_token",
    }
    args.q_quant_params = {
        "n_bits": args.abits,
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_token",
    }
    args.k_quant_params = {
        "n_bits": args.abits,
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_token",
    }
    args.v_quant_params = {
        "n_bits": args.abits,
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_token",
    }
    args.p_quant_params = {
        "n_bits": args.abits,
        "symmetric": False,
        "metric": "minmax",
        "dynamic_method": "per_token",
    }
    
    layers = model.model.layers
    for i in range(len(layers)):
        layers[i] = QuantLlamaDecoderLayer(model.config, layers[i], args)
    print("Layer replacement done.")
    
    # Enable Quantization (Weight Only for Mix Mode)
    print("Enabling Quantization (Weight Only)...")
    def set_model_quant_state(model, weight_quant, act_quant):
        for name, module in model.named_modules():
            if hasattr(module, "set_quant_state"):
                module.set_quant_state(weight_quant, act_quant)
    
    # Enable weight quantization to simulate 4-bit forward pass
    set_model_quant_state(model, weight_quant=True, act_quant=False)
    
    # Enable LoRA
    model = enable_lora_for_model(model, args)
    
    # Enable input gradients for gradient checkpointing
    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()
    else:
        def make_inputs_require_grad(module, input, output):
            output.requires_grad_(True)
        model.get_input_embeddings().register_forward_hook(make_inputs_require_grad)
    
    # Ensure model is on GPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    print(f"Model moved to {device}")
    
    # Clear memory after loading and moving
    torch.cuda.empty_cache()
    import gc
    gc.collect()
    
    print_trainable_parameters(model)
    
    print("Prepare training data...")
    trainloader, _ = get_loaders(
        args.dataset, 
        nsamples=args.train_steps * args.batch_size, 
        seed=args.seed, 
        seqlen=2048, 
        model=args.model_id
    )
    data = QATDataset(trainloader)
    
    training_args = TrainingArguments(
        output_dir=args.output_dir + "/lora_finetuned",
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.lr,
        logging_steps=10,
        max_steps=args.train_steps,
        save_steps=25,
        bf16=True,
        optim="adamw_torch",
        report_to="tensorboard",
        gradient_checkpointing=True, # Enable gradient checkpointing to save memory
        save_total_limit=None, # Keep all checkpoints
    )
    
    trainer = LoRATrainer(
        model=model,
        train_dataset=data,
        args=training_args,
        data_collator=DataCollatorForLanguageModeling(tokenizer, mlm=False),
    )
    
    model.config.use_cache = False
    
    print("Starting LoRA finetuning...")
    trainer.train()
    
    save_path = args.output_dir + "/lora_final.pth"
    print(f"Saving LoRA model to {save_path}...")
    torch.save(model.state_dict(), save_path)
    print("Done!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_id", type=str, required=True)
    parser.add_argument("--prune_info_path", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--wbits", type=int, default=4)
    parser.add_argument("--abits", type=int, default=16)
    parser.add_argument("--quant_type", type=str, default="mix")
    parser.add_argument("--group_size", type=int, default=None)
    parser.add_argument("--act_scales", type=str, default=None)
    parser.add_argument("--act_shifts", type=str, default=None)
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=16)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--dataset", type=str, default="wikitext2")
    parser.add_argument("--data_percent", type=float, default=100)
    parser.add_argument("--train_steps", type=int, default=200)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    
    args = parser.parse_args()
    
    if args.act_scales is None: args.act_scales = args.output_dir + "/act_scales.pt"
    if args.act_shifts is None: args.act_shifts = args.output_dir + "/act_shifts.pt"
    
    main(args)
